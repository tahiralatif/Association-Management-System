--
-- PostgreSQL database dump
--

\restrict xmdXl7eYJDNRdd08hIVVRw9QFbr6OnYXaFsldhx4S6HalZDoF43Lo2L6oDci89D

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workflow_runs DROP CONSTRAINT IF EXISTS workflow_runs_workflow_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workflow_delays DROP CONSTRAINT IF EXISTS workflow_delays_workflow_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workflow_delays DROP CONSTRAINT IF EXISTS workflow_delays_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.webhook_logs DROP CONSTRAINT IF EXISTS webhook_logs_webhook_id_fkey;
ALTER TABLE IF EXISTS ONLY public.survey_responses DROP CONSTRAINT IF EXISTS survey_responses_survey_id_fkey;
ALTER TABLE IF EXISTS ONLY public.survey_responses DROP CONSTRAINT IF EXISTS survey_responses_respondent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recurring_transactions DROP CONSTRAINT IF EXISTS recurring_transactions_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.recurring_transactions DROP CONSTRAINT IF EXISTS recurring_transactions_dues_structure_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nominations DROP CONSTRAINT IF EXISTS nominations_position_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nominations DROP CONSTRAINT IF EXISTS nominations_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.nominations DROP CONSTRAINT IF EXISTS nominations_election_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_logs DROP CONSTRAINT IF EXISTS message_logs_recipient_id_fkey;
ALTER TABLE IF EXISTS ONLY public.message_logs DROP CONSTRAINT IF EXISTS message_logs_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_profiles DROP CONSTRAINT IF EXISTS member_profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_profile_tags DROP CONSTRAINT IF EXISTS member_profile_tags_tag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_profile_tags DROP CONSTRAINT IF EXISTS member_profile_tags_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_notes DROP CONSTRAINT IF EXISTS member_notes_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_notes DROP CONSTRAINT IF EXISTS member_notes_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_groups DROP CONSTRAINT IF EXISTS member_groups_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_group_memberships DROP CONSTRAINT IF EXISTS member_group_memberships_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_group_memberships DROP CONSTRAINT IF EXISTS member_group_memberships_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.member_activity_logs DROP CONSTRAINT IF EXISTS member_activity_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_dues_structure_id_fkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_submitted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_budget_id_fkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_approved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.event_tickets DROP CONSTRAINT IF EXISTS event_tickets_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_sponsors DROP CONSTRAINT IF EXISTS event_sponsors_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_speakers DROP CONSTRAINT IF EXISTS event_speakers_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_speakers DROP CONSTRAINT IF EXISTS event_speakers_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_speakers DROP CONSTRAINT IF EXISTS event_speakers_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_sessions DROP CONSTRAINT IF EXISTS event_sessions_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_registrations DROP CONSTRAINT IF EXISTS event_registrations_ticket_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_registrations DROP CONSTRAINT IF EXISTS event_registrations_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_registrations DROP CONSTRAINT IF EXISTS event_registrations_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_feedback DROP CONSTRAINT IF EXISTS event_feedback_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_feedback DROP CONSTRAINT IF EXISTS event_feedback_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_feedback DROP CONSTRAINT IF EXISTS event_feedback_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_sending_logs DROP CONSTRAINT IF EXISTS email_sending_logs_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_sending_logs DROP CONSTRAINT IF EXISTS email_sending_logs_recipient_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_sending_logs DROP CONSTRAINT IF EXISTS email_sending_logs_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.election_results DROP CONSTRAINT IF EXISTS election_results_position_id_fkey;
ALTER TABLE IF EXISTS ONLY public.election_results DROP CONSTRAINT IF EXISTS election_results_election_id_fkey;
ALTER TABLE IF EXISTS ONLY public.election_positions DROP CONSTRAINT IF EXISTS election_positions_election_id_fkey;
ALTER TABLE IF EXISTS ONLY public.drip_steps DROP CONSTRAINT IF EXISTS drip_steps_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.drip_logs DROP CONSTRAINT IF EXISTS drip_logs_step_id_fkey;
ALTER TABLE IF EXISTS ONLY public.drip_logs DROP CONSTRAINT IF EXISTS drip_logs_enrollment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.drip_logs DROP CONSTRAINT IF EXISTS drip_logs_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.drip_enrollments DROP CONSTRAINT IF EXISTS drip_enrollments_campaign_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_versions DROP CONSTRAINT IF EXISTS document_versions_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_shares DROP CONSTRAINT IF EXISTS document_shares_shared_with_fkey;
ALTER TABLE IF EXISTS ONLY public.document_shares DROP CONSTRAINT IF EXISTS document_shares_shared_by_fkey;
ALTER TABLE IF EXISTS ONLY public.document_shares DROP CONSTRAINT IF EXISTS document_shares_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_comments DROP CONSTRAINT IF EXISTS document_comments_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_comments DROP CONSTRAINT IF EXISTS document_comments_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_comments DROP CONSTRAINT IF EXISTS document_comments_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_categories DROP CONSTRAINT IF EXISTS document_categories_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_activities DROP CONSTRAINT IF EXISTS document_activities_member_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_activities DROP CONSTRAINT IF EXISTS document_activities_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.discount_codes DROP CONSTRAINT IF EXISTS discount_codes_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS dashboard_widgets_dashboard_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ballots DROP CONSTRAINT IF EXISTS ballots_voter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ballots DROP CONSTRAINT IF EXISTS ballots_election_id_fkey;
DROP INDEX IF EXISTS public.ix_workflows_tenant_id;
DROP INDEX IF EXISTS public.ix_workflow_runs_workflow_id;
DROP INDEX IF EXISTS public.ix_workflow_runs_tenant_id;
DROP INDEX IF EXISTS public.ix_workflow_delays_workflow_id;
DROP INDEX IF EXISTS public.ix_workflow_delays_tenant_id;
DROP INDEX IF EXISTS public.ix_workflow_delays_run_id;
DROP INDEX IF EXISTS public.ix_workflow_action_templates_tenant_id;
DROP INDEX IF EXISTS public.ix_webhooks_tenant_id;
DROP INDEX IF EXISTS public.ix_webhook_logs_webhook_id;
DROP INDEX IF EXISTS public.ix_webhook_logs_tenant_id;
DROP INDEX IF EXISTS public.ix_users_tenant_id;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_surveys_tenant_id;
DROP INDEX IF EXISTS public.ix_survey_responses_survey_id;
DROP INDEX IF EXISTS public.ix_saved_reports_tenant_id;
DROP INDEX IF EXISTS public.ix_recurring_transactions_tenant_id;
DROP INDEX IF EXISTS public.ix_payments_tenant_id;
DROP INDEX IF EXISTS public.ix_payments_invoice_id;
DROP INDEX IF EXISTS public.ix_notifications_user_id;
DROP INDEX IF EXISTS public.ix_notifications_tenant_id;
DROP INDEX IF EXISTS public.ix_nominations_tenant_id;
DROP INDEX IF EXISTS public.ix_nominations_member_id;
DROP INDEX IF EXISTS public.ix_nominations_election_id;
DROP INDEX IF EXISTS public.ix_message_logs_tenant_id;
DROP INDEX IF EXISTS public.ix_member_tags_tenant_id;
DROP INDEX IF EXISTS public.ix_member_profiles_tenant_id;
DROP INDEX IF EXISTS public.ix_member_notes_tenant_id;
DROP INDEX IF EXISTS public.ix_member_groups_tenant_id;
DROP INDEX IF EXISTS public.ix_member_activity_logs_tenant_id;
DROP INDEX IF EXISTS public.ix_kpi_snapshots_tenant_id;
DROP INDEX IF EXISTS public.ix_kpi_snapshots_snapshot_date;
DROP INDEX IF EXISTS public.ix_kpi_snapshots_metric_name;
DROP INDEX IF EXISTS public.ix_invoices_tenant_id;
DROP INDEX IF EXISTS public.ix_invoices_member_id;
DROP INDEX IF EXISTS public.ix_integrations_tenant_id;
DROP INDEX IF EXISTS public.ix_integration_events_tenant_id;
DROP INDEX IF EXISTS public.ix_expenses_tenant_id;
DROP INDEX IF EXISTS public.ix_events_tenant_id;
DROP INDEX IF EXISTS public.ix_event_tickets_tenant_id;
DROP INDEX IF EXISTS public.ix_event_tickets_event_id;
DROP INDEX IF EXISTS public.ix_event_sponsors_tenant_id;
DROP INDEX IF EXISTS public.ix_event_sponsors_event_id;
DROP INDEX IF EXISTS public.ix_event_speakers_tenant_id;
DROP INDEX IF EXISTS public.ix_event_speakers_event_id;
DROP INDEX IF EXISTS public.ix_event_sessions_tenant_id;
DROP INDEX IF EXISTS public.ix_event_sessions_event_id;
DROP INDEX IF EXISTS public.ix_event_registrations_tenant_id;
DROP INDEX IF EXISTS public.ix_event_registrations_member_id;
DROP INDEX IF EXISTS public.ix_event_registrations_event_id;
DROP INDEX IF EXISTS public.ix_event_feedback_tenant_id;
DROP INDEX IF EXISTS public.ix_event_feedback_event_id;
DROP INDEX IF EXISTS public.ix_email_templates_tenant_id;
DROP INDEX IF EXISTS public.ix_email_sending_logs_tenant_status;
DROP INDEX IF EXISTS public.ix_email_sending_logs_tenant_id;
DROP INDEX IF EXISTS public.ix_email_sending_logs_status;
DROP INDEX IF EXISTS public.ix_email_sending_logs_recipient_id;
DROP INDEX IF EXISTS public.ix_email_sending_logs_recipient_email;
DROP INDEX IF EXISTS public.ix_email_sending_logs_created_at;
DROP INDEX IF EXISTS public.ix_email_campaigns_tenant_id;
DROP INDEX IF EXISTS public.ix_elections_tenant_id;
DROP INDEX IF EXISTS public.ix_election_results_tenant_id;
DROP INDEX IF EXISTS public.ix_election_results_election_id;
DROP INDEX IF EXISTS public.ix_election_positions_tenant_id;
DROP INDEX IF EXISTS public.ix_election_positions_election_id;
DROP INDEX IF EXISTS public.ix_dues_structures_tenant_id;
DROP INDEX IF EXISTS public.ix_drip_steps_tenant_id;
DROP INDEX IF EXISTS public.ix_drip_steps_campaign_id;
DROP INDEX IF EXISTS public.ix_drip_logs_tenant_id;
DROP INDEX IF EXISTS public.ix_drip_logs_enrollment_id;
DROP INDEX IF EXISTS public.ix_drip_enrollments_tenant_id;
DROP INDEX IF EXISTS public.ix_drip_enrollments_member_id;
DROP INDEX IF EXISTS public.ix_drip_enrollments_campaign_id;
DROP INDEX IF EXISTS public.ix_drip_campaigns_tenant_id;
DROP INDEX IF EXISTS public.ix_documents_tenant_id;
DROP INDEX IF EXISTS public.ix_documents_category_id;
DROP INDEX IF EXISTS public.ix_document_versions_tenant_id;
DROP INDEX IF EXISTS public.ix_document_versions_document_id;
DROP INDEX IF EXISTS public.ix_document_shares_tenant_id;
DROP INDEX IF EXISTS public.ix_document_shares_document_id;
DROP INDEX IF EXISTS public.ix_document_comments_tenant_id;
DROP INDEX IF EXISTS public.ix_document_comments_document_id;
DROP INDEX IF EXISTS public.ix_document_categories_tenant_id;
DROP INDEX IF EXISTS public.ix_document_activities_tenant_id;
DROP INDEX IF EXISTS public.ix_document_activities_document_id;
DROP INDEX IF EXISTS public.ix_discount_codes_tenant_id;
DROP INDEX IF EXISTS public.ix_data_exports_tenant_id;
DROP INDEX IF EXISTS public.ix_dashboards_tenant_id;
DROP INDEX IF EXISTS public.ix_dashboard_widgets_tenant_id;
DROP INDEX IF EXISTS public.ix_dashboard_widgets_dashboard_id;
DROP INDEX IF EXISTS public.ix_budgets_tenant_id;
DROP INDEX IF EXISTS public.ix_ballots_voter_id;
DROP INDEX IF EXISTS public.ix_ballots_tenant_id;
DROP INDEX IF EXISTS public.ix_ballots_election_id;
DROP INDEX IF EXISTS public.ix_announcements_tenant_id;
DROP INDEX IF EXISTS public.ix_ai_predictions_tenant_id;
DROP INDEX IF EXISTS public.ix_ai_predictions_model_id;
DROP INDEX IF EXISTS public.ix_ai_predictions_entity_type;
DROP INDEX IF EXISTS public.ix_ai_predictions_entity_id;
DROP INDEX IF EXISTS public.ix_ai_models_tenant_id;
DROP INDEX IF EXISTS public.ix_ai_insights_tenant_id;
DROP INDEX IF EXISTS public.ix_ai_embeddings_tenant_id;
DROP INDEX IF EXISTS public.ix_ai_embeddings_content_type;
DROP INDEX IF EXISTS public.ix_ai_embeddings_content_id;
DROP INDEX IF EXISTS public.ix_ai_conversations_tenant_id;
DROP INDEX IF EXISTS public.ix_ai_conversations_session_id;
DROP INDEX IF EXISTS public.idx_notifications_user;
DROP INDEX IF EXISTS public.idx_notifications_unread;
DROP INDEX IF EXISTS public.idx_esl_unsubscribe;
DROP INDEX IF EXISTS public.idx_esl_tracking;
DROP INDEX IF EXISTS public.idx_email_tracking_tenant;
DROP INDEX IF EXISTS public.idx_audit_logs_user;
DROP INDEX IF EXISTS public.idx_audit_logs_tenant;
DROP INDEX IF EXISTS public.idx_audit_logs_created;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_pkey;
ALTER TABLE IF EXISTS ONLY public.workflow_runs DROP CONSTRAINT IF EXISTS workflow_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.workflow_delays DROP CONSTRAINT IF EXISTS workflow_delays_pkey;
ALTER TABLE IF EXISTS ONLY public.workflow_action_templates DROP CONSTRAINT IF EXISTS workflow_action_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.webhooks DROP CONSTRAINT IF EXISTS webhooks_pkey;
ALTER TABLE IF EXISTS ONLY public.webhook_logs DROP CONSTRAINT IF EXISTS webhook_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.surveys DROP CONSTRAINT IF EXISTS surveys_pkey;
ALTER TABLE IF EXISTS ONLY public.survey_responses DROP CONSTRAINT IF EXISTS survey_responses_pkey;
ALTER TABLE IF EXISTS ONLY public.saved_reports DROP CONSTRAINT IF EXISTS saved_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.recurring_transactions DROP CONSTRAINT IF EXISTS recurring_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.nominations DROP CONSTRAINT IF EXISTS nominations_pkey;
ALTER TABLE IF EXISTS ONLY public.message_logs DROP CONSTRAINT IF EXISTS message_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.member_tags DROP CONSTRAINT IF EXISTS member_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.member_profiles DROP CONSTRAINT IF EXISTS member_profiles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.member_profiles DROP CONSTRAINT IF EXISTS member_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.member_profiles DROP CONSTRAINT IF EXISTS member_profiles_member_number_key;
ALTER TABLE IF EXISTS ONLY public.member_profile_tags DROP CONSTRAINT IF EXISTS member_profile_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.member_notes DROP CONSTRAINT IF EXISTS member_notes_pkey;
ALTER TABLE IF EXISTS ONLY public.member_groups DROP CONSTRAINT IF EXISTS member_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.member_group_memberships DROP CONSTRAINT IF EXISTS member_group_memberships_pkey;
ALTER TABLE IF EXISTS ONLY public.member_activity_logs DROP CONSTRAINT IF EXISTS member_activity_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_snapshots DROP CONSTRAINT IF EXISTS kpi_snapshots_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_invoice_number_key;
ALTER TABLE IF EXISTS ONLY public.integrations DROP CONSTRAINT IF EXISTS integrations_pkey;
ALTER TABLE IF EXISTS ONLY public.integration_events DROP CONSTRAINT IF EXISTS integration_events_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.event_tickets DROP CONSTRAINT IF EXISTS event_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.event_sponsors DROP CONSTRAINT IF EXISTS event_sponsors_pkey;
ALTER TABLE IF EXISTS ONLY public.event_speakers DROP CONSTRAINT IF EXISTS event_speakers_pkey;
ALTER TABLE IF EXISTS ONLY public.event_sessions DROP CONSTRAINT IF EXISTS event_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.event_registrations DROP CONSTRAINT IF EXISTS event_registrations_pkey;
ALTER TABLE IF EXISTS ONLY public.event_feedback DROP CONSTRAINT IF EXISTS event_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.email_tracking_events DROP CONSTRAINT IF EXISTS email_tracking_events_pkey;
ALTER TABLE IF EXISTS ONLY public.email_templates DROP CONSTRAINT IF EXISTS email_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.email_sending_logs DROP CONSTRAINT IF EXISTS email_sending_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.email_campaigns DROP CONSTRAINT IF EXISTS email_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.elections DROP CONSTRAINT IF EXISTS elections_pkey;
ALTER TABLE IF EXISTS ONLY public.election_results DROP CONSTRAINT IF EXISTS election_results_pkey;
ALTER TABLE IF EXISTS ONLY public.election_positions DROP CONSTRAINT IF EXISTS election_positions_pkey;
ALTER TABLE IF EXISTS ONLY public.dues_structures DROP CONSTRAINT IF EXISTS dues_structures_pkey;
ALTER TABLE IF EXISTS ONLY public.drip_steps DROP CONSTRAINT IF EXISTS drip_steps_pkey;
ALTER TABLE IF EXISTS ONLY public.drip_logs DROP CONSTRAINT IF EXISTS drip_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.drip_enrollments DROP CONSTRAINT IF EXISTS drip_enrollments_pkey;
ALTER TABLE IF EXISTS ONLY public.drip_campaigns DROP CONSTRAINT IF EXISTS drip_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_versions DROP CONSTRAINT IF EXISTS document_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.document_shares DROP CONSTRAINT IF EXISTS document_shares_pkey;
ALTER TABLE IF EXISTS ONLY public.document_comments DROP CONSTRAINT IF EXISTS document_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.document_categories DROP CONSTRAINT IF EXISTS document_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.document_activities DROP CONSTRAINT IF EXISTS document_activities_pkey;
ALTER TABLE IF EXISTS ONLY public.discount_codes DROP CONSTRAINT IF EXISTS discount_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.data_exports DROP CONSTRAINT IF EXISTS data_exports_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboards DROP CONSTRAINT IF EXISTS dashboards_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS dashboard_widgets_pkey;
ALTER TABLE IF EXISTS ONLY public.budgets DROP CONSTRAINT IF EXISTS budgets_pkey;
ALTER TABLE IF EXISTS ONLY public.ballots DROP CONSTRAINT IF EXISTS ballots_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.announcements DROP CONSTRAINT IF EXISTS announcements_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS ONLY public.ai_predictions DROP CONSTRAINT IF EXISTS ai_predictions_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_models DROP CONSTRAINT IF EXISTS ai_models_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_insights DROP CONSTRAINT IF EXISTS ai_insights_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_embeddings DROP CONSTRAINT IF EXISTS ai_embeddings_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_conversations DROP CONSTRAINT IF EXISTS ai_conversations_pkey;
DROP TABLE IF EXISTS public.workflows;
DROP TABLE IF EXISTS public.workflow_runs;
DROP TABLE IF EXISTS public.workflow_delays;
DROP TABLE IF EXISTS public.workflow_action_templates;
DROP TABLE IF EXISTS public.webhooks;
DROP TABLE IF EXISTS public.webhook_logs;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.surveys;
DROP TABLE IF EXISTS public.survey_responses;
DROP TABLE IF EXISTS public.saved_reports;
DROP TABLE IF EXISTS public.recurring_transactions;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.nominations;
DROP TABLE IF EXISTS public.message_logs;
DROP TABLE IF EXISTS public.member_tags;
DROP TABLE IF EXISTS public.member_profiles;
DROP TABLE IF EXISTS public.member_profile_tags;
DROP TABLE IF EXISTS public.member_notes;
DROP TABLE IF EXISTS public.member_groups;
DROP TABLE IF EXISTS public.member_group_memberships;
DROP TABLE IF EXISTS public.member_activity_logs;
DROP TABLE IF EXISTS public.kpi_snapshots;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.integrations;
DROP TABLE IF EXISTS public.integration_events;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.event_tickets;
DROP TABLE IF EXISTS public.event_sponsors;
DROP TABLE IF EXISTS public.event_speakers;
DROP TABLE IF EXISTS public.event_sessions;
DROP TABLE IF EXISTS public.event_registrations;
DROP TABLE IF EXISTS public.event_feedback;
DROP TABLE IF EXISTS public.email_tracking_events;
DROP TABLE IF EXISTS public.email_templates;
DROP TABLE IF EXISTS public.email_sending_logs;
DROP TABLE IF EXISTS public.email_campaigns;
DROP TABLE IF EXISTS public.elections;
DROP TABLE IF EXISTS public.election_results;
DROP TABLE IF EXISTS public.election_positions;
DROP TABLE IF EXISTS public.dues_structures;
DROP TABLE IF EXISTS public.drip_steps;
DROP TABLE IF EXISTS public.drip_logs;
DROP TABLE IF EXISTS public.drip_enrollments;
DROP TABLE IF EXISTS public.drip_campaigns;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_versions;
DROP TABLE IF EXISTS public.document_shares;
DROP TABLE IF EXISTS public.document_comments;
DROP TABLE IF EXISTS public.document_categories;
DROP TABLE IF EXISTS public.document_activities;
DROP TABLE IF EXISTS public.discount_codes;
DROP TABLE IF EXISTS public.data_exports;
DROP TABLE IF EXISTS public.dashboards;
DROP TABLE IF EXISTS public.dashboard_widgets;
DROP TABLE IF EXISTS public.budgets;
DROP TABLE IF EXISTS public.ballots;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.announcements;
DROP TABLE IF EXISTS public.alembic_version;
DROP TABLE IF EXISTS public.ai_predictions;
DROP TABLE IF EXISTS public.ai_models;
DROP TABLE IF EXISTS public.ai_insights;
DROP TABLE IF EXISTS public.ai_embeddings;
DROP TABLE IF EXISTS public.ai_conversations;
DROP TYPE IF EXISTS public.workflowstatus;
DROP TYPE IF EXISTS public.votemethod;
DROP TYPE IF EXISTS public.triggertype;
DROP TYPE IF EXISTS public.tickettype;
DROP TYPE IF EXISTS public.surveystatus;
DROP TYPE IF EXISTS public.sessiontype;
DROP TYPE IF EXISTS public.runstatus;
DROP TYPE IF EXISTS public.reporttype;
DROP TYPE IF EXISTS public.reportformat;
DROP TYPE IF EXISTS public.registrationstatus;
DROP TYPE IF EXISTS public.predictiontype;
DROP TYPE IF EXISTS public.paymentmethod;
DROP TYPE IF EXISTS public.nominationstatus;
DROP TYPE IF EXISTS public.modeltype;
DROP TYPE IF EXISTS public.memberstatus;
DROP TYPE IF EXISTS public.membershiptier;
DROP TYPE IF EXISTS public.invoicestatus;
DROP TYPE IF EXISTS public.integrationtype;
DROP TYPE IF EXISTS public.integrationstatus;
DROP TYPE IF EXISTS public.grouptype;
DROP TYPE IF EXISTS public.groupmemberrole;
DROP TYPE IF EXISTS public.expensestatus;
DROP TYPE IF EXISTS public.expensecategory;
DROP TYPE IF EXISTS public.eventstatus;
DROP TYPE IF EXISTS public.electionstatus;
DROP TYPE IF EXISTS public.documenttype;
DROP TYPE IF EXISTS public.documentstatus;
DROP TYPE IF EXISTS public.discounttype;
DROP TYPE IF EXISTS public.dashboardwidgettype;
DROP TYPE IF EXISTS public.conversationrole;
DROP TYPE IF EXISTS public.contenttype;
DROP TYPE IF EXISTS public.channeltype;
DROP TYPE IF EXISTS public.campaignstatus;
DROP TYPE IF EXISTS public.budgetperiod;
DROP TYPE IF EXISTS public.applicableto;
DROP TYPE IF EXISTS public.announcementstatus;
DROP TYPE IF EXISTS public.actiontype;
DROP TYPE IF EXISTS public.accesslevel;
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: accesslevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.accesslevel AS ENUM (
    'PUBLIC',
    'MEMBERS',
    'STAFF',
    'ADMIN',
    'RESTRICTED'
);


--
-- Name: actiontype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.actiontype AS ENUM (
    'SEND_EMAIL',
    'SEND_NOTIFICATION',
    'SEND_SMS',
    'UPDATE_MEMBER',
    'CREATE_TASK',
    'ADD_TO_GROUP',
    'REMOVE_FROM_GROUP',
    'CREATE_INVOICE',
    'GENERATE_REPORT',
    'WAIT',
    'CONDITION',
    'WEBHOOK_CALL',
    'AI_ACTION'
);


--
-- Name: announcementstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.announcementstatus AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'PUBLISHED',
    'ARCHIVED'
);


--
-- Name: applicableto; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.applicableto AS ENUM (
    'EVENT',
    'MEMBERSHIP',
    'BOTH'
);


--
-- Name: budgetperiod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.budgetperiod AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'ANNUAL'
);


--
-- Name: campaignstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.campaignstatus AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'SENDING',
    'SENT',
    'PAUSED',
    'CANCELLED'
);


--
-- Name: channeltype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.channeltype AS ENUM (
    'EMAIL',
    'SMS',
    'PUSH',
    'IN_APP'
);


--
-- Name: contenttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.contenttype AS ENUM (
    'MEMBER',
    'DOCUMENT',
    'EVENT',
    'TRANSACTION',
    'COMMUNICATION',
    'POLICY',
    'CUSTOM'
);


--
-- Name: conversationrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.conversationrole AS ENUM (
    'USER',
    'ASSISTANT',
    'SYSTEM'
);


--
-- Name: dashboardwidgettype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.dashboardwidgettype AS ENUM (
    'LINE_CHART',
    'BAR_CHART',
    'PIE_CHART',
    'STAT_CARD',
    'TABLE',
    'HEATMAP',
    'FUNNEL',
    'GAUGE'
);


--
-- Name: discounttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.discounttype AS ENUM (
    'PERCENTAGE',
    'FIXED'
);


--
-- Name: documentstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.documentstatus AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED',
    'DELETED'
);


--
-- Name: documenttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.documenttype AS ENUM (
    'FILE',
    'FOLDER',
    'LINK',
    'policy',
    'bylaws',
    'minutes',
    'resolution',
    'report',
    'form',
    'other',
    'POLICY',
    'BYLAWS',
    'MINUTES',
    'RESOLUTION',
    'REPORT',
    'FORM',
    'OTHER'
);


--
-- Name: electionstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.electionstatus AS ENUM (
    'DRAFT',
    'NOMINATIONS_OPEN',
    'VOTING',
    'CLOSED',
    'RESULTS_PUBLISHED'
);


--
-- Name: eventstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.eventstatus AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'CANCELLED',
    'COMPLETED'
);


--
-- Name: expensecategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.expensecategory AS ENUM (
    'OPERATIONS',
    'EVENTS',
    'MARKETING',
    'TRAVEL',
    'TECHNOLOGY',
    'PROFESSIONAL_SERVICES',
    'FACILITIES',
    'INSURANCE',
    'OTHER'
);


--
-- Name: expensestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.expensestatus AS ENUM (
    'DRAFT',
    'PENDING_APPROVAL',
    'APPROVED',
    'REJECTED',
    'REIMBURSED'
);


--
-- Name: groupmemberrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.groupmemberrole AS ENUM (
    'MEMBER',
    'CHAIR',
    'CO_CHAIR',
    'SECRETARY',
    'TREASURER'
);


--
-- Name: grouptype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.grouptype AS ENUM (
    'CHAPTER',
    'COMMITTEE',
    'INTEREST_GROUP',
    'WORKING_GROUP',
    'BOARD'
);


--
-- Name: integrationstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.integrationstatus AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'ERROR',
    'PENDING'
);


--
-- Name: integrationtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.integrationtype AS ENUM (
    'STRIPE',
    'SLACK',
    'GOOGLE_CALENDAR',
    'ZAPIER',
    'CUSTOM'
);


--
-- Name: invoicestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.invoicestatus AS ENUM (
    'DRAFT',
    'PENDING',
    'PAID',
    'OVERDUE',
    'CANCELLED',
    'REFUNDED'
);


--
-- Name: membershiptier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.membershiptier AS ENUM (
    'FREE',
    'BASIC',
    'PREMIUM',
    'CORPORATE',
    'LIFETIME'
);


--
-- Name: memberstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.memberstatus AS ENUM (
    'PENDING',
    'ACTIVE',
    'SUSPENDED',
    'LAPSED',
    'CANCELLED'
);


--
-- Name: modeltype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.modeltype AS ENUM (
    'CHURN_PREDICTION',
    'ANOMALY_DETECTION',
    'RECOMMENDATION',
    'CLASSIFICATION',
    'REGRESSION',
    'CUSTOM'
);


--
-- Name: nominationstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.nominationstatus AS ENUM (
    'PENDING',
    'ACCEPTED',
    'DECLINED',
    'WITHDRAWN'
);


--
-- Name: paymentmethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.paymentmethod AS ENUM (
    'STRIPE',
    'BANK_TRANSFER',
    'CHECK',
    'CASH',
    'OTHER'
);


--
-- Name: predictiontype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.predictiontype AS ENUM (
    'CHURN_RISK',
    'ANOMALY',
    'RECOMMENDATION',
    'CLASSIFICATION',
    'SCORING'
);


--
-- Name: registrationstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.registrationstatus AS ENUM (
    'PENDING',
    'CONFIRMED',
    'CANCELLED',
    'WAITLISTED',
    'CHECKED_IN'
);


--
-- Name: reportformat; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reportformat AS ENUM (
    'JSON',
    'CSV',
    'PDF',
    'EXCEL'
);


--
-- Name: reporttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reporttype AS ENUM (
    'MEMBER',
    'FINANCIAL',
    'EVENT',
    'COMMUNICATION',
    'ENGAGEMENT',
    'CUSTOM'
);


--
-- Name: runstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.runstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'SUCCESS',
    'FAILED',
    'WAITING',
    'CANCELLED'
);


--
-- Name: sessiontype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sessiontype AS ENUM (
    'KEYNOTE',
    'WORKSHOP',
    'PANEL',
    'NETWORKING',
    'BREAK',
    'CUSTOM'
);


--
-- Name: surveystatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.surveystatus AS ENUM (
    'DRAFT',
    'ACTIVE',
    'CLOSED'
);


--
-- Name: tickettype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tickettype AS ENUM (
    'EARLY_BIRD',
    'REGULAR',
    'VIP',
    'STUDENT',
    'MEMBER',
    'NON_MEMBER',
    'FREE'
);


--
-- Name: triggertype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.triggertype AS ENUM (
    'MEMBER_JOIN',
    'MEMBER_RENEWAL',
    'MEMBER_EXPIRY',
    'PAYMENT_RECEIVED',
    'PAYMENT_OVERDUE',
    'EVENT_REGISTRATION',
    'EVENT_REMINDER',
    'FORM_SUBMISSION',
    'DOCUMENT_UPLOAD',
    'MANUAL',
    'SCHEDULED',
    'WEBHOOK'
);


--
-- Name: votemethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.votemethod AS ENUM (
    'ONLINE',
    'MAIL',
    'IN_PERSON'
);


--
-- Name: workflowstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.workflowstatus AS ENUM (
    'DRAFT',
    'ACTIVE',
    'PAUSED',
    'ARCHIVED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_conversations (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    session_id character varying(64) NOT NULL,
    role public.conversationrole NOT NULL,
    content text NOT NULL,
    tokens_used integer NOT NULL,
    model_used character varying(100),
    metadata_json json,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: ai_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_embeddings (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    content_id character varying(64) NOT NULL,
    content_type public.contenttype NOT NULL,
    text_chunk text NOT NULL,
    embedding public.vector(1536) NOT NULL,
    metadata_json json,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: ai_insights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_insights (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(300) NOT NULL,
    summary text NOT NULL,
    insight_type character varying(50) NOT NULL,
    source_data json,
    confidence integer NOT NULL,
    is_read boolean NOT NULL,
    is_dismissed boolean NOT NULL,
    action_url character varying(500),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: ai_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_models (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    version character varying(50) NOT NULL,
    model_type public.modeltype NOT NULL,
    description text,
    config json,
    metrics json,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: ai_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_predictions (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    model_id uuid,
    entity_id character varying(64) NOT NULL,
    entity_type character varying(50) NOT NULL,
    prediction_type public.predictiontype NOT NULL,
    confidence double precision NOT NULL,
    result json NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(300) NOT NULL,
    slug character varying(300) NOT NULL,
    summary text,
    content text NOT NULL,
    image_url character varying(500),
    audience character varying(50) NOT NULL,
    target_group_ids json,
    status public.announcementstatus NOT NULL,
    is_pinned boolean NOT NULL,
    allow_comments boolean NOT NULL,
    published_at timestamp with time zone,
    expires_at timestamp with time zone,
    view_count integer NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying NOT NULL,
    user_id uuid,
    action character varying NOT NULL,
    resource_type character varying,
    resource_id uuid,
    details jsonb,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: ballots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ballots (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    voter_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    votes json NOT NULL,
    abstentions json,
    verification_code character varying(100),
    ip_address character varying(45),
    cast_at timestamp with time zone NOT NULL
);


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category public.expensecategory NOT NULL,
    period public.budgetperiod NOT NULL,
    planned_amount numeric(12,2) NOT NULL,
    actual_amount numeric(12,2) NOT NULL,
    currency character varying(3) NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    alert_threshold numeric(5,2) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: dashboard_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_widgets (
    id uuid NOT NULL,
    dashboard_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    widget_type public.dashboardwidgettype NOT NULL,
    data_source character varying(100) NOT NULL,
    config json,
    "position" json,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboards (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    is_default boolean NOT NULL,
    is_public boolean NOT NULL,
    layout json,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: data_exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_exports (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    export_type character varying(50) NOT NULL,
    format public.reportformat NOT NULL,
    filters json,
    status character varying(20) NOT NULL,
    file_url character varying(500),
    file_size integer,
    record_count integer NOT NULL,
    requested_by uuid NOT NULL,
    completed_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: discount_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discount_codes (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    code character varying(50) NOT NULL,
    discount_type public.discounttype NOT NULL,
    value numeric(10,2) NOT NULL,
    max_uses integer,
    used_count integer NOT NULL,
    valid_from timestamp with time zone,
    valid_to timestamp with time zone,
    applicable_to public.applicableto NOT NULL,
    is_active boolean NOT NULL,
    created_by uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: document_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_activities (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    member_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    action character varying(50) NOT NULL,
    details json,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: document_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_categories (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    description text,
    icon character varying(50),
    color character varying(7),
    parent_id uuid,
    sort_order integer NOT NULL,
    document_count integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: document_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_comments (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    member_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    content text NOT NULL,
    parent_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: document_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_shares (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    shared_by uuid NOT NULL,
    shared_with uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    permission character varying(20) NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: document_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_versions (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    version integer NOT NULL,
    file_name character varying(300) NOT NULL,
    file_size integer NOT NULL,
    file_url character varying(500) NOT NULL,
    storage_path character varying(500) NOT NULL,
    change_summary text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(300) NOT NULL,
    slug character varying(300) NOT NULL,
    description text,
    document_type public.documenttype NOT NULL,
    status public.documentstatus NOT NULL,
    file_name character varying(300),
    file_size integer,
    file_type character varying(50),
    file_url character varying(500),
    thumbnail_url character varying(500),
    storage_path character varying(500),
    link_url character varying(500),
    version integer NOT NULL,
    current_version_id uuid,
    category_id uuid,
    parent_id uuid,
    tags json,
    access_level public.accesslevel NOT NULL,
    allowed_user_ids json,
    allowed_group_ids json,
    metadata_json json,
    search_text text,
    view_count integer NOT NULL,
    download_count integer NOT NULL,
    published_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: drip_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drip_campaigns (
    id character varying(36) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    trigger_event character varying(50) DEFAULT 'manual'::character varying NOT NULL,
    target_segments json,
    target_group_ids json,
    target_all boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    total_enrolled integer DEFAULT 0 NOT NULL,
    total_completed integer DEFAULT 0 NOT NULL,
    total_unsubscribed integer DEFAULT 0 NOT NULL,
    from_name character varying(100) NOT NULL,
    from_email character varying(200) NOT NULL,
    created_by character varying(36) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: drip_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drip_enrollments (
    id character varying(36) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    campaign_id character varying(36) NOT NULL,
    member_id character varying(36) NOT NULL,
    current_step_order integer DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    next_send_at timestamp with time zone,
    completed_at timestamp with time zone,
    unsubscribed_at timestamp with time zone,
    enrolled_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: drip_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drip_logs (
    id character varying(36) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    enrollment_id character varying(36) NOT NULL,
    step_id character varying(36) NOT NULL,
    campaign_id character varying(36) NOT NULL,
    member_id character varying(36) NOT NULL,
    action character varying(30) NOT NULL,
    tracking_id character varying(100),
    executed_at timestamp with time zone NOT NULL
);


--
-- Name: drip_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drip_steps (
    id character varying(36) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    campaign_id character varying(36) NOT NULL,
    step_order integer NOT NULL,
    step_type character varying(20) DEFAULT 'email'::character varying NOT NULL,
    name character varying(200) NOT NULL,
    subject character varying(500),
    html_body text,
    plain_body text,
    delay_days integer DEFAULT 0 NOT NULL,
    delay_hours integer DEFAULT 0 NOT NULL,
    condition_type character varying(50),
    condition_value character varying(200),
    condition_branch_true integer,
    condition_branch_false integer,
    sent_count integer DEFAULT 0 NOT NULL,
    opened_count integer DEFAULT 0 NOT NULL,
    clicked_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: dues_structures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dues_structures (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    tier character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    billing_cycle character varying(20) NOT NULL,
    description text,
    is_active boolean NOT NULL,
    prorate boolean NOT NULL,
    trial_days integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: election_positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.election_positions (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    seats integer NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: election_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.election_results (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    position_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    total_votes integer NOT NULL,
    results_detail json NOT NULL,
    winners json NOT NULL,
    is_final boolean NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: elections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elections (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    election_type character varying(50) NOT NULL,
    status public.electionstatus NOT NULL,
    nominations_open timestamp with time zone,
    nominations_close timestamp with time zone,
    voting_start timestamp with time zone,
    voting_end timestamp with time zone,
    seats_available integer NOT NULL,
    max_candidates_per_seat integer,
    min_votes_required integer,
    quorum_percentage integer NOT NULL,
    require_unanimous boolean NOT NULL,
    vote_method public.votemethod NOT NULL,
    allow_abstain boolean NOT NULL,
    secret_ballot boolean NOT NULL,
    multiple_rounds boolean NOT NULL,
    ranked_choice boolean NOT NULL,
    total_eligible_voters integer NOT NULL,
    total_votes_cast integer NOT NULL,
    quorum_met boolean NOT NULL,
    results_summary json,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: email_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaigns (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    subject character varying(500) NOT NULL,
    preview_text character varying(200),
    html_body text NOT NULL,
    plain_body text,
    target_segments json,
    target_group_ids json,
    target_all boolean NOT NULL,
    status public.campaignstatus NOT NULL,
    total_recipients integer NOT NULL,
    sent_count integer NOT NULL,
    delivered_count integer NOT NULL,
    opened_count integer NOT NULL,
    clicked_count integer NOT NULL,
    bounced_count integer NOT NULL,
    unsubscribed_count integer NOT NULL,
    scheduled_at timestamp with time zone,
    sent_at timestamp with time zone,
    from_name character varying(100) NOT NULL,
    from_email character varying(200) NOT NULL,
    reply_to character varying(200),
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: email_sending_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_sending_logs (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    recipient_id uuid,
    recipient_email character varying(200) NOT NULL,
    subject character varying(500) NOT NULL,
    body_preview character varying(500),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    provider character varying(50) DEFAULT 'smtp'::character varying NOT NULL,
    error_message text,
    template_id uuid,
    campaign_id uuid,
    retry_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    unsubscribe_token character varying(36),
    tracking_id character varying(36)
);


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    subject character varying(500) NOT NULL,
    html_body text NOT NULL,
    plain_body text,
    variables json,
    category character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: email_tracking_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_tracking_events (
    id character varying(36) NOT NULL,
    tenant_id character varying(64) NOT NULL,
    email_log_id character varying(36),
    event_type character varying(20) NOT NULL,
    tracking_id character varying(36),
    ip_address character varying(45),
    user_agent text,
    url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_feedback (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    member_id uuid NOT NULL,
    session_id uuid,
    tenant_id character varying(64) NOT NULL,
    rating integer NOT NULL,
    review text,
    would_recommend boolean,
    improvements text,
    is_anonymous boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: event_registrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_registrations (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    member_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    ticket_id uuid,
    status public.registrationstatus NOT NULL,
    amount_paid numeric(10,2) NOT NULL,
    payment_method character varying(50),
    stripe_payment_id character varying(100),
    checked_in_at timestamp with time zone,
    check_in_method character varying(50),
    cancelled_at timestamp with time zone,
    cancellation_reason text,
    refund_amount numeric(10,2) NOT NULL,
    dietary_restrictions character varying(200),
    special_requirements text,
    emergency_contact character varying(200),
    emergency_phone character varying(50),
    custom_fields json,
    registered_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: event_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_sessions (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    session_type public.sessiontype NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone NOT NULL,
    room character varying(100),
    track character varying(100),
    max_attendees integer,
    recording_url character varying(500),
    slides_url character varying(500),
    sort_order integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: event_speakers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_speakers (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    session_id uuid,
    member_id uuid,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    title character varying(200),
    company character varying(200),
    bio text,
    avatar_url character varying(500),
    email character varying(200),
    website character varying(500),
    linkedin character varying(500),
    twitter character varying(200),
    is_keynote boolean NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: event_sponsors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_sponsors (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    logo_url character varying(500),
    website character varying(500),
    tier character varying(50) NOT NULL,
    description text,
    sort_order integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: event_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_tickets (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(100) NOT NULL,
    ticket_type public.tickettype NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    quantity_available integer NOT NULL,
    quantity_sold integer NOT NULL,
    max_per_order integer NOT NULL,
    sale_start timestamp with time zone,
    sale_end timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(300) NOT NULL,
    slug character varying(300) NOT NULL,
    description text,
    short_description character varying(500),
    image_url character varying(500),
    banner_url character varying(500),
    event_type character varying(50) NOT NULL,
    status public.eventstatus NOT NULL,
    is_virtual boolean NOT NULL,
    is_hybrid boolean NOT NULL,
    virtual_link character varying(500),
    virtual_platform character varying(50),
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    registration_open timestamp with time zone,
    registration_close timestamp with time zone,
    venue_name character varying(200),
    venue_address text,
    venue_city character varying(100),
    venue_country character varying(100),
    venue_lat double precision,
    venue_lng double precision,
    max_attendees integer,
    waitlist_enabled boolean NOT NULL,
    max_waitlist integer NOT NULL,
    is_free boolean NOT NULL,
    currency character varying(3) NOT NULL,
    tags json,
    external_url character varying(500),
    contact_email character varying(200),
    view_count integer NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    submitted_by uuid NOT NULL,
    approved_by uuid,
    title character varying(200) NOT NULL,
    description text,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    category public.expensecategory NOT NULL,
    status public.expensestatus NOT NULL,
    expense_date timestamp with time zone NOT NULL,
    submitted_at timestamp with time zone,
    approved_at timestamp with time zone,
    reimbursed_at timestamp with time zone,
    receipt_url character varying(500),
    receipt_filename character varying(255),
    budget_id uuid,
    cost_center character varying(100),
    rejection_reason text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: integration_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.integration_events (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    event_type character varying(100) NOT NULL,
    source_module character varying(50) NOT NULL,
    payload json,
    processed boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.integrations (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    integration_type public.integrationtype NOT NULL,
    status public.integrationstatus NOT NULL,
    config json,
    webhook_url character varying(500),
    last_sync_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    invoice_number character varying(50) NOT NULL,
    member_id uuid NOT NULL,
    dues_structure_id uuid,
    event_id character varying(36),
    status public.invoicestatus NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    tax_rate numeric(5,2) NOT NULL,
    tax_amount numeric(10,2) NOT NULL,
    discount_amount numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    amount_paid numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    line_items json,
    issued_at timestamp with time zone NOT NULL,
    due_at timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    notes text,
    internal_notes text,
    stripe_invoice_id character varying(100),
    stripe_payment_intent_id character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    discount_code_id character varying(36)
);


--
-- Name: kpi_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_snapshots (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value integer NOT NULL,
    metric_unit character varying(20),
    dimensions json,
    snapshot_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: member_activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_activity_logs (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    details json,
    ip_address character varying(45),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: member_group_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_group_memberships (
    id uuid NOT NULL,
    member_id uuid NOT NULL,
    group_id uuid NOT NULL,
    role public.groupmemberrole NOT NULL,
    joined_at timestamp with time zone NOT NULL,
    left_at timestamp with time zone,
    is_active boolean NOT NULL
);


--
-- Name: member_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_groups (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    group_type public.grouptype NOT NULL,
    parent_id uuid,
    max_members integer,
    is_active boolean NOT NULL,
    meeting_schedule character varying(200),
    contact_email character varying(255),
    metadata_json json,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: member_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_notes (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    member_id uuid NOT NULL,
    author_id uuid NOT NULL,
    content text NOT NULL,
    is_pinned boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: member_profile_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_profile_tags (
    member_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


--
-- Name: member_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_profiles (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id uuid NOT NULL,
    member_number character varying(50),
    tier public.membershiptier NOT NULL,
    status public.memberstatus NOT NULL,
    joined_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    renewal_date timestamp with time zone,
    auto_renew boolean NOT NULL,
    phone character varying(20),
    organization character varying(200),
    job_title character varying(100),
    bio text,
    avatar_url character varying(500),
    address json,
    social_links json,
    tags json,
    interests json,
    email_opt_in boolean NOT NULL,
    sms_opt_in boolean NOT NULL,
    engagement_score double precision NOT NULL,
    churn_risk double precision NOT NULL,
    lifetime_value double precision NOT NULL,
    custom_fields json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: member_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_tags (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(7) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: message_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_logs (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    channel public.channeltype NOT NULL,
    recipient_id uuid,
    recipient_email character varying(200),
    recipient_phone character varying(50),
    subject character varying(500),
    body_preview character varying(500),
    status character varying(20) NOT NULL,
    campaign_id uuid,
    opened_at timestamp with time zone,
    clicked_at timestamp with time zone,
    clicked_link character varying(500),
    sent_at timestamp with time zone NOT NULL
);


--
-- Name: nominations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nominations (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    position_id uuid NOT NULL,
    member_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    status public.nominationstatus NOT NULL,
    statement text,
    qualifications text,
    endorsed_by json,
    nominated_at timestamp with time zone NOT NULL,
    responded_at timestamp with time zone
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    user_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    link character varying(500),
    notification_type character varying(50) NOT NULL,
    is_read boolean NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    invoice_id uuid NOT NULL,
    member_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    payment_method public.paymentmethod NOT NULL,
    status character varying(20) NOT NULL,
    stripe_charge_id character varying(100),
    stripe_receipt_url character varying(500),
    reference_number character varying(100),
    notes text,
    metadata_json json,
    paid_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: recurring_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_transactions (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    member_id uuid NOT NULL,
    dues_structure_id uuid NOT NULL,
    frequency character varying(20) NOT NULL,
    next_invoice_date timestamp with time zone NOT NULL,
    last_invoice_date timestamp with time zone,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: saved_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_reports (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    report_type public.reporttype NOT NULL,
    query_config json NOT NULL,
    is_scheduled boolean NOT NULL,
    schedule_cron character varying(50),
    last_run_at timestamp with time zone,
    last_result json,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: survey_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.survey_responses (
    id uuid NOT NULL,
    survey_id uuid NOT NULL,
    respondent_id uuid,
    answers json NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.surveys (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    questions json NOT NULL,
    target_segments json,
    target_all boolean NOT NULL,
    status public.surveystatus NOT NULL,
    is_anonymous boolean NOT NULL,
    opens_at timestamp with time zone,
    closes_at timestamp with time zone,
    total_invited integer NOT NULL,
    response_count integer NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    roles json NOT NULL,
    is_active boolean NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    email_verified boolean DEFAULT true NOT NULL,
    verification_token character varying(255),
    verification_sent_at timestamp with time zone,
    custom_permissions text[]
);


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_logs (
    id uuid NOT NULL,
    webhook_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    event_type character varying(100) NOT NULL,
    payload json,
    response_status integer,
    response_body text,
    success boolean NOT NULL,
    attempts integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    url character varying(500) NOT NULL,
    events json,
    secret character varying(200),
    is_active boolean NOT NULL,
    retry_count integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: workflow_action_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_action_templates (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    action_type public.actiontype NOT NULL,
    config json NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: workflow_delays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_delays (
    id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    run_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    step_index integer NOT NULL,
    resume_at timestamp with time zone NOT NULL,
    is_resumed boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: workflow_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_runs (
    id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    status public.runstatus NOT NULL,
    current_step integer NOT NULL,
    total_steps integer NOT NULL,
    trigger_data json,
    context json,
    step_results json,
    error_message text,
    error_step integer,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id uuid NOT NULL,
    tenant_id character varying(64) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    status public.workflowstatus NOT NULL,
    trigger_type public.triggertype NOT NULL,
    trigger_config json,
    steps json NOT NULL,
    total_runs integer NOT NULL,
    successful_runs integer NOT NULL,
    failed_runs integer NOT NULL,
    last_run_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Data for Name: ai_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_conversations (id, tenant_id, session_id, role, content, tokens_used, model_used, metadata_json, created_at) FROM stdin;
f210707b-1ff1-441a-b457-4245b855d932	demo-association	764c8a86-f045-4dbf-8845-385d62a1823f	USER	How many members do we have?	0	\N	{}	2026-07-23 01:53:09.823348+00
74cb90a1-85dc-4ce0-9b8d-b1e337777f3e	demo-association	764c8a86-f045-4dbf-8845-385d62a1823f	ASSISTANT	AI chat is in demo mode. Your message was: 'How many members do we have?'. Configure LLM_API_KEY to enable full AI capabilities.	6	rule-based	{}	2026-07-23 01:53:09.834406+00
b4ea88c2-f140-4871-881d-57d4b4b7e6a9	demo-association	05c4e3fa-61d2-47ff-ba46-0aa253fbe5bc	USER	How many members?	0	\N	{}	2026-07-23 02:11:05.620317+00
11c66005-1909-42d9-bc4f-b5802eb7bfec	demo-association	05c4e3fa-61d2-47ff-ba46-0aa253fbe5bc	ASSISTANT	AI chat is in demo mode. Your message was: 'How many members?'. Configure LLM_API_KEY to enable full AI capabilities.	3	rule-based	{}	2026-07-23 02:11:05.629525+00
f104c1a1-743a-4ee5-a1a2-6d307ee4381b	demo-association	b6e813dd-d082-446d-af3c-1c6abbe62a22	USER	How many members?	0	\N	{}	2026-07-23 02:23:21.691402+00
a069c963-49bb-4700-b6eb-f7d05d516bf1	demo-association	b6e813dd-d082-446d-af3c-1c6abbe62a22	ASSISTANT	AI chat is in demo mode. Your message was: 'How many members?'. Configure LLM_API_KEY to enable full AI capabilities.	3	rule-based	{}	2026-07-23 02:23:21.706239+00
2de4b0f0-312c-494b-9556-7fdd3566c222	demo-association	b4302c96-6302-4635-98ce-4fcf6f66c219	USER	How many members?	0	\N	{}	2026-07-23 02:35:27.216027+00
70b1c1a5-7733-4332-9a24-c120a8efbec5	demo-association	b4302c96-6302-4635-98ce-4fcf6f66c219	ASSISTANT	AI chat is in demo mode. Your message was: 'How many members?'. Configure LLM_API_KEY to enable full AI capabilities.	3	rule-based	{}	2026-07-23 02:35:27.227314+00
74144157-cfb9-4674-8f06-04e6ebb5ea19	demo-association	853886f6-130d-4992-a3c0-bd2804481c1e	USER	How many members do we have?	0	\N	{}	2026-07-23 05:32:13.958386+00
a7e88a91-d9a3-45f3-b80e-4fba2ad141b5	demo-association	853886f6-130d-4992-a3c0-bd2804481c1e	ASSISTANT	I don't have access to real-time data. To get the most up-to-date information on the number of members, I recommend checking the association management system's member database or contacting the system administrator.	81	llama-3.3-70b-versatile	{}	2026-07-23 05:32:15.104236+00
1fe79ae6-5f88-4ea3-8005-b785ffde2797	demo-association	39732196-4e0c-45f4-8149-12a7e3b8ce71	USER	Hello	0	\N	{}	2026-07-23 05:34:31.198061+00
6fe54d72-33a5-41eb-81e3-6aac6bc805a8	demo-association	39732196-4e0c-45f4-8149-12a7e3b8ce71	ASSISTANT	Hello. How can I assist you with your association management needs today? Do you have questions about member management, finances, events, documents, or something else?	64	llama-3.3-70b-versatile	{}	2026-07-23 05:34:31.597603+00
b86f5ab4-953a-420d-a2fd-49741fe1eec5	demo-association	d0577bab-b1d5-482d-8faf-1d98818f2513	USER	Hello	0	\N	{}	2026-07-23 05:36:11.633654+00
38093351-4439-4c09-a4a2-edd726312fed	demo-association	d0577bab-b1d5-482d-8faf-1d98818f2513	ASSISTANT	Hello. How can I assist you with your association management needs today? Do you need help with member management, finances, events, documents, or something else?	64	llama-3.3-70b-versatile	{}	2026-07-23 05:36:12.773067+00
4b21e665-dfb8-4397-b957-8d9d0bcd9d56	demo-association	c5d090e9-d05b-4242-940f-8bc4a423a76d	USER	Hello	0	\N	{}	2026-07-23 06:48:29.05756+00
9c680720-44b9-41a5-8ecd-ae48a9d2e552	demo-association	c5d090e9-d05b-4242-940f-8bc4a423a76d	ASSISTANT	Hello. How can I assist you with your association management today? Do you have questions about member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 06:48:29.304074+00
f7d15e4a-f33a-4bf1-a736-3f831a3e04e8	demo-association	166bd4cc-30e1-4332-98ef-fc8f0ea871d6	USER	Hi	0	\N	{}	2026-07-23 06:50:41.400639+00
0c817a88-e7bd-4dc3-98b4-822921ae9f18	demo-association	166bd4cc-30e1-4332-98ef-fc8f0ea871d6	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 06:50:41.786981+00
cca3537a-61eb-4d26-9d30-de476769ad60	demo-association	3165d54f-5c5b-4593-9bf3-cf83b4f985f8	USER	Hi	0	\N	{}	2026-07-23 07:00:32.01505+00
2a213f3a-392b-42be-b761-db1d795778c4	demo-association	3165d54f-5c5b-4593-9bf3-cf83b4f985f8	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 07:00:34.171086+00
dc6c2cdc-3b2b-4326-9d90-03ea82d959db	demo-association	33783cd7-f782-4a86-b1a5-183af16e597c	USER	Hello	0	\N	{}	2026-07-23 07:09:20.4017+00
dfc6358b-31ec-476e-b7c0-67b8369c72fe	demo-association	33783cd7-f782-4a86-b1a5-183af16e597c	ASSISTANT	Hello. How can I assist you with your association management needs today? Do you need help with member management, finances, events, documents, or something else?	64	llama-3.3-70b-versatile	{}	2026-07-23 07:09:22.261482+00
75736bd3-812e-41af-9560-0ef9ca2d767e	demo-association	5ed5ee9a-7106-43a0-9ed5-3eb46104a6e4	USER	Hi	0	\N	{}	2026-07-23 07:12:24.890529+00
a87229e5-7067-4708-affc-65a9895518ea	demo-association	5ed5ee9a-7106-43a0-9ed5-3eb46104a6e4	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 07:12:26.233393+00
ae2a276d-c9e4-40e6-bd18-f32503ba5e2c	demo-association	1354a6ed-65e8-4675-9e4e-655fe4853a92	USER	Hi	0	\N	{}	2026-07-23 07:22:56.084952+00
f73d583d-ea1c-4d31-8a8a-502d52afe208	demo-association	1354a6ed-65e8-4675-9e4e-655fe4853a92	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 07:22:57.371439+00
a62f22c9-3010-44f5-9653-1f52f82ea805	demo-association	53bddd61-b73b-4c55-b73c-41c89ffe03c3	USER	What is the total revenue?	0	\N	{}	2026-07-23 07:23:15.393479+00
21822a04-5cbf-4edc-8501-1b70e7558f96	demo-association	53bddd61-b73b-4c55-b73c-41c89ffe03c3	ASSISTANT	I don't have access to the current financial data. To get the total revenue, I recommend checking the finance section of the association management system or contacting the finance team for the most up-to-date information.	82	llama-3.3-70b-versatile	{}	2026-07-23 07:23:15.767332+00
488c4ef6-fd86-44bb-8377-325590daf905	demo-association	83d70b08-73f6-40f6-b867-9211f2facc98	USER	Hello	0	\N	{}	2026-07-23 09:06:04.811371+00
3e68571e-9acd-44df-838e-1d7584c42cee	demo-association	83d70b08-73f6-40f6-b867-9211f2facc98	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 09:06:05.89531+00
afd31c21-9395-4abe-b199-b1d95a675b2a	demo-association	1ee8727c-4b75-4b75-9338-7d0a8452bca3	USER	Hello	0	\N	{}	2026-07-23 09:16:07.945978+00
b2afb8b6-31de-41ed-a9cb-b71c838ef3d1	demo-association	1ee8727c-4b75-4b75-9338-7d0a8452bca3	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 09:16:09.078688+00
a1f9059f-81e6-472e-83d0-6dcde21215c9	demo-association	b4a393e3-7068-43f4-ab3c-410bd6527d49	USER	Hello	0	\N	{}	2026-07-23 09:21:32.552767+00
a031d84d-6d3d-4e34-b464-6ddcdc418541	demo-association	b4a393e3-7068-43f4-ab3c-410bd6527d49	ASSISTANT	Hello. How can I assist you with your association management today? Do you have questions about member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 09:21:32.839849+00
e5fe336a-280c-4d6e-b6b9-5dd818c42d81	demo-association	58d29901-b332-4e2f-9c0f-274acc3907b2	USER	hi	0	\N	{}	2026-07-23 11:09:17.088988+00
2b6a9bfd-b9ef-4914-9ee8-811a539b91f3	demo-association	58d29901-b332-4e2f-9c0f-274acc3907b2	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 11:09:18.433517+00
506fac1d-7b13-4b53-9dde-c97a3626b176	demo-association	dd201f06-66c6-4c14-9218-9a7a8978147d	USER	what can you d for me	0	\N	{}	2026-07-23 11:09:27.90736+00
7f9096db-7cf0-41f0-aa47-a47698ee6b2e	demo-association	dd201f06-66c6-4c14-9218-9a7a8978147d	ASSISTANT	I can assist you with various tasks related to association management, such as:\n\n1. **Member Management**: Help with member registration, profile updates, and membership tracking.\n2. **Finances**: Assist with financial transactions, invoicing, and payment tracking.\n3. **Events**: Aid with event planning, registration, and scheduling.\n4. **Documents**: Help with document storage, sharing, and management.\n5. **Association Operations**: Provide support with general association management, such as reporting and analytics.\n\nPlease let me know what specific task or issue you need help with, and I'll do my best to assist you.	137	llama-3.3-70b-versatile	{}	2026-07-23 11:09:28.507338+00
4c6122a3-5f11-4c88-a070-c9cb397a7396	demo-association	1de02b7a-8a3d-4e0b-bfbc-f77bc26d035b	USER	hello	0	\N	{}	2026-07-23 11:35:02.27185+00
062d4990-175f-402c-a6fe-b7b40fc5b89a	demo-association	1de02b7a-8a3d-4e0b-bfbc-f77bc26d035b	ASSISTANT	Hello. How can I assist you with your association management needs today? Do you need help with member management, finances, events, documents, or something else?	64	llama-3.3-70b-versatile	{}	2026-07-23 11:35:02.610609+00
559e033d-5f52-41f8-b8c9-26a3c9a0f451	demo-association	5f1a335d-aeb7-465c-8192-05657638c635	USER	hello	0	\N	{}	2026-07-23 11:40:07.999756+00
fd7b0940-e524-4e5f-829f-3f7f48d7c6e6	demo-association	5f1a335d-aeb7-465c-8192-05657638c635	ASSISTANT	Hello. How can I assist you with your association management today? Do you need help with member management, finances, events, documents, or something else?	63	llama-3.3-70b-versatile	{}	2026-07-23 11:40:09.380487+00
97ada910-6786-4b9f-8e91-180986884c20	demo-association	5a87d871-537b-40fe-b65d-c3d0334eda33	USER	What modules does this system have?	0	\N	{}	2026-07-23 11:42:56.149313+00
629389bb-ddf4-471a-a8f9-7059a372e56f	demo-association	5a87d871-537b-40fe-b65d-c3d0334eda33	ASSISTANT	This association management system has the following modules:\n\n1. **Member Management**: to manage member profiles, contacts, and relationships.\n2. **Finances**: to handle financial transactions, invoicing, and accounting.\n3. **Events**: to organize and manage events, conferences, and meetings.\n4. **Documents**: to store, share, and manage association documents and files.\n5. **Operations**: to manage the day-to-day activities and tasks of the association.\n\nThese modules are designed to help associations streamline their operations and improve member engagement. If you have any specific questions about a module, feel free to ask.	136	llama-3.3-70b-versatile	{}	2026-07-23 11:42:56.798732+00
26f31452-6e6f-48a9-a9e7-bca25e65f7c0	demo-association	5d2fefff-f430-4fee-96f7-80052d57c417	USER	Analyze event attendancehi	0	\N	{}	2026-07-23 11:45:14.511874+00
39b3e4a2-e5cf-46b0-aab8-e57b81614c52	demo-association	5d2fefff-f430-4fee-96f7-80052d57c417	ASSISTANT	To analyze event attendance, I'll need more information. Can you please provide the following details:\n\n1. Which event would you like to analyze?\n2. What type of attendance data is available (e.g., number of attendees, registration numbers, demographics)?\n3. Are there any specific metrics or insights you're looking to gain from the analysis (e.g., attendance trends, member engagement, revenue impact)?\n\nWithout this information, I can suggest general steps for analyzing event attendance:\n\n1. **Track registration and attendance numbers**: Monitor the number of attendees who registered for the event and those who actually attended.\n2. **Categorize attendees**: Break down attendees by member type, demographics, or other relevant categories to identify trends and patterns.\n3. **Analyze attendance trends**: Compare attendance numbers to previous events or industry benchmarks to identify areas for improvement.\n4. **Evaluate event feedback**: Collect feedback from attendees to understand their experiences and identify areas for improvement.\n\nIf you provide more specific details, I'd be happy to help you analyze event attendance.	205	llama-3.3-70b-versatile	{}	2026-07-23 11:45:15.52139+00
9add8c55-6603-4ae8-90c9-81d8d0de2918	demo-association	bb17a65d-7795-4333-9437-dc45fa9a7355	USER	How many members do we have?	0	\N	{}	2026-07-23 17:55:17.101549+00
f0c4c8e5-1584-4fa7-b161-6111959974bd	demo-association	bb17a65d-7795-4333-9437-dc45fa9a7355	ASSISTANT	I don't have access to real-time data. To get the most up-to-date information on the number of members, I recommend checking the association management system's member database or contacting the system administrator.	81	llama-3.3-70b-versatile	{}	2026-07-23 17:55:17.62304+00
d2e0f6ab-794a-4c13-a74b-fdf86d43e4b7	demo-association	f6adc519-989a-47cd-95c5-eccb35cbf7bb	USER	How many members do we have?	0	\N	{}	2026-07-23 18:02:26.06943+00
22c8af52-5ced-4223-ad7d-4bf36ba1367f	demo-association	f6adc519-989a-47cd-95c5-eccb35cbf7bb	ASSISTANT	We currently have a total of **65 members**, with **44** of them being active.	320	llama-3.3-70b-versatile	{}	2026-07-23 18:02:27.343256+00
15b2dea1-baed-47d2-b867-b03d845a1f01	demo-association	e1f46c3d-0ebe-43a0-b2aa-45c587e7a006	USER	How many members do we have?	0	\N	{}	2026-07-23 18:04:01.132137+00
024429c5-278b-40a0-b2d6-4ff0a78cbfd7	demo-association	e1f46c3d-0ebe-43a0-b2aa-45c587e7a006	ASSISTANT	We currently have a total of **65 members**, with **44** of them being active.	320	llama-3.3-70b-versatile	{}	2026-07-23 18:04:04.180763+00
719953fc-dbc6-4133-8ba3-3be45b7ba7c1	demo-association	5dd12175-8240-4ff2-a8c8-be14b354372e	USER	How many members?	0	\N	{}	2026-07-23 18:04:56.334513+00
df4e586f-4492-46b9-bfa0-8824fa951943	demo-association	5dd12175-8240-4ff2-a8c8-be14b354372e	ASSISTANT	We currently have a total of **66 members**, with **45** being active.	312	llama-3.3-70b-versatile	{}	2026-07-23 18:04:57.411916+00
994d7932-672d-4331-9ed3-ee76bff6e84b	demo-association	6deac212-482d-4e74-99e5-f4fe16c1cbdf	USER	Hello, how are you?	0	\N	{}	2026-07-23 18:15:39.592924+00
9358b487-174e-44d7-b57e-060fa4d7c890	demo-association	6deac212-482d-4e74-99e5-f4fe16c1cbdf	ASSISTANT	**Hello!** I'm doing well, thanks for asking. I'm ready to help you with any questions or tasks you have regarding the Association Management System (AMS). How can I assist you today?	333	llama-3.3-70b-versatile	{}	2026-07-23 18:15:40.064433+00
a2e2d5cc-9fe5-423b-bd95-8c70918e7179	demo-association	0b330251-89ed-4c44-abc5-92ab1c793c99	USER	Hello	0	\N	{}	2026-07-23 18:19:02.077428+00
0573fad0-7e4e-47e3-9d7f-dc8dc293fc8e	demo-association	0b330251-89ed-4c44-abc5-92ab1c793c99	ASSISTANT	**Welcome to AssocHub**. I'm here to assist you with any questions or tasks related to the Association Management System. What can I help you with today?	322	llama-3.3-70b-versatile	{}	2026-07-23 18:19:02.451568+00
f1d9a5c9-54ea-4b16-abab-ddffda3f84e3	demo-association	qa-test	USER	What database does this app use?	0	\N	{}	2026-07-23 18:49:47.715834+00
d54f0e73-8c40-4d8d-8e0e-03da0c92c4d6	demo-association	qa-test	ASSISTANT	I don't have the specific information on the database management system used by the AssocHub application. The data I have access to is the **Current Association Data**, which includes details such as member counts, events, documents, and financial information. If you need assistance with any of the **System Modules**, I can provide step-by-step instructions or insights based on the available data. \n\nFor example, I can help with:\n* Managing members and their status\n* Creating and tracking finances, invoices, and expenses\n* Organizing events and documents\n* Conducting elections and surveys\n\nPlease let me know how I can assist you further.	407	llama-3.3-70b-versatile	{}	2026-07-23 18:49:48.635703+00
84e390c9-0faf-4a74-acb8-d623ccc4d0e9	demo-association	browser-qa	USER	What database does this app use? — from browser test	0	\N	{}	2026-07-23 18:50:47.718009+00
45c271b9-1221-420a-bee0-0b962481760a	demo-association	browser-qa	ASSISTANT	I don't have the specific information about the database used by this Association Management System (AMS). However, I can suggest checking the **System Information** or **About** page within the app for more details. Alternatively, you can contact the system administrator or support team for more information on the database used. \n\nIf you need help with any of the modules or features within the app, I'd be happy to assist you with that. Just let me know what you're trying to accomplish, and I'll do my best to guide you through it. \n\nHere are the modules I can help you with:\n1. **Members**\n2. **Finances**\n3. **Events**\n4. **Documents**\n5. **Elections**\n6. **Workflows**\n7. **Communications**\n8. **Analytics**\n9. **AI Features**	433	llama-3.3-70b-versatile	{}	2026-07-23 18:50:48.584458+00
94c340ae-bd44-4f20-8a2c-74dd641f97e9	demo-association	034a4419-05dd-4c55-811e-08722f6d6e7b	USER	How many members do we have?	0	\N	{}	2026-07-24 07:13:13.108828+00
6d9ce0be-68b8-4620-a642-82b0098d3f21	demo-association	034a4419-05dd-4c55-811e-08722f6d6e7b	ASSISTANT	We currently have a total of **76 members**, with **55** of them being **Active**.	320	llama-3.3-70b-versatile	{}	2026-07-24 07:13:16.807413+00
7b292d84-2d38-45ca-baf8-a61154e59106	demo-association	2122265f-ed6c-4466-a004-34266e124dc4	USER	List all members with their email	0	\N	{}	2026-07-24 07:13:45.542577+00
f7386af8-3ba0-4859-a5a7-79811cfb43e3	demo-association	2122265f-ed6c-4466-a004-34266e124dc4	ASSISTANT	I don't have direct access to the individual member data, including their emails. However, I can guide you on how to access this information using the **Members** module.\n\nTo view all members with their emails, follow these steps:\n\n1. **Navigate to the Members Module**: Click on the "Members" tab in the navigation menu.\n2. **Member List**: You will see a list of all members. Click on the "View All Members" button if you don't see the list immediately.\n3. **Filter and Sort**: Use the filter and sort options to organize the member list as needed. You can filter by status (active, pending, etc.) and sort by name, email, or other criteria.\n4. **Export Member List**: If you need to download the list of members with their emails, look for an "Export" or "Download" option. This will allow you to save the list in a CSV or Excel file.\n\nPlease note that you need the necessary permissions to access the member list and their contact information. If you're unsure about how to perform these steps or need further assistance, you can contact your association's administrator for help.	492	llama-3.3-70b-versatile	{}	2026-07-24 07:13:46.69637+00
2f47e759-1477-4b9f-a674-4fcc30bdf554	demo-association	230a96b4-3ea2-4bc7-8a5d-266d38cd17df	USER	How many active members?	0	\N	{}	2026-07-24 07:17:43.508148+00
b791565f-cb08-4c00-b80c-6a0f4c2a1cba	demo-association	230a96b4-3ea2-4bc7-8a5d-266d38cd17df	ASSISTANT	We have **55** active members out of a total of 76 members.	314	llama-3.3-70b-versatile	{}	2026-07-24 07:17:45.190517+00
8d5ff686-58b7-48f7-86d6-d28516b70775	demo-association	5d70a28a-3bd7-4324-bbdb-46d039d033a4	USER	Hello, how many members?	0	\N	{}	2026-07-24 07:18:52.290597+00
a37c0b92-01cf-4cdf-b609-0645eb7d7b3f	demo-association	5d70a28a-3bd7-4324-bbdb-46d039d033a4	ASSISTANT	We currently have a total of **76 members**, with **55** of them being active.	316	llama-3.3-70b-versatile	{}	2026-07-24 07:18:52.709069+00
7d9c9e3c-2439-4430-a0be-58295c11ef22	demo-association	91793935-1806-4cb6-b83a-2f4009e3fa57	USER	Hello, how many members do we have?	0	\N	{}	2026-07-24 08:14:18.914792+00
f65e3983-24d1-4a87-806a-7971e01d45fa	demo-association	91793935-1806-4cb6-b83a-2f4009e3fa57	ASSISTANT	I couldn't generate a response. Please try again.	316	llama-3.3-70b-versatile	{}	2026-07-24 08:14:20.009041+00
7966194f-b348-4d7a-8fe4-42b67d414fe7	demo-association	1afaccce-c725-4714-9292-4ce7c0a73e92	USER	How many members does the association have?	0	\N	{}	2026-07-24 08:15:35.860603+00
9e5fe15e-17d0-4acb-8668-f7521992fed6	demo-association	1afaccce-c725-4714-9292-4ce7c0a73e92	ASSISTANT	The association has **78** members in total. Out of these, **57** are active members.	322	llama-3.3-70b-versatile	{}	2026-07-24 08:15:38.461068+00
e67ff046-8816-45ec-af04-8d4301c9dfab	demo-association	e87bdae4-5445-44d0-b074-077ce1a63050	USER	How many members does the association have?	0	\N	{}	2026-07-24 08:48:37.74265+00
466e76c7-ad0b-4956-b430-3f17e54e9335	demo-association	e87bdae4-5445-44d0-b074-077ce1a63050	ASSISTANT	I couldn't generate a response. Please try again.	316	llama-3.3-70b-versatile	{}	2026-07-24 08:48:40.319681+00
ebc1d5ba-4670-4e75-b5ed-04c3dd756dd9	demo-association	d5c04b51-472d-4558-93d1-a78f61358385	USER	What events are coming up?	0	\N	{}	2026-07-24 08:48:40.837505+00
c3b0d9d4-6144-43af-9b85-15e6e3743800	demo-association	d5c04b51-472d-4558-93d1-a78f61358385	ASSISTANT	I couldn't generate a response. Please try again.	312	llama-3.3-70b-versatile	{}	2026-07-24 08:48:43.213629+00
35ee13aa-f716-44a5-84f3-5768fc0722b2	demo-association	202f30ea-cc0c-404d-a366-20a3cbb3ab52	USER	How many members does the association have?	0	\N	{}	2026-07-24 08:50:50.0954+00
a98c45ee-3449-4f85-a57b-802656f96f58	demo-association	202f30ea-cc0c-404d-a366-20a3cbb3ab52	ASSISTANT	The association currently has **78** total members. Out of these, **57** are active members.	322	llama-3.1-8b-instant	{}	2026-07-24 08:50:53.192794+00
f0d8b5d6-7912-4bb3-a583-3fb0bd21010a	demo-association	3391220d-8f8d-4cc0-b768-0d1b82889561	USER	What events do we have?	0	\N	{}	2026-07-24 08:51:08.825101+00
8e3cfe13-2e07-4b39-bdf9-e401937c7b7c	demo-association	3391220d-8f8d-4cc0-b768-0d1b82889561	ASSISTANT	You can view the list of events in the **Events** module.\n\n**Current Events:**\nWe have 17 events scheduled.\n\nTo view the list of events, you can log in to the AssocHub system and navigate to the **Events** module. From there, you can see the event title, date, time, location, and description.\n\nWould you like me to guide you on how to view the events in the system?	371	llama-3.1-8b-instant	{}	2026-07-24 08:51:11.754079+00
b95db333-8ab8-4a25-861c-c79fbe74d90f	demo-association	0772d79e-3363-412d-970e-9c1a7b3dec3c	USER	Give me a financial summary	0	\N	{}	2026-07-24 08:51:11.858555+00
7bfce3e9-c437-46ed-8487-fa6f4c60caa7	demo-association	0772d79e-3363-412d-970e-9c1a7b3dec3c	ASSISTANT	**Financial Summary**\n\nBased on the current data, here's a summary of the association's financial situation:\n\n* **Total Revenue**: $6,255.00\n* **Total Paid**: $3,485.00 (55.5% of total revenue)\n* **Outstanding**: $2,770.00 (44.5% of total revenue)\n* **Total Expenses**: 31 (not explicitly stated, but implied to be part of the budget or finances module)\n\n**Key Takeaways**\n\n* The association has collected 55.5% of its total revenue.\n* There is a significant outstanding amount of $2,770.00.\n* The exact breakdown of expenses is not clear, but there are 31 expenses recorded.\n\n**Recommendation**\n\nTo get a clearer picture of the association's finances, I recommend checking the **Finances** module for a detailed breakdown of expenses and outstanding amounts. You can also review the **Budgets** module to see how the association is tracking its spending.	433	llama-3.1-8b-instant	{}	2026-07-24 08:51:12.807157+00
8218f50a-ba19-46cf-9356-f94a0acf0463	demo-association	test-123	USER	Hello	0	\N	{}	2026-07-24 08:55:35.811087+00
5651eafc-47ce-44f1-94bf-9659a8c486eb	demo-association	test-123	ASSISTANT	Welcome to AssocHub. I'm here to help you with any questions or tasks related to managing your association. What would you like to know or accomplish today?	323	llama-3.1-8b-instant	{}	2026-07-24 08:55:37.368825+00
ea0a7844-03d0-486f-b919-d7c9fdcb1b15	demo-association	83231f05-fa2f-471d-bdc7-c5ec95745fd1	USER	Show membership stats	0	\N	{}	2026-07-24 09:16:49.546825+00
a3fcae0d-2f04-4229-85c2-1cce64bd8ae5	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	USER	Generate a meeting minutes document	0	\N	{}	2026-07-24 09:28:19.484113+00
d8dbc6f8-743f-4282-8298-4fde6ba51a2d	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	USER	hi	0	\N	{}	2026-07-24 09:29:10.02451+00
6c48f68e-a674-4ad7-9a82-e5bb059424b7	demo-association	83231f05-fa2f-471d-bdc7-c5ec95745fd1	ASSISTANT	**Membership Stats**\n\n* **Total Members:** 78\n* **Active Members:** 57\n* **Inactive Members:** 21\n* **Pending Members:** 0\n* **Suspended Members:** 0\n* **Lapsed Members:** 0\n* **Cancelled Members:** 0\n\nYou can view more detailed membership data, including member group and tag assignments, by going to the **Members** module. From there, you can filter and sort the list to view specific information about your members.	365	llama-3.1-8b-instant	{}	2026-07-24 09:16:54.809681+00
88377818-ee16-48d7-8b18-79f94e86056a	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	USER	what model are you currently running	0	\N	{}	2026-07-24 09:28:34.094022+00
49bd833b-0dde-4682-8c4e-9ce506af6daa	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	ASSISTANT	I am currently running the **Documents** module.	602	llama-3.1-8b-instant	{}	2026-07-24 09:28:34.803299+00
e1750213-1375-4f50-b73f-4a5775ca40bf	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	USER	what can you do for me	0	\N	{}	2026-07-24 09:29:01.880597+00
fe2a0e5f-4f00-4804-aed1-1607c9c52116	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	ASSISTANT	You're currently in the **Documents** module. Based on the data I have access to, here are some things I can do for you:\n\n1. **Create a new document**: I can guide you through the process of creating a new document, including selecting a template, adding content, and saving the document.\n2. **Generate a meeting minutes document**: I can provide you with a template and guide you on how to fill it out, including the event details, attendees, agenda, discussions, actions, and decisions.\n3. **Help you with document formatting**: I can assist you with formatting your document, including changing font styles, adding headings, and inserting images or other multimedia elements.\n4. **Provide document templates**: I can share some pre-built document templates that you can use as a starting point for your meeting minutes document.\n5. **Help you upload and share documents**: I can guide you on how to upload your document to the system and share it with association members or stakeholders.\n\nPlease let me know which of these options you're interested in, and I'll be happy to assist you further!	808	llama-3.1-8b-instant	{}	2026-07-24 09:29:03.572283+00
a4aeae3b-5852-4862-9906-ff775a446692	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	ASSISTANT	**Meeting Minutes Document**\n\nSince there are no events created in the **Events** module, I'll guide you on how to create one. Please follow these steps:\n\n### Step 1: Create an Event\n\n1. Go to the **Events** module.\n2. Click on **Create Event**.\n3. Fill in the required details: Event Title, Description, Event Date, Event Time, Location, and Registration information (if applicable).\n4. Click **Save** to create the event.\n\nOnce the event is created, you can generate a meeting minutes document in a Word document or PDF format using the **Documents** module. Here's how:\n\n### Step 2: Create a Meeting Minutes Document\n\n1. Go to the **Documents** module.\n2. Click on **Create Document**.\n3. Select the event you created in Step 1 as the related event.\n4. Choose a document template or create a new one from scratch.\n5. Fill in the meeting minutes details, including attendees, agenda, discussions, actions, and decisions.\n6. Add any supporting documents or attachments as needed.\n7. Click **Save** to create the meeting minutes document.\n\nYou can also use the **Documents** module to upload and share the meeting minutes document with association members or stakeholders.\n\n**Template:**\n\nYou can use the following template to create your meeting minutes document:\n\n**Meeting Minutes: [Event Name]**\n\n* Date: [Event Date]\n* Time: [Event Time]\n* Location: [Event Location]\n* Attendees: [List of attendees]\n* Agenda:\n\t+ [Topic 1]\n\t+ [Topic 2]\n\t+ [Topic 3]\n* Discussions:\n\t+ [Summary of discussions]\n* Actions and Decisions:\n\t+ [List of actions and decisions]\n* Next Steps:\n\t+ [List of next steps and responsibilities]\n\nNote: You can customize the template to fit your association's needs.\n\nI hope this helps! If you need further assistance, please let me know.	588	llama-3.1-8b-instant	{}	2026-07-24 09:28:20.771435+00
6fd24f28-fc84-4099-b98e-9eb38071355c	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	USER	what model are you using?	0	\N	{}	2026-07-24 09:28:51.162979+00
914083cc-a497-4601-acea-8821daeeeb34	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	ASSISTANT	I'm currently using the **Documents** module, specifically the default template for a meeting minutes document.	621	llama-3.1-8b-instant	{}	2026-07-24 09:28:52.561332+00
e64d1a9f-ca4d-4d6c-8474-f9a20aa4412c	mohsin-123	b897403e-cde0-40e6-9841-a1cebcdc884a	ASSISTANT	It looks like we're starting fresh! What can I help you with today? Are you looking to create a document, generate meeting minutes, or maybe something else?	831	llama-3.1-8b-instant	{}	2026-07-24 09:29:12.058756+00
9118f5a7-8146-4ec2-8537-1111d3b993e6	demo-association	f884de5e-f959-420f-a517-535037dfad5b	USER	hii	0	\N	{}	2026-07-25 07:32:40.439897+00
dce53047-7189-4132-b562-584d532c2714	demo-association	f884de5e-f959-420f-a517-535037dfad5b	ASSISTANT	Welcome to AssocHub!\n\nWhat would you like to know or do today? Would you like to check on your association's finances, events, or perhaps see a list of all your members? I'm here to help!	331	llama-3.1-8b-instant	{}	2026-07-25 07:32:43.428897+00
313b54d0-0c8d-464d-ab96-12bbbc63b41c	demo-association	f884de5e-f959-420f-a517-535037dfad5b	USER	what can you do	0	\N	{}	2026-07-25 07:32:51.325412+00
3e287386-b800-4afc-9e7a-ddfb176bebe8	demo-association	f884de5e-f959-420f-a517-535037dfad5b	ASSISTANT	You can ask me to:\n\n1. **View/Manage** data using the following modules:\n\t* **Members**: View, add, edit members, check status, manage groups and tags, track member notes.\n\t* **Finances**: View invoices, budgets, expenses, dues, payments, and get a dashboard with revenue overview.\n\t* **Events**: Create, manage events with sessions, speakers, registrations, and feedback.\n\t* **Documents**: Upload, share, version control, and organize documents by category.\n\t* **Elections**: Create elections with positions, nominations, voting, and results.\n\t* **Workflows**: Automate tasks with triggers and conditions, and run workflow instances.\n2. **Analyze** data using:\n\t* **Analytics**: Get KPIs, insights, custom dashboards, reports, and exports.\n3. **Perform tasks** using:\n\t* **Finances**: Create/send invoices, mark invoices as paid, submit/approve expenses, track spending, and manage dues.\n\t* **Communications**: Send announcements, email campaigns, use templates, send notifications, and create surveys.\n4. **Get insights** using:\n\t* **AI Features**: Get churn prediction, anomaly detection, semantic search, and document generation.\n\nLet me know what you'd like to do!	495	llama-3.1-8b-instant	{}	2026-07-25 07:32:53.745773+00
cb0db90d-0eca-40e8-948e-d3ff60df1a90	demo-association	4027aa45-cbb6-494f-81eb-2e1e8588482a	USER	How many members do we have?	0	\N	{}	2026-07-25 07:34:38.601435+00
91be9bf7-3ac6-421e-9061-7c6e04816170	demo-association	4027aa45-cbb6-494f-81eb-2e1e8588482a	ASSISTANT	According to our data, you have a total of **82** members. Out of these, **61** are active members.	324	llama-3.1-8b-instant	{}	2026-07-25 07:34:39.854644+00
717d3b86-5d87-4b8c-b832-a446bb9010a7	demo-association	f3e6c5f3-a1ad-480a-aaf5-7497f7e2346f	USER	What events are coming up?	0	\N	{}	2026-07-27 06:35:22.79555+00
30b03e03-43b7-4b10-842e-6cae42a5298b	demo-association	f3e6c5f3-a1ad-480a-aaf5-7497f7e2346f	ASSISTANT	You can find a list of upcoming events in the **Events** module. To see the upcoming events, follow these steps:\n\n1. Go to the **Modules** dropdown menu at the top left corner of the screen.\n2. Click on **Events**.\n3. On the **Events** page, click on the **Upcoming** tab.\n\nAlternatively, you can use the AI search feature by typing "upcoming events" in the search bar. This will give you a quick overview of the upcoming events, along with the date, time, and location.\n\nYou can also see the events in a calendar view by clicking on the **Calendar** tab in the **Events** module.\n\nThere are currently 5 upcoming events scheduled, with the next one being on April 15th, 2023.	423	llama-3.1-8b-instant	{}	2026-07-27 06:35:30.989616+00
930db695-5ca6-4626-a932-220a5e0fe3e4	demo-association	f3e6c5f3-a1ad-480a-aaf5-7497f7e2346f	USER	okk	0	\N	{}	2026-07-27 06:35:36.609423+00
524cec92-31b1-4038-970c-be1eb96ad1ff	demo-association	f3e6c5f3-a1ad-480a-aaf5-7497f7e2346f	ASSISTANT	It seems like you're trying to respond with a brief acknowledgement. However, I'll be happy to provide a more detailed response.\n\nIf you'd like to know more information about the upcoming events, such as the event titles, descriptions, or the number of attendees, you can refer to the **Events** module. To access this information, follow the steps I provided earlier or use the AI search feature.\n\nIf you have any specific questions about the upcoming events or would like to know more about a particular event, please feel free to ask, and I'll do my best to assist you!	519	llama-3.1-8b-instant	{}	2026-07-27 06:35:40.894385+00
a1c58258-fa48-482d-916c-bc2f919f49a4	Munazzah-association	96860800-7a80-42e4-9be0-0dd2691bcea5	USER	Check election status	0	\N	{}	2026-07-27 11:23:59.047995+00
03b840db-07c5-4ff1-98fe-4c41419dbde5	Munazzah-association	96860800-7a80-42e4-9be0-0dd2691bcea5	ASSISTANT	Since there are **0** elections in the association, there is no election to check the status of.	317	llama-3.1-8b-instant	{}	2026-07-27 11:24:03.419511+00
\.


--
-- Data for Name: ai_embeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_embeddings (id, tenant_id, content_id, content_type, text_chunk, embedding, metadata_json, created_at) FROM stdin;
d3c230aa-845e-4aae-b8da-aa4962549678	demo-association	test-001	DOCUMENT	Annual membership dues are due January 1st	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.17677669,0,0,0,0,0,0,0,0,0,0,0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.17677669,0,0,0,0,0,-0.17677669,0,0,0,0,0,0,0,0.17677669,0,0.17677669,0,0,0,0,0,0,0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.17677669,0,-0.17677669,0,0,0,0,0,0,0.17677669,0,0,0,0,0,0,0,0.17677669,0,0,-0.17677669,0,0,0,0,0,0,0,-0.35355338,0,-0.17677669,0,0,0,0,0,0,0,0,0,0,0.17677669,0,0,0,0,0.17677669,0,0,0,0,0,0,0,0,0,0,0,-0.17677669,-0.17677669,0,0,0,0,0,0,-0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.35355338,0,0,0,0,-0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.17677669,0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,0.17677669,0,0,0,0,0,0,-0.17677669,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]	{}	2026-07-23 01:53:09.623221+00
b39e33a9-fceb-4431-99bf-3e38ea7ecec6	demo-association	test-002	DOCUMENT	Membership dues are due Jan 1st	[0,0,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0.19611613,0,0.19611613,0,0,0,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0,0.19611613,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.39223227,0,0,0,0,-0.19611613,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]	{}	2026-07-23 02:11:05.449629+00
a9cfede9-e916-410f-9173-3b6bcbd3e649	demo-association	test-003	DOCUMENT	Membership dues are due Jan 1st	[0,0,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0.19611613,0,0.19611613,0,0,0,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0,0.19611613,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.39223227,0,0,0,0,-0.19611613,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]	{}	2026-07-23 02:23:21.519063+00
80547177-6e74-45ad-8a75-1599d9009eea	demo-association	test-004	DOCUMENT	Membership dues are due Jan 1st	[0,0,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0.19611613,0,0.19611613,0,0,0,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0,0.19611613,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.39223227,0,0,0,0,-0.19611613,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,-0.19611613,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]	{}	2026-07-23 02:35:27.041781+00
\.


--
-- Data for Name: ai_insights; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_insights (id, tenant_id, title, summary, insight_type, source_data, confidence, is_read, is_dismissed, action_url, created_at) FROM stdin;
\.


--
-- Data for Name: ai_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_models (id, tenant_id, name, version, model_type, description, config, metrics, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_predictions (id, tenant_id, model_id, entity_id, entity_type, prediction_type, confidence, result, created_at) FROM stdin;
d3c9b29b-bfee-4e25-8b20-5a4b7c156d32	demo-association	\N	8ce0d21d-1b3b-483c-8f66-eccda38568ee	member	CHURN_RISK	0.55	{"risk_score": 0.4, "risk_factors": ["Never logged in", "Moderate engagement score (0.3)"], "recommendation": "Low-moderate risk. Include in regular engagement communications."}	2026-07-28 07:14:30.8979+00
1d6271b1-da74-43f6-9c47-96f326298351	demo-association	\N	8ce0d21d-1b3b-483c-8f66-eccda38568ee	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["No login for 9999 days", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:16.322656+00
0ccf56e5-dad0-476d-a91d-5e46cdc19724	demo-association	\N	8ce0d21d-1b3b-483c-8f66-eccda38568ee	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["No login for 9999 days", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:28.923261+00
8d23d2c5-28b9-44d7-9954-b5e587ed845b	demo-association	\N	8ce0d21d-1b3b-483c-8f66-eccda38568ee	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["No login for 9999 days", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:45.298472+00
c28220ef-6268-48ba-90e4-9bc00c0b6600	demo-association	\N	00612962-5402-4b5a-b3cb-bbded7ebe8fe	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["Last login 121 days ago", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:45.403756+00
650dc5c2-58d1-4589-9e79-56b19fd6db4d	demo-association	\N	43fe70dd-856a-4ee8-a1da-83950adbfed1	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["Last login 148 days ago", "Membership is lapsed", "Low engagement score (0.14)", "No event registrations", "No group memberships"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:45.509497+00
d9e2bb76-02ac-447c-b09b-6c2ea6376a80	demo-association	\N	a292507b-3092-455c-817e-a5ddfc22c22e	member	CHURN_RISK	0.85	{"risk_score": 0.9999, "risk_level": "critical", "risk_factors": ["No login for 321 days", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:45.617762+00
ad288cd1-708a-4040-8bef-bd8909683ffb	demo-association	\N	866a7d12-67ad-4027-ba28-9c56838f720e	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["Last login 98 days ago", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:16:45.718079+00
eb744623-3cc1-4f90-a6a0-dd4a205ecc89	demo-association	\N	8ce0d21d-1b3b-483c-8f66-eccda38568ee	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["No login for 9999 days", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:18:59.12476+00
e336464f-7487-412d-a0be-973970f284ca	demo-association	\N	00612962-5402-4b5a-b3cb-bbded7ebe8fe	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["Last login 121 days ago", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:18:59.225527+00
f0f59640-224e-4f51-870f-cc57279dc49a	demo-association	\N	43fe70dd-856a-4ee8-a1da-83950adbfed1	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["Last login 148 days ago", "Membership is lapsed", "Low engagement score (0.14)", "No event registrations", "No group memberships"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:18:59.318717+00
6f42f64e-02c3-40bd-95dc-45f9ab5ea6af	demo-association	\N	a292507b-3092-455c-817e-a5ddfc22c22e	member	CHURN_RISK	0.85	{"risk_score": 0.9999, "risk_level": "critical", "risk_factors": ["No login for 321 days", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:18:59.40532+00
569a4c14-9037-47bb-a045-5a623e0e8a5c	demo-association	\N	866a7d12-67ad-4027-ba28-9c56838f720e	member	CHURN_RISK	0.85	{"risk_score": 1.0, "risk_level": "critical", "risk_factors": ["Last login 98 days ago", "Membership is lapsed", "No event registrations", "No payment in 9999 days"], "recommendation": "Immediate outreach recommended. Consider personalized retention offer or one-on-one meeting.", "method": "ml"}	2026-07-28 07:18:59.492973+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
2aa34958cdde
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, tenant_id, title, slug, summary, content, image_url, audience, target_group_ids, status, is_pinned, allow_comments, published_at, expires_at, view_count, created_by, created_at, updated_at) FROM stdin;
016a76dd-93fc-4d6f-ac78-4cb7db59fa05	demo-association	Test Announcement 1fb4	test-announcement-1fb4	\N	This is a test announcement.	\N	all	[]	DRAFT	f	t	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:32:13.265755+00	2026-07-23 05:32:13.265759+00
d11a70a9-3979-49b6-a85e-cda5e3ecf615	demo-association	Test 4002	test-4002	\N	Test	\N	all	[]	DRAFT	f	t	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:34:30.813464+00	2026-07-23 05:34:30.813472+00
5ce835db-9dc3-474f-9f30-137ef7195283	demo-association	QA Test Announcement	qa-test-announcement	\N	Test announcement content	\N	all	[]	PUBLISHED	f	t	2026-07-23 06:47:33.673956+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:47:33.602138+00	2026-07-23 06:47:33.676116+00
ebfcf21a-77b7-4292-ab9a-57a20dc629bc	demo-association	QA Test Announcement	qa-test-announcement	\N	Test announcement content	\N	all	[]	PUBLISHED	f	t	2026-07-23 06:48:28.028362+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:48:27.970432+00	2026-07-23 06:48:28.028893+00
12cd1275-f9bc-40c8-b4eb-98954c4a7d22	demo-association	QA Ann	qa-ann	\N	Test	\N	all	[]	PUBLISHED	f	t	2026-07-23 06:50:39.217555+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:50:39.148303+00	2026-07-23 06:50:39.217933+00
95ccc78a-eb9d-401c-b42e-d45341a2448b	demo-association	QA	qa	\N	Test	\N	all	[]	PUBLISHED	f	t	2026-07-23 07:00:28.877584+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:00:28.82+00	2026-07-23 07:00:28.878629+00
7028dc07-4f4f-4782-97d2-dd0545d64a9b	demo-association	QA Test Announcement	qa-test-announcement	\N	Test announcement content	\N	all	[]	PUBLISHED	f	t	2026-07-23 07:09:16.603085+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:09:16.520145+00	2026-07-23 07:09:16.607634+00
aef63060-fea3-4e4d-a3d3-3c80f9b8c181	demo-association	QA	qa	\N	Test	\N	all	[]	PUBLISHED	f	t	2026-07-23 07:12:22.161477+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:12:22.104707+00	2026-07-23 07:12:22.162575+00
9623d50d-6c95-45bb-88d2-45fdb5c03ff8	demo-association	QA	qa	\N	Test	\N	all	[]	PUBLISHED	f	t	2026-07-23 07:22:53.680658+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:22:53.608589+00	2026-07-23 07:22:53.683718+00
f245fb25-78f5-4488-aa8c-3e9984e23065	demo-association	Audit Announcement	audit-announcement	\N	Test content	\N	all	[]	DRAFT	f	t	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:06:01.947834+00	2026-07-23 09:06:01.94784+00
cfe85eae-ab98-455c-a0d4-303b7db562f3	demo-association	Audit Announcement	audit-announcement	\N	Test content	\N	all	[]	DRAFT	f	t	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:16:05.731731+00	2026-07-23 09:16:05.731737+00
c753578b-6635-4fc6-a5d4-5a3621678b93	demo-association	Audit Announcement	audit-announcement	\N	Test content	\N	all	[]	PUBLISHED	f	t	2026-07-23 11:06:23.314429+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:21:31.8442+00	2026-07-23 11:06:23.323157+00
f17196a7-0833-49c2-bca0-b1e4dab08e96	demo-association	Test 8581	test-8581	\N	Test	\N	all	[]	PUBLISHED	f	t	2026-07-24 07:06:28.289731+00	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:36:10.970465+00	2026-07-24 07:06:28.295115+00
7bcbb0d0-3576-4193-b782-f7059e628e77	demo-association	Annual Conference 2026 — Early Bird Registration Now Open!	annual-conference-2026-—-early-bird-registration-now-open!	Summary: Annual Conference 2026 — Early Bird Registration Now Open!	We are pleased to share: Annual Conference 2026 — Early Bird Registration Now Open!.	\N	all_members	\N	PUBLISHED	t	t	2026-05-05 07:39:28.372431+00	\N	147	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.372431+00	2026-07-24 07:39:28.372431+00
201fe2cb-5b63-417f-865d-37c2b415a331	demo-association	New Member Benefits: Free Access to Online Learning Platform	new-member-benefits-free-access-to-online-learning-platform	Summary: New Member Benefits: Free Access to Online Learning Platform	We are pleased to share: New Member Benefits: Free Access to Online Learning Platform.	\N	all_members	\N	PUBLISHED	f	t	2026-07-17 07:39:28.376412+00	\N	18	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.376412+00	2026-07-24 07:39:28.376412+00
2b8a1fd1-e529-4bd3-9f2d-3b35b4fb1f08	demo-association	Board Election Results — Congratulations to Our New Officers!	board-election-results-—-congratulations-to-our-new-officers	Summary: Board Election Results — Congratulations to Our New Officers!	We are pleased to share: Board Election Results — Congratulations to Our New Officers!.	\N	all_members	\N	PUBLISHED	t	t	2026-02-16 07:39:28.379324+00	\N	55	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.379324+00	2026-07-24 07:39:28.379324+00
1d074d0b-5f25-4644-ad6b-161da5cbed53	demo-association	Spring Networking Event — Save the Date!	spring-networking-event-—-save-the-date!	Summary: Spring Networking Event — Save the Date!	We are pleased to share: Spring Networking Event — Save the Date!.	\N	all_members	\N	PUBLISHED	f	t	2026-03-01 07:39:28.382069+00	\N	164	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.382069+00	2026-07-24 07:39:28.382069+00
3ea74c02-4309-4577-8b3f-5b648a9c0939	demo-association	Updated Bylaws Available for Review	updated-bylaws-available-for-review	Summary: Updated Bylaws Available for Review	We are pleased to share: Updated Bylaws Available for Review.	\N	all_members	\N	PUBLISHED	t	t	2026-03-22 07:39:28.385083+00	\N	174	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.385083+00	2026-07-24 07:39:28.385083+00
9c9897d5-7b1c-43d3-8fc8-03fd47b1bd83	demo-association	Welcome to Our 15 New Members This Quarter!	welcome-to-our-15-new-members-this-quarter!	Summary: Welcome to Our 15 New Members This Quarter!	We are pleased to share: Welcome to Our 15 New Members This Quarter!.	\N	all_members	\N	PUBLISHED	f	t	2026-05-14 07:39:28.38793+00	\N	125	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.38793+00	2026-07-24 07:39:28.38793+00
8d3502b2-2cfd-49df-bf1c-c8e6bfa360c4	demo-association	Financial Report Q4 2025 Now Available	financial-report-q4-2025-now-available	Summary: Financial Report Q4 2025 Now Available	We are pleased to share: Financial Report Q4 2025 Now Available.	\N	all_members	\N	PUBLISHED	f	t	2026-05-13 07:39:28.390712+00	\N	177	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.390712+00	2026-07-24 07:39:28.390712+00
f0dcb1f0-d610-437a-a8b7-40d3d67a272a	demo-association	Call for Nominations: 2026 Board of Directors	call-for-nominations-2026-board-of-directors	Summary: Call for Nominations: 2026 Board of Directors	We are pleased to share: Call for Nominations: 2026 Board of Directors.	\N	all_members	\N	PUBLISHED	t	t	2026-02-09 07:39:28.393546+00	\N	18	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.393546+00	2026-07-24 07:39:28.393546+00
3a7d7e17-1949-4f3f-a7dd-6d911cdb6abe	demo-association	Holiday Office Hours — Dec 24 to Jan 2	holiday-office-hours-—-dec-24-to-jan-2	Summary: Holiday Office Hours — Dec 24 to Jan 2	We are pleased to share: Holiday Office Hours — Dec 24 to Jan 2.	\N	all_members	\N	PUBLISHED	f	t	2026-02-13 07:39:28.396509+00	\N	120	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.396509+00	2026-07-24 07:39:28.396509+00
5e22cf63-5650-43f4-ba9f-11679ca44706	demo-association	Partnership Opportunity with TechCorp International	partnership-opportunity-with-techcorp-international	Summary: Partnership Opportunity with TechCorp International	We are pleased to share: Partnership Opportunity with TechCorp International.	\N	all_members	\N	PUBLISHED	f	t	2026-05-29 07:39:28.399245+00	\N	120	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.399245+00	2026-07-24 07:39:28.399245+00
cd3ae2d2-f817-4d02-a83c-dc876a870f32	demo-association	Volunteer Spotlight: Thank You to Our Amazing Team!	volunteer-spotlight-thank-you-to-our-amazing-team!	Summary: Volunteer Spotlight: Thank You to Our Amazing Team!	We are pleased to share: Volunteer Spotlight: Thank You to Our Amazing Team!.	\N	all_members	\N	PUBLISHED	f	t	2026-01-29 07:39:28.40178+00	\N	177	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.40178+00	2026-07-24 07:39:28.40178+00
b8e461f0-739f-4a34-8ca4-e5d8e6ef69d7	demo-association	System Maintenance Scheduled for Saturday	system-maintenance-scheduled-for-saturday	Summary: System Maintenance Scheduled for Saturday	We are pleased to share: System Maintenance Scheduled for Saturday.	\N	all_members	\N	PUBLISHED	f	t	2026-06-19 07:39:28.405063+00	\N	153	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.405063+00	2026-07-24 07:39:28.405063+00
8acbb368-a30c-40c3-aaa1-17a48d9cb613	demo-association	Strategic Plan 2026-2028: Your Input Needed	strategic-plan-2026-2028-your-input-needed	Summary: Strategic Plan 2026-2028: Your Input Needed	We are pleased to share: Strategic Plan 2026-2028: Your Input Needed.	\N	all_members	\N	DRAFT	t	t	2026-02-28 07:39:28.407693+00	\N	66	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:39:28.407693+00	2026-07-24 07:39:28.407693+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, tenant_id, user_id, action, resource_type, resource_id, details, ip_address, created_at) FROM stdin;
ed720120-0ce4-4438-9b27-42a5b8c37aa5	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	member.created	document	5f7fb6f1-a2d2-4cae-84d1-4c97f1e04d1c	{"action": "created"}	192.168.1.87	2026-06-25 06:39:28.494728+00
358bb22d-78a1-44de-b212-c230c388cd54	demo-association	9a402f41-9334-45eb-b110-1f0ddc2e462b	event.published	event	c502fdef-9b19-435c-aa58-a8914d314843	{"action": "created"}	192.168.1.179	2026-07-12 20:39:28.500494+00
cc69f513-aa30-43f0-acdd-d37462c73d60	demo-association	9a402f41-9334-45eb-b110-1f0ddc2e462b	payment.received	user	5709812b-63f7-41d5-aa85-bbda96e2ea50	{"action": "created"}	192.168.1.37	2026-07-16 17:39:28.503537+00
f88b79af-49f1-4075-ab8b-c2845faa331f	demo-association	e1de858a-5ead-4819-9afa-15f13c9b4cae	document.uploaded	invoice	3196e15b-8646-4259-90d9-61df6a2b4d91	{"action": "created"}	192.168.1.135	2026-07-06 16:39:28.506303+00
a626a248-e2ac-476f-ac66-aae55eab8039	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	document.uploaded	document	6789a549-8245-4c30-b3ee-456aa28d4244	{"action": "created"}	192.168.1.9	2026-07-23 03:39:28.509141+00
849b46e6-12aa-43c0-9fe3-6a61af46504d	demo-association	e0183dea-662d-40e4-882d-b39c325de8b6	payment.received	user	b1c8c9b8-846d-404c-a38d-e552439499ae	{"action": "created"}	192.168.1.250	2026-07-21 12:39:28.51242+00
2cdc2ac2-230e-48e7-bea3-7e126963f1ec	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	document.uploaded	document	3d460d4a-c0d1-4f37-b02a-6910a23c2845	{"action": "created"}	192.168.1.112	2026-06-28 17:39:28.515901+00
eb372309-4d01-44fa-9ccc-f762eb09103b	demo-association	891637f1-d5f7-4c13-aaae-281c12a8ebb3	event.published	user	1dcdbc05-4bb0-417d-a02c-efa143a1bdd4	{"action": "created"}	192.168.1.187	2026-07-22 00:39:28.51886+00
135f8578-b976-4b1b-a494-17b9ad43f463	demo-association	891637f1-d5f7-4c13-aaae-281c12a8ebb3	member.created	user	508d1603-d076-459f-954e-07ea474f5728	{"action": "created"}	192.168.1.207	2026-06-25 15:39:28.521737+00
65d4b676-6fa0-457d-b1e9-284933c0d83d	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	payment.received	invoice	799e6d24-895f-4625-a382-87c1250e4412	{"action": "created"}	192.168.1.203	2026-07-19 18:39:28.524778+00
a05189d1-ab47-4562-b961-593577984a63	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	event.published	document	322a44e8-068e-4cb0-a856-d13e12863360	{"action": "created"}	192.168.1.15	2026-07-13 15:39:28.527748+00
c88341cd-4d20-435c-bd35-ccd370bf68f4	demo-association	91edd7a9-bbf0-429d-8107-3b16f01e9f45	document.uploaded	invoice	179197db-5623-4b5f-8d9d-0c702acfa9ba	{"action": "created"}	192.168.1.122	2026-07-19 07:39:28.530667+00
59cfca9f-c9fe-4f55-acb0-6a0065a044d4	demo-association	fa500bbe-2af8-483b-885a-94ec0de08cff	invoice.created	user	6058a7d3-001d-4876-b8c9-fc8245f7e80b	{"action": "created"}	192.168.1.4	2026-07-11 14:39:28.533613+00
dd69e7b3-32bb-48bd-ac6b-263b30e1bed4	demo-association	79befe4c-d588-4c8c-a572-3e11ad023df9	payment.received	user	0c3a3f71-91e8-454c-a5ce-fbb768ab93af	{"action": "created"}	192.168.1.183	2026-06-29 00:39:28.536613+00
58155a03-b830-400d-ac85-750e99517d62	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	member.created	user	9b4586f3-940e-4d4f-a86f-35067cc69da9	{"action": "created"}	192.168.1.8	2026-07-04 14:39:28.539502+00
7d8dde54-3ed0-4c5f-8ec0-360603ffecb2	demo-association	4cc69459-a224-4a8c-8aba-4fdc5f03fdac	member.created	user	d3411a85-4adc-415c-849e-60c01da37242	{"action": "created"}	192.168.1.174	2026-07-07 11:39:28.542442+00
e2218284-2317-48e0-ad80-d7758a9deced	demo-association	04d3cb9b-c2e7-4e0b-80d3-06f1b0d88c34	payment.received	document	ab3baac6-7f05-4011-a5f1-cad035603036	{"action": "created"}	192.168.1.23	2026-07-13 04:39:28.54528+00
b3a4824a-4a72-429e-8246-27d498dade6e	demo-association	9a402f41-9334-45eb-b110-1f0ddc2e462b	payment.received	invoice	ac000359-42ec-4fc6-929b-7b6c6c3aa77c	{"action": "created"}	192.168.1.127	2026-07-12 00:39:28.548331+00
6b08da58-281a-4b76-9088-1f34fda78932	demo-association	fa500bbe-2af8-483b-885a-94ec0de08cff	member.created	document	bbb28b85-7c47-4952-b75a-ef1ec0259cb7	{"action": "created"}	192.168.1.220	2026-06-30 10:39:28.551091+00
02438ae9-d780-49fb-9ff3-6be6764c7d33	demo-association	9a402f41-9334-45eb-b110-1f0ddc2e462b	event.published	invoice	c10868da-f365-40d3-a938-548d2236c638	{"action": "created"}	192.168.1.192	2026-07-08 02:39:28.553953+00
7995d2e1-3016-444b-97ac-43c4ba3877ef	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	member.created	invoice	5f8e4ea8-d902-4087-9bae-d98b2a779347	{"action": "created"}	192.168.1.103	2026-07-13 07:39:28.556809+00
e82c068d-616d-499b-80b9-3de6a8f94900	demo-association	891637f1-d5f7-4c13-aaae-281c12a8ebb3	payment.received	user	aa03f76a-9d14-400c-a8fd-027ddfd07e28	{"action": "created"}	192.168.1.46	2026-06-29 18:39:28.559703+00
c592e6d8-3858-497a-88d7-d7aec6b11fcd	demo-association	657834d2-176f-45f2-b1e0-1cbc6c21e971	payment.received	user	e276a076-0fd7-4199-a1b6-8d6d344afe40	{"action": "created"}	192.168.1.97	2026-07-16 22:39:28.562639+00
605fa206-069d-4932-bab3-70b71a72e27c	demo-association	36dcfd7d-3d69-41a9-adb9-1f58dbe4bab6	payment.received	invoice	558140c9-2465-4c68-b2f4-f05bdf88639f	{"action": "created"}	192.168.1.246	2026-07-23 16:39:28.565551+00
0226afec-3142-46d4-a109-c5b4cfd9f91b	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	payment.received	user	c6473315-ed74-4944-939f-8e13b01f1872	{"action": "created"}	192.168.1.156	2026-07-02 14:39:28.56845+00
8b80fd31-7040-4af3-b76e-5bd9c6d97b19	demo-association	a52a155a-5eb0-4954-b25f-e8ea38d4a698	member.created	event	91450b8e-455a-4012-b96a-15e7e42dea3b	{"action": "created"}	192.168.1.130	2026-06-29 07:39:28.571498+00
e76168b3-e618-4b78-b97c-d11767653583	demo-association	f948d4f9-1d71-471b-b82a-bfed60c3fbf5	invoice.created	user	4df25ab9-4997-48f5-9755-ce809316c57f	{"action": "created"}	192.168.1.145	2026-07-20 05:39:28.574359+00
d3ae5b9e-56de-4b9d-8a60-2784ca8f6ce9	demo-association	81ab7a4d-0a0c-4804-84c4-a746fc332378	event.published	event	9458ad59-6718-4222-b7e9-6fc653230922	{"action": "created"}	192.168.1.134	2026-07-09 15:39:28.577274+00
ed835f1c-5c78-4008-ae1f-1b0c5459f11d	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	document.uploaded	user	f391517d-3d54-4f3f-92d7-effc9d7602ea	{"action": "created"}	192.168.1.248	2026-07-04 06:39:28.580057+00
95409e81-0bd9-4ec4-ad1d-8483d69c7190	demo-association	04d3cb9b-c2e7-4e0b-80d3-06f1b0d88c34	document.uploaded	document	003e2608-02ec-4fbb-8419-470f86073370	{"action": "created"}	192.168.1.234	2026-07-21 01:39:28.582927+00
72f6d750-a6d9-4125-bc78-503dcdfbb770	demo-association	78f737e7-bbc4-495a-9b7a-b636452622cb	event.published	event	3f6a9759-04aa-4723-897c-65d9f480f519	{"action": "created"}	192.168.1.253	2026-07-09 18:39:28.585789+00
c5efdd0e-1603-4a83-a0c2-9eca6f55f27a	demo-association	e1de858a-5ead-4819-9afa-15f13c9b4cae	member.created	invoice	8fdee4e6-0d04-4ea3-ae5a-1219cfc6fde2	{"action": "created"}	192.168.1.67	2026-06-29 06:39:28.588684+00
bb892403-8639-437c-a51d-29475eaf3f5f	demo-association	79befe4c-d588-4c8c-a572-3e11ad023df9	member.created	event	9330b740-340c-4213-861f-73aa6200d6d9	{"action": "created"}	192.168.1.212	2026-07-21 08:39:28.591594+00
009169af-d026-47af-9e29-2bb5bac4e292	demo-association	6557e96a-2274-4b64-9f89-dccd750107e4	payment.received	invoice	e913f4d7-5455-434e-b2a3-3ca85a4d4d67	{"action": "created"}	192.168.1.102	2026-06-29 09:39:28.594556+00
7304e35c-5e42-4c44-abf8-30b6e73f2dbc	demo-association	9a402f41-9334-45eb-b110-1f0ddc2e462b	event.published	event	bbd2dcb0-ef25-42fc-aeb9-df6514d19412	{"action": "created"}	192.168.1.203	2026-06-26 11:39:28.604564+00
ac5ed46b-166d-4612-8e3c-719cdf2c6418	demo-association	66d4ca5e-6f2f-4c9a-a53a-dcf03cbaffe8	member.created	event	e96a0e47-9efa-4fd6-92eb-e0fdcb0c7741	{"action": "created"}	192.168.1.112	2026-07-17 04:39:28.60791+00
df7897e0-ac34-49e7-adc9-cf9cd51857cd	demo-association	e1de858a-5ead-4819-9afa-15f13c9b4cae	payment.received	user	dca5a37d-7473-40ca-b211-138e3e8aa73b	{"action": "created"}	192.168.1.29	2026-07-22 21:39:28.611585+00
0c8085c7-ebe2-4f9b-a8c1-7e7791b15b5a	demo-association	bb090ff1-bd1e-4092-8940-57fc2f94deab	payment.received	invoice	ab9a48c3-7b4d-46f4-b769-ae30eb9469bf	{"action": "created"}	192.168.1.138	2026-07-20 07:39:28.614702+00
6389f06d-4833-4aef-a5ba-6438fda27a23	demo-association	f948d4f9-1d71-471b-b82a-bfed60c3fbf5	document.uploaded	invoice	41455818-f856-4509-9c97-fe4c9fda59b7	{"action": "created"}	192.168.1.7	2026-07-01 15:39:28.617693+00
99da5c51-dfcf-4644-afe9-99d03b9ef668	demo-association	66d4ca5e-6f2f-4c9a-a53a-dcf03cbaffe8	invoice.created	document	eccfa23b-4349-4abb-843b-a2f3b7334bc1	{"action": "created"}	192.168.1.102	2026-07-19 12:39:28.620629+00
adcd574e-c15c-46b5-b988-681df8252cfe	demo-association	2722b0b7-cea9-4008-83bd-4b5c357259a4	document.uploaded	invoice	37216f73-c335-4e61-9921-74d241593942	{"action": "created"}	192.168.1.42	2026-06-24 15:39:28.623457+00
15fdbe5a-254f-41d9-a672-68cd1018bc3f	demo-association	4e83d2ac-6e7a-44f8-a795-f94da6150631	payment.received	document	8edf945c-9463-451f-8261-961ec6f1f976	{"action": "created"}	192.168.1.240	2026-07-02 01:39:28.627247+00
345f9014-d952-4359-8442-c8571bdcec8e	demo-association	36dcfd7d-3d69-41a9-adb9-1f58dbe4bab6	member.created	document	d5d6e617-8897-428a-afaf-69e599e7e0b8	{"action": "created"}	192.168.1.173	2026-07-01 08:39:28.630849+00
e8056af9-3577-4f45-871e-df7bb2ecd175	demo-association	66d4ca5e-6f2f-4c9a-a53a-dcf03cbaffe8	event.published	user	bf6f117e-ecd8-4649-a7cd-afd5979bfbf3	{"action": "created"}	192.168.1.13	2026-06-30 02:39:28.634132+00
f816b7a1-8029-444d-bf86-1c5e23eb540c	demo-association	657834d2-176f-45f2-b1e0-1cbc6c21e971	invoice.created	invoice	72cce32b-1cb9-47e2-9913-e2b89c8dca29	{"action": "created"}	192.168.1.109	2026-06-27 00:39:28.637338+00
f32b0daa-9db3-46df-aa0d-b714116a4881	demo-association	e0183dea-662d-40e4-882d-b39c325de8b6	document.uploaded	invoice	e2865cb0-e97d-4bd8-956c-26b45a9b7260	{"action": "created"}	192.168.1.176	2026-07-01 22:39:28.639835+00
83b4866b-b845-461d-915f-1be948fa534c	demo-association	9e8cc2d7-69ff-4f3b-9382-5b80b6922370	payment.received	document	e7e6fb9b-30d9-4553-b2ab-5316a1c0f387	{"action": "created"}	192.168.1.199	2026-07-10 07:39:28.642446+00
2541ad3b-4722-40d5-9d11-f0077f5bd973	demo-association	891637f1-d5f7-4c13-aaae-281c12a8ebb3	payment.received	document	0fe1ea3d-0a8f-41e7-8e9a-e7b8e7b2de07	{"action": "created"}	192.168.1.73	2026-07-17 09:39:28.645032+00
7ef1907d-4921-4da0-9699-9e998320c894	demo-association	79befe4c-d588-4c8c-a572-3e11ad023df9	invoice.created	user	38f18db3-bbf9-4a71-8906-6b2d9ae12ede	{"action": "created"}	192.168.1.68	2026-06-26 01:39:28.647723+00
d912da7f-d7df-4e26-b347-b9d1a764ee4b	demo-association	6557e96a-2274-4b64-9f89-dccd750107e4	member.created	invoice	59fcb212-72c5-4f53-87c8-60128b3a69ca	{"action": "created"}	192.168.1.60	2026-07-20 15:39:28.650366+00
62db285f-b4f1-4642-88d6-a3a60142a73b	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	69.12.84.135	2026-07-25 09:48:23.460565+00
10631dab-2b15-4e7d-a3b7-659ae83539d5	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	69.12.84.135	2026-07-25 09:48:35.647107+00
b158cfa4-df81-4fb3-a203-93314a9d8e8f	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 10:35:18.196103+00
9145c24c-cfb4-4536-afb0-7cb43bfcb1aa	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 10:35:27.419945+00
8fafb970-58aa-40dc-a5b0-7cbb26504266	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 10:46:04.516002+00
aa86d388-de0b-4882-b0e3-7a7471a9edef	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 10:46:20.069109+00
e7b7b9b9-a445-443f-828d-b483772c545f	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	154.81.253.185	2026-07-25 11:16:20.22848+00
700730ca-1cd8-45f6-886e-4c1afc93963f	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:23:32.251711+00
07d7b7ec-bf01-45d7-ba28-5d4ff52c27cc	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:24:04.724345+00
ff0a88b3-250f-4705-8b3d-eb9024248dd3	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:24:22.442823+00
d10d5226-a7b3-4da0-8679-19d1c7f9c003	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:24:32.472079+00
07a1d411-e14a-4b38-b306-61c6f00041a8	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:24:52.004847+00
cfdc7cb9-3634-4001-92db-c79aad56c2e9	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:25:13.494279+00
f8ca51dc-77de-4287-b309-c522034e42a2	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-25 11:26:46.004401+00
49520b38-e35b-4ade-9799-1c57a2d87501	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	154.81.250.96	2026-07-27 06:22:05.21398+00
6e49c67d-bcdc-48c6-8788-eb8677a06ae4	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 07:54:33.717281+00
e9600343-c20d-4e5f-9490-06913c2cd63d	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 07:57:41.285747+00
a49ca6fc-b67d-4a92-8de2-01113c9d4df5	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 07:58:31.25332+00
bf05b2e3-10d8-4260-a3cf-9ae5d15ddf37	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	create	invoice	2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf	{"total": 323.67, "member_id": "c8ada24d-1dec-4f9e-b0f7-3be95ebabf14"}	\N	2026-07-27 08:00:40.661675+00
c025febe-fc3f-4cdd-a60d-6d3e9b52bafe	demo-association	578d9f44-a84d-4f27-9753-28ccc685287b	register	auth	578d9f44-a84d-4f27-9753-28ccc685287b	{"email": "testuser@example.com"}	127.0.0.1	2026-07-27 08:05:31.609619+00
7938202e-47b8-47f2-a4cb-1ebcde667c0a	demo-association	6557e96a-2274-4b64-9f89-dccd750107e4	login	auth	6557e96a-2274-4b64-9f89-dccd750107e4	{}	127.0.0.1	2026-07-27 08:06:30.795721+00
7d7a4054-d53c-490c-8baf-2c93c04dc54a	demo-association	6557e96a-2274-4b64-9f89-dccd750107e4	download	invoice_pdf	2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf	{}	\N	2026-07-27 08:09:17.985184+00
15eb2643-75e7-4b34-8fd7-a60037ef0018	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 08:34:18.240421+00
690e13f9-45fd-46bb-8770-7dfea4513de4	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	create	invoice	e60a7ec2-2b32-47b4-a8ad-427c862a9744	{"total": 431.92, "member_id": "3f5dc381-5b1d-499f-9a1f-9a4be253fde5"}	\N	2026-07-27 08:35:24.249411+00
67edbc0b-18db-4d50-b52a-c0049cf9752c	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	download	invoice_pdf	e60a7ec2-2b32-47b4-a8ad-427c862a9744	{}	\N	2026-07-27 08:35:40.720455+00
149f4edf-c928-4325-b028-660d94cd0353	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	154.81.250.96	2026-07-27 08:39:28.247989+00
306b09bc-eb5c-467f-956a-2c379562706e	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	record	payment	fe5d874e-030f-4e9d-9e40-4e8126f5b3ce	{"amount": 431.92, "invoice_id": "e60a7ec2-2b32-47b4-a8ad-427c862a9744"}	\N	2026-07-27 08:40:07.265234+00
b54885e8-558d-4148-ac1f-fa36c70a3ec3	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	send	invoice	2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf	{}	\N	2026-07-27 08:41:21.532517+00
261035cd-6c17-481c-a16d-31c7b6e77493	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	send	invoice	2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf	{}	\N	2026-07-27 08:41:26.12284+00
319f40e6-dcd0-474a-af39-fb2352285eac	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	send	invoice	2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf	{}	\N	2026-07-27 08:41:33.858492+00
95e94408-a2ec-4cb9-bf9f-944e1fdd192c	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 08:51:45.337837+00
a256de82-4201-4e7b-b0cd-95cebd12a4b9	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	create	invoice	8f029a0c-f544-48d6-9775-1b084bd24994	{"total": 323.67, "member_id": "3f5dc381-5b1d-499f-9a1f-9a4be253fde5"}	\N	2026-07-27 08:53:28.783339+00
6ccf6163-49e8-4e6a-a7d7-d1cefc345ae2	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	download	invoice_pdf	8f029a0c-f544-48d6-9775-1b084bd24994	{}	\N	2026-07-27 08:53:46.052663+00
d305236f-e9b7-40d0-a159-305b7b91f331	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	154.81.250.96	2026-07-27 09:02:57.732768+00
69e11b0a-6549-46d5-a8e4-0b42efa13700	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 09:05:11.427538+00
5aa35024-5c59-4cab-9d35-0a921faaac6e	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 09:05:18.412714+00
05ba2673-e179-45f7-a6f2-bfa7734f2c26	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 09:05:30.556296+00
2d3f4db0-63aa-4f39-92d5-9cf99b5f04f7	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	download	invoice_pdf	e60a7ec2-2b32-47b4-a8ad-427c862a9744	{}	\N	2026-07-27 09:35:58.876419+00
cf99264a-9591-43ee-a5c3-a550c3f22ca5	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	download	invoice_pdf	e60a7ec2-2b32-47b4-a8ad-427c862a9744	{}	\N	2026-07-27 09:36:00.224845+00
f4059a70-a7e8-4d4a-98d2-ba5387b11fd3	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	download	invoice_pdf	e60a7ec2-2b32-47b4-a8ad-427c862a9744	{}	\N	2026-07-27 09:51:29.779909+00
4e8de8ba-9924-40f9-88ae-9bb08e8448eb	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	download	invoice_pdf	e60a7ec2-2b32-47b4-a8ad-427c862a9744	{}	\N	2026-07-27 09:51:30.962868+00
3ffdfd08-909d-4a7d-aa3b-431fd82ff2e7	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 09:56:58.926074+00
281aae73-3718-408b-a81d-89ed0e47134b	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 09:57:12.174726+00
45a04394-d0dd-447a-a452-1a1ecb1661b9	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 09:57:23.045385+00
e56f7503-0eb5-443d-acef-a9e98e8e02b4	Munazzah-association	ad3e0ece-dd9d-401a-91d4-44b920337714	register	auth	ad3e0ece-dd9d-401a-91d4-44b920337714	{"email": "munazzah184@gmail.com"}	154.81.250.96	2026-07-27 11:22:35.834826+00
7ec42275-8c22-43bb-8265-d607fed20922	Munazzah-association	ad3e0ece-dd9d-401a-91d4-44b920337714	login	auth	ad3e0ece-dd9d-401a-91d4-44b920337714	{}	154.81.250.96	2026-07-27 11:23:36.420235+00
59427f7f-f3c6-4516-b218-4d2290fe4d75	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 12:27:55.313151+00
9dc55293-d357-4598-ac87-9468eee26f6d	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 13:06:45.686881+00
6653a1da-3e7b-4f3f-b769-04ab77fe2abb	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 13:07:14.918284+00
4a4ab23d-5ce6-4c5f-8c71-4b34117929ac	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 13:08:14.892612+00
8ba98a5d-ff58-4527-8561-463fcd560b6c	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	login	auth	ca028c51-23b8-4ae5-b945-2ce378a92ab3	{}	127.0.0.1	2026-07-27 13:11:03.442592+00
\.


--
-- Data for Name: ballots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ballots (id, election_id, voter_id, tenant_id, votes, abstentions, verification_code, ip_address, cast_at) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, tenant_id, name, description, category, period, planned_amount, actual_amount, currency, start_date, end_date, alert_threshold, is_active, created_at, updated_at) FROM stdin;
4c8eca74-94d3-4a03-bfec-33ad1bbb7a3a	demo-association	Test Budget	\N	OPERATIONS	ANNUAL	1000.00	0.00	USD	2026-01-01 00:00:00+00	2026-12-31 23:59:59+00	80.00	t	2026-07-23 09:21:19.038102+00	2026-07-23 09:21:19.038108+00
b0e4c870-630e-401f-a19e-2f4c138acf0f	demo-association	Test	\N	OPERATIONS	MONTHLY	1000.00	0.00	USD	2026-01-01 00:00:00+00	2026-12-31 23:59:59+00	80.00	t	2026-07-23 09:22:25.295752+00	2026-07-23 09:22:25.295757+00
9137f972-ec5c-4a7c-a697-be93c89079f6	demo-association	E2E Test Budget	\N	OPERATIONS	MONTHLY	5000.00	0.00	USD	2026-08-01 00:00:00+00	2026-08-31 00:00:00+00	80.00	t	2026-07-23 17:55:14.378057+00	2026-07-23 17:55:14.378065+00
38ef7d36-229d-4c39-a97c-efc406e2e62c	demo-association	Marketing & Outreach	Budget allocation for marketing & outreach	MARKETING	ANNUAL	25000.00	18750.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.885267+00	2026-07-24 07:38:00.885267+00
6bb241b1-b3da-42a3-ad8a-69e82e33ee66	demo-association	Events & Hospitality	Budget allocation for events & hospitality	EVENTS	ANNUAL	45000.00	32100.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.888903+00	2026-07-24 07:38:00.888903+00
f6929320-8a11-4f75-92be-43448505bde9	demo-association	Technology & Infrastructure	Budget allocation for technology & infrastructure	TECHNOLOGY	ANNUAL	15000.00	9800.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.891336+00	2026-07-24 07:38:00.891336+00
aa8474b9-f23e-4a97-ad85-90133db985bd	demo-association	Administrative Operations	Budget allocation for administrative operations	OPERATIONS	ANNUAL	12000.00	11200.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.893686+00	2026-07-24 07:38:00.893686+00
54b02c1e-7466-4a37-9b03-8ae2df76eb9d	demo-association	Member Benefits & Programs	Budget allocation for member benefits & programs	OTHER	ANNUAL	30000.00	22500.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.896315+00	2026-07-24 07:38:00.896315+00
83cb72dc-b148-4bbd-892d-888ddefed207	demo-association	Professional Development	Budget allocation for professional development	OTHER	ANNUAL	20000.00	8600.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.898979+00	2026-07-24 07:38:00.898979+00
361f3d5f-6065-46d8-8118-b2aff9041d5c	demo-association	Community Outreach	Budget allocation for community outreach	MARKETING	ANNUAL	10000.00	6400.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:38:00.901439+00	2026-07-24 07:38:00.901439+00
e0badf09-30a2-4f45-885d-c7a523d55caa	demo-association	Marketing & Outreach	Budget: Marketing & Outreach	MARKETING	ANNUAL	25000.00	18750.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.291553+00	2026-07-24 07:39:28.291553+00
e85a5f95-5335-4f59-8250-f4c878d09026	demo-association	Events & Hospitality	Budget: Events & Hospitality	EVENTS	ANNUAL	45000.00	32100.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.29577+00	2026-07-24 07:39:28.29577+00
edd13977-68f6-4084-9b4d-264fd19f5806	demo-association	Technology & Infrastructure	Budget: Technology & Infrastructure	TECHNOLOGY	ANNUAL	15000.00	9800.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.298983+00	2026-07-24 07:39:28.298983+00
f17fed55-9c67-4ceb-aecf-42429b3d62db	demo-association	Administrative Operations	Budget: Administrative Operations	OPERATIONS	ANNUAL	12000.00	11200.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.302077+00	2026-07-24 07:39:28.302077+00
7a825835-e966-4655-a4e7-3b6997509498	demo-association	Member Benefits & Programs	Budget: Member Benefits & Programs	OTHER	ANNUAL	30000.00	22500.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.304964+00	2026-07-24 07:39:28.304964+00
f8190f8d-82e0-48c8-97d4-b0ea14e958c2	demo-association	Professional Development	Budget: Professional Development	OTHER	ANNUAL	20000.00	8600.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.307816+00	2026-07-24 07:39:28.307816+00
9ece43e9-e56c-403c-b2d5-6a7144d5f0e1	demo-association	Community Outreach	Budget: Community Outreach	MARKETING	ANNUAL	10000.00	6400.00	USD	2026-01-01 00:00:00+00	2026-12-31 00:00:00+00	0.85	t	2026-07-24 07:39:28.310672+00	2026-07-24 07:39:28.310672+00
\.


--
-- Data for Name: dashboard_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_widgets (id, dashboard_id, tenant_id, name, widget_type, data_source, config, "position", created_at) FROM stdin;
15df5d79-514a-4581-9d85-4cd0e210be33	039d3372-cd46-4ae1-97c8-c41c93263d00	demo-association	john	TABLE	members	{}	{}	2026-07-23 11:02:17.235958+00
\.


--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboards (id, tenant_id, name, description, is_default, is_public, layout, created_by, created_at, updated_at) FROM stdin;
039d3372-cd46-4ae1-97c8-c41c93263d00	demo-association	Test Dashboard f9ae	A test dashboard	f	f	{}	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:32:13.746187+00	2026-07-23 05:32:13.746192+00
b708ba58-5efe-43a8-9bd3-57b949808783	demo-association	Test 49b9	\N	f	f	{}	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:34:31.038533+00	2026-07-23 05:34:31.038537+00
1068d6e2-71f2-47cb-a90f-92601adc1d5d	demo-association	Test e7eb	\N	f	f	{}	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:36:11.382055+00	2026-07-23 05:36:11.382059+00
\.


--
-- Data for Name: data_exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_exports (id, tenant_id, name, export_type, format, filters, status, file_url, file_size, record_count, requested_by, completed_at, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: discount_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_codes (id, tenant_id, code, discount_type, value, max_uses, used_count, valid_from, valid_to, applicable_to, is_active, created_by, created_at, updated_at) FROM stdin;
a17369e6-ad0a-450a-b5b8-437ee385253b	demo-association	TEST10	PERCENTAGE	10.00	\N	0	\N	\N	BOTH	t	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-27 13:11:05.628893+00	2026-07-27 13:11:05.628904+00
\.


--
-- Data for Name: document_activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_activities (id, document_id, member_id, tenant_id, action, details, created_at) FROM stdin;
53f00548-575f-4e59-a1a6-6c361422040c	24c7a34a-9fcc-4de5-ba64-dc76454d934a	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 02:35:25.02345+00
3d7549c7-1ab1-4f9f-adc5-ce3ba36704d0	5786d8f4-3a29-484c-b9b4-cb5ee6529476	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 07:00:29.334036+00
9ab8716c-6f6d-450e-9a25-fe15a851eebd	6c30608a-a1f4-4fcd-b010-320fdeddf0a3	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 07:12:22.59809+00
c0c0640f-0c19-4616-a87b-75e4bfff9fea	ca8bc130-defa-4de3-a965-3167033b1cca	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 07:22:54.109509+00
0b6b8181-542f-44d3-9ecd-f5489b3f9cba	6aaa9d5d-8126-4e8a-be96-7fe4b0a79675	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 09:06:01.306146+00
2abaa871-9e4c-4e71-a4e6-a4a12679473f	6b87bf8d-8a81-4b4b-a19f-e1c6c82827b5	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 09:16:05.303363+00
82a3615e-dc5d-446f-994c-10fa241877b1	d1d5b436-ef5a-4e22-980d-b4cf1d770b41	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 09:21:31.56192+00
67eb6397-5f72-4363-b4cf-6e548fcf24de	1338a06a-2f0b-4508-8f6c-c81d35db9198	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 11:08:11.874601+00
de48b45f-3e4c-4b5e-b1da-c331d7c630c6	1338a06a-2f0b-4508-8f6c-c81d35db9198	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 11:40:48.283534+00
ee6d9457-154d-43f3-906b-42735c71f98a	57244d0b-3f39-4948-acc7-adc65f9cde63	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 18:02:21.107909+00
db2ef71c-d13a-4f30-a684-528768a942c0	f9351395-93a4-4f93-a239-b832daa94ead	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 18:03:56.056829+00
34059a5f-a2dd-4cd1-b23d-0cca52cca876	2d5be92e-88d6-4689-8fec-f14fe4bd41ed	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	view	null	2026-07-23 18:04:53.338408+00
\.


--
-- Data for Name: document_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_categories (id, tenant_id, name, slug, description, icon, color, parent_id, sort_order, document_count, created_at) FROM stdin;
8217f303-d7c3-4ea3-8162-d927a050aaf6	demo-association	Test Category 5b97	test-category-5b97	A test category	\N	\N	\N	0	0	2026-07-23 05:32:13.44607+00
57d2ae99-557c-4c65-8889-dd84f164248b	demo-association	Test f6ce	test-f6ce	\N	\N	\N	\N	0	0	2026-07-23 05:34:30.886787+00
5ab0e6b6-bb2b-4a1d-a505-61f6f76c3b1a	demo-association	Test 2501	test-2501	\N	\N	\N	\N	0	0	2026-07-23 05:36:11.16645+00
49ade158-5634-4a2f-95e3-211b20be38e9	demo-association	Audit Category	audit-category	\N	\N	\N	\N	0	0	2026-07-23 09:06:01.221798+00
971198db-cda8-4fe0-bac6-46df07c0a7be	demo-association	Audit Category	audit-category	\N	\N	\N	\N	0	0	2026-07-23 09:16:05.205339+00
2700791b-22b6-48f9-a111-5dbb5a7ff847	demo-association	Audit Category	audit-category	\N	\N	\N	\N	0	0	2026-07-23 09:21:31.495965+00
\.


--
-- Data for Name: document_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_comments (id, document_id, member_id, tenant_id, content, parent_id, created_at, updated_at) FROM stdin;
4fafb446-3ee0-49fc-b522-ae8ad2798ef9	51c1450f-e087-47fa-a43d-b5a0997d8bba	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Test comment	\N	2026-07-23 07:04:03.669387+00	\N
005e343c-f043-4c04-b1cf-80fa19b54909	1338a06a-2f0b-4508-8f6c-c81d35db9198	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	QA test comment	\N	2026-07-23 07:09:17.502877+00	\N
eed22de5-1f71-42ec-b1fc-a50579983a48	6c30608a-a1f4-4fcd-b010-320fdeddf0a3	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	test	\N	2026-07-23 07:12:22.671801+00	\N
43b01900-f831-49e9-a795-a0139d02aab4	ca8bc130-defa-4de3-a965-3167033b1cca	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	test	\N	2026-07-23 07:22:54.165028+00	\N
cec9ebc4-6372-4f69-aa18-2f5b655c3da5	6aaa9d5d-8126-4e8a-be96-7fe4b0a79675	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Audit comment	\N	2026-07-23 09:06:01.567904+00	\N
aedea70d-ce30-486f-a8f2-be906499741a	6b87bf8d-8a81-4b4b-a19f-e1c6c82827b5	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Audit comment	\N	2026-07-23 09:16:05.368269+00	\N
6aadb477-f559-4304-bc11-2bb7ae8f173c	d1d5b436-ef5a-4e22-980d-b4cf1d770b41	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Audit comment	\N	2026-07-23 09:21:31.604947+00	\N
7a30b396-947f-4508-93a1-59fbed561ee0	1338a06a-2f0b-4508-8f6c-c81d35db9198	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	nice	\N	2026-07-23 10:10:36.516154+00	\N
39d4916e-96ee-4ddf-b59f-13204b84f2f3	57244d0b-3f39-4948-acc7-adc65f9cde63	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Test comment	\N	2026-07-23 18:02:21.435322+00	\N
eebd62ed-d1f2-4dcd-a26b-096c74202b4e	f9351395-93a4-4f93-a239-b832daa94ead	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Test comment	\N	2026-07-23 18:03:56.365542+00	\N
41edf072-a1de-4d79-9779-aa5d9eacd171	2d5be92e-88d6-4689-8fec-f14fe4bd41ed	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	Test	\N	2026-07-23 18:04:53.714487+00	\N
\.


--
-- Data for Name: document_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_shares (id, document_id, shared_by, shared_with, tenant_id, permission, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: document_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_versions (id, document_id, tenant_id, version, file_name, file_size, file_url, storage_path, change_summary, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, tenant_id, title, slug, description, document_type, status, file_name, file_size, file_type, file_url, thumbnail_url, storage_path, link_url, version, current_version_id, category_id, parent_id, tags, access_level, allowed_user_ids, allowed_group_ids, metadata_json, search_text, view_count, download_count, published_at, expires_at, created_by, created_at, updated_at) FROM stdin;
172ab669-c951-42ac-b8a7-88d8cfd6784c	demo-association	Test Policy	test-policy	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:13:36.252283+00	2026-07-23 02:13:36.252288+00
63394c99-54bd-461e-aeb9-2f851e2ccbf8	demo-association	Bylaws 2026	bylaws-2026	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:23:19.883802+00	2026-07-23 02:23:19.883807+00
2750ffcc-4852-401e-9ee3-3b946af9b380	demo-association	Test Doc 3	test-doc-3	\N	FILE	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:29:49.122612+00	2026-07-23 02:29:49.122618+00
24c7a34a-9fcc-4de5-ba64-dc76454d934a	demo-association	Bylaws 2026	bylaws-2026	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:35:24.930772+00	2026-07-23 02:35:25.030805+00
e6a05ecc-f93a-448c-b112-2599d09d877a	demo-association	QA Test Document	qa-test-document	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:48:28.382273+00	2026-07-23 06:48:28.382278+00
d507a5ca-ddec-4d55-a969-41cef0ec1360	demo-association	QA Doc	qa-doc	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:50:39.604201+00	2026-07-23 06:50:39.604206+00
5786d8f4-3a29-484c-b9b4-cb5ee6529476	demo-association	QA Doc	qa-doc	\N	FILE	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:00:29.299272+00	2026-07-23 07:00:29.445414+00
51c1450f-e087-47fa-a43d-b5a0997d8bba	demo-association	Test	test	\N	FILE	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:04:03.606501+00	2026-07-23 07:04:03.705288+00
2d5be92e-88d6-4689-8fec-f14fe4bd41ed	demo-association	Doc 1784829888	doc-1784829888	\N	POLICY	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:04:53.213727+00	2026-07-23 18:04:53.904752+00
6c30608a-a1f4-4fcd-b010-320fdeddf0a3	demo-association	QA Doc	qa-doc	\N	FILE	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:12:22.564012+00	2026-07-23 07:12:22.687021+00
c5551255-0398-41e7-9f10-a251d7259997	demo-association	Annual Report 2025	annual-report-2025	Document: Annual Report 2025	POLICY	PUBLISHED	annual-report-2025.pdf	24902	application/pdf	/docs/annual-report-2025.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	51	30	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.331943+00	2026-07-24 07:40:11.331943+00
ca8bc130-defa-4de3-a965-3167033b1cca	demo-association	QA	qa	\N	FILE	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:22:54.077854+00	2026-07-23 07:22:54.181766+00
ba9da68f-edbd-40ac-9e2c-34ae337e7b45	demo-association	Bylaws Amendment Proposal	bylaws-amendment-proposal	Document: Bylaws Amendment Proposal	POLICY	DRAFT	bylaws-amendment-proposal.pdf	207533	application/pdf	/docs/bylaws-amendment-proposal.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	92	6	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.336543+00	2026-07-24 07:40:11.336543+00
c0d44708-3839-4791-b1da-21d5d94318c6	demo-association	Meeting Minutes - Jan 2026	meeting-minutes---jan-2026	Document: Meeting Minutes - Jan 2026	MINUTES	PUBLISHED	meeting-minutes---jan-2026.pdf	296357	application/pdf	/docs/meeting-minutes---jan-2026.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	13	22	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.33963+00	2026-07-24 07:40:11.33963+00
6aaa9d5d-8126-4e8a-be96-7fe4b0a79675	demo-association	Updated Audit Doc	audit-test-doc	\N	POLICY	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:06:01.240912+00	2026-07-23 09:06:01.659405+00
f5355dcf-166a-468c-8d65-320848bd4805	demo-association	Meeting Minutes - Feb 2026	meeting-minutes---feb-2026	Document: Meeting Minutes - Feb 2026	MINUTES	PUBLISHED	meeting-minutes---feb-2026.pdf	373766	application/pdf	/docs/meeting-minutes---feb-2026.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	52	4	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.342802+00	2026-07-24 07:40:11.342802+00
021b1fe0-81d6-408f-bdaf-d424ffb7fe6f	demo-association	Meeting Minutes - Mar 2026	meeting-minutes---mar-2026	Document: Meeting Minutes - Mar 2026	MINUTES	PUBLISHED	meeting-minutes---mar-2026.pdf	399084	application/pdf	/docs/meeting-minutes---mar-2026.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	79	7	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.345828+00	2026-07-24 07:40:11.345828+00
6b87bf8d-8a81-4b4b-a19f-e1c6c82827b5	demo-association	Updated Audit Doc	audit-test-doc	\N	POLICY	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:16:05.222436+00	2026-07-23 09:16:05.441328+00
676d03c3-0cb0-447d-b590-88019722dcbe	demo-association	Budget Proposal 2026	budget-proposal-2026	Document: Budget Proposal 2026	REPORT	PUBLISHED	budget-proposal-2026.pdf	257953	application/pdf	/docs/budget-proposal-2026.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	30	41	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.348882+00	2026-07-24 07:40:11.348882+00
565d2a9f-bf04-4ff3-ac3f-5254607ee50e	demo-association	Strategic Plan 2026-2028	strategic-plan-2026-2028	Document: Strategic Plan 2026-2028	REPORT	DRAFT	strategic-plan-2026-2028.pdf	348202	application/pdf	/docs/strategic-plan-2026-2028.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	49	8	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.351857+00	2026-07-24 07:40:11.351857+00
d1d5b436-ef5a-4e22-980d-b4cf1d770b41	demo-association	Updated Audit Doc	audit-test-doc	\N	POLICY	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:21:31.517464+00	2026-07-23 09:21:31.651064+00
afdaf150-9b67-4cc7-8864-179e33e55935	demo-association	Membership Application Form	membership-application-form	Document: Membership Application Form	FORM	PUBLISHED	membership-application-form.pdf	494069	application/pdf	/docs/membership-application-form.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	71	39	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.354625+00	2026-07-24 07:40:11.354625+00
1338a06a-2f0b-4508-8f6c-c81d35db9198	demo-association	QA Test Document	qa-test-document	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	2	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:09:17.25851+00	2026-07-23 11:40:48.298803+00
3c51c9fa-726e-4edd-bb52-11a115c7e277	demo-association	Vendor Contract	vendor-contract	Document: Vendor Contract	OTHER	PUBLISHED	vendor-contract.pdf	67743	application/pdf	/docs/vendor-contract.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	20	9	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.357438+00	2026-07-24 07:40:11.357438+00
57244d0b-3f39-4948-acc7-adc65f9cde63	demo-association	E2E Test Doc v2	e2e-test-doc-v2	\N	POLICY	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:02:20.994788+00	2026-07-23 18:02:21.70175+00
e8f15b19-7965-43d3-81e9-f6a03bdb3bb8	demo-association	E2E Test Document	e2e-test-document	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 17:55:14.96751+00	2026-07-23 17:55:14.96752+00
5bb66c3e-b2d9-4bd3-84f9-b2186c6f9e39	demo-association	Volunteer Handbook	volunteer-handbook	Document: Volunteer Handbook	OTHER	DRAFT	volunteer-handbook.pdf	464906	application/pdf	/docs/volunteer-handbook.pdf	\N	\N	\N	1	\N	\N	\N	\N	MEMBERS	\N	\N	\N	\N	111	48	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.360366+00	2026-07-24 07:40:11.360366+00
f9351395-93a4-4f93-a239-b832daa94ead	demo-association	E2E Test Doc v2	e2e-test-doc-v2	\N	POLICY	DELETED	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	1	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:03:55.908455+00	2026-07-23 18:03:56.585028+00
344f92b7-1171-4f0e-b3b5-dc5780929922	demo-association	test-upload.txt	test-uploadtxt	\N	FILE	DRAFT	test-upload.txt	13	text/plain	/api/v1/documents/file/demo-association/documents/9dacac52141b4a82894f9174a736e550.txt	\N	demo-association/documents/9dacac52141b4a82894f9174a736e550.txt	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-25 10:35:28.884353+00	2026-07-25 10:35:28.884357+00
488b1d8c-2ff8-44fd-90bd-cd0f82fa1c42	demo-association	Test Document	test-document	\N	FILE	DRAFT	test-doc.txt	79	text/plain	/api/v1/documents/file/demo-association/documents/2f551ff2f1f8415a997a9183e33de988.txt	\N	demo-association/documents/2f551ff2f1f8415a997a9183e33de988.txt	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-25 10:46:06.629831+00	2026-07-25 10:46:06.629839+00
e0a37b16-ba85-46db-8220-50808c8da437	demo-association	Test Document	test-document	\N	POLICY	DRAFT	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	[]	STAFF	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-27 06:22:54.602793+00	2026-07-27 06:22:54.602804+00
eda709ef-fd8e-485e-af7d-0938c29a5e9c	demo-association	council-result	council-result	\N	FILE	DRAFT	council-result.json	1703	application/json	/api/v1/documents/file/demo-association/documents/e4167cf5cf8b4689bdd500e9d788cb8b.json	\N	demo-association/documents/e4167cf5cf8b4689bdd500e9d788cb8b.json	\N	1	\N	\N	\N	[]	MEMBERS	[]	[]	{}	\N	0	0	\N	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-27 06:23:50.210952+00	2026-07-27 06:23:50.210962+00
\.


--
-- Data for Name: drip_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drip_campaigns (id, tenant_id, name, description, trigger_event, target_segments, target_group_ids, target_all, status, total_enrolled, total_completed, total_unsubscribed, from_name, from_email, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drip_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drip_enrollments (id, tenant_id, campaign_id, member_id, current_step_order, status, next_send_at, completed_at, unsubscribed_at, enrolled_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drip_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drip_logs (id, tenant_id, enrollment_id, step_id, campaign_id, member_id, action, tracking_id, executed_at) FROM stdin;
\.


--
-- Data for Name: drip_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drip_steps (id, tenant_id, campaign_id, step_order, step_type, name, subject, html_body, plain_body, delay_days, delay_hours, condition_type, condition_value, condition_branch_true, condition_branch_false, sent_count, opened_count, clicked_count, created_at) FROM stdin;
\.


--
-- Data for Name: dues_structures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dues_structures (id, tenant_id, name, tier, amount, currency, billing_cycle, description, is_active, prorate, trial_days, created_at) FROM stdin;
7a677e7e-a4ac-418f-8f2f-45ecc860a411	demo-association	Annual Membership	basic	100.00	USD	annual	\N	t	t	0	2026-07-23 09:06:00.650941+00
6b3ebece-0008-4a76-b607-f2332fc8d78c	demo-association	Annual Membership	basic	100.00	USD	annual	\N	t	t	0	2026-07-23 09:16:04.397771+00
d484254b-88c9-4909-a611-7d095e4dbf1f	demo-association	Annual Membership	basic	100.00	USD	annual	\N	t	t	0	2026-07-23 09:21:31.12653+00
a3072bae-5374-45f7-8f67-9c54a3f4277d	demo-association	abc	basic	2000.00	USD	annual		t	t	0	2026-07-23 11:04:20.119346+00
f2a29eff-205b-4930-b7a4-f5bd4fd4240d	demo-association	abc	basic	2000.00	USD	annual		t	t	0	2026-07-23 11:04:20.908876+00
\.


--
-- Data for Name: election_positions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.election_positions (id, election_id, tenant_id, title, description, seats, sort_order, created_at) FROM stdin;
96a5c3c9-d723-4a14-be75-e9445864d5d1	59e9c6f3-6718-4414-849e-384828a20ec4	demo-association	President	Test position	1	0	2026-07-23 06:48:28.707286+00
bd51bb81-5659-4d3d-999a-ca888c099150	8ceb77fe-2ef1-4723-b595-d55af3d915c2	demo-association	President	\N	1	0	2026-07-23 06:50:40.336349+00
b45fe2fd-fe17-4496-bfee-d25c99ab1abe	f2c618fd-a54c-4472-bf82-a33b4403a7c6	demo-association	President	\N	1	0	2026-07-23 07:00:29.612494+00
4d36eca2-2029-404c-ac6c-c1e46db28795	58b7b56c-1270-4859-9edf-3051f3446ad3	demo-association	President	Test position	1	0	2026-07-23 07:09:17.840493+00
b324be27-ac0d-4009-b39a-e5d56fb86df0	5489b170-f7fa-4a9d-9e91-d9fb115196f0	demo-association	Pres	\N	1	0	2026-07-23 07:12:22.922639+00
\.


--
-- Data for Name: election_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.election_results (id, election_id, position_id, tenant_id, total_votes, results_detail, winners, is_final, published_at, created_at) FROM stdin;
\.


--
-- Data for Name: elections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.elections (id, tenant_id, title, description, election_type, status, nominations_open, nominations_close, voting_start, voting_end, seats_available, max_candidates_per_seat, min_votes_required, quorum_percentage, require_unanimous, vote_method, allow_abstain, secret_ballot, multiple_rounds, ranked_choice, total_eligible_voters, total_votes_cast, quorum_met, results_summary, created_by, created_at, updated_at) FROM stdin;
cb36f11c-8b4d-41e2-971d-a59b343d8208	demo-association	Board Election 2026	Annual board election	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 01:53:07.69253+00	2026-07-23 01:53:07.692535+00
764debf2-9a81-4202-8a15-7084f6ae1d2f	demo-association	Board Election 2026	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:11:03.358563+00	2026-07-23 02:11:03.358567+00
6279c130-02ed-4f00-87dd-b27daff2bab7	demo-association	Board Election 2026	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:23:19.637781+00	2026-07-23 02:23:19.637784+00
00b40928-99f9-4684-b999-c02354ecfbe8	demo-association	Board Election 2026	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:35:24.642124+00	2026-07-23 02:35:24.642128+00
1abfa031-6f47-41b6-8db3-dee9025efb5e	demo-association	Test Election d46b	Board election	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:32:13.553103+00	2026-07-23 05:32:13.553107+00
2e1dbfdf-ef0c-41d4-91c8-d85638e8cf29	demo-association	Test a722	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:34:30.962417+00	2026-07-23 05:34:30.962426+00
cd1b8300-8d34-4045-b3ae-e3f062570f13	demo-association	Test 879b	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:36:11.298802+00	2026-07-23 05:36:11.298807+00
59e9c6f3-6718-4414-849e-384828a20ec4	demo-association	QA Test Election	Test	board	DRAFT	\N	\N	\N	\N	3	\N	\N	25	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:48:28.634239+00	2026-07-23 06:48:28.634244+00
8ceb77fe-2ef1-4723-b595-d55af3d915c2	demo-association	QA Election	\N	board	DRAFT	\N	\N	\N	\N	3	\N	\N	25	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:50:40.114501+00	2026-07-23 06:50:40.114508+00
f2c618fd-a54c-4472-bf82-a33b4403a7c6	demo-association	QA Election	\N	board	DRAFT	\N	\N	\N	\N	3	\N	\N	25	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:00:29.563671+00	2026-07-23 07:00:29.563677+00
58b7b56c-1270-4859-9edf-3051f3446ad3	demo-association	QA Test Election	Test	board	DRAFT	\N	\N	\N	\N	3	\N	\N	25	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:09:17.724451+00	2026-07-23 07:09:17.724458+00
5489b170-f7fa-4a9d-9e91-d9fb115196f0	demo-association	QA2	\N	board	DRAFT	\N	\N	\N	\N	3	\N	\N	25	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:12:22.820734+00	2026-07-23 07:12:22.820738+00
35c35eb0-bd3b-4667-bf31-9c609148d511	demo-association	QA	\N	board	DRAFT	\N	\N	\N	\N	3	\N	\N	25	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:22:54.303578+00	2026-07-23 07:22:54.303581+00
0bff225f-96d6-4b59-9e1a-4cb65e4bda46	demo-association	Updated	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:06:02.151716+00	2026-07-23 09:06:02.771406+00
5c249e8b-edc2-4a50-b393-9ce65591bcf4	demo-association	Updated	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:16:05.843768+00	2026-07-23 09:16:05.994806+00
2d933216-64bc-4129-aa85-0d7691b2aaeb	demo-association	Updated	Test	board	DRAFT	\N	\N	\N	\N	1	\N	\N	33	f	ONLINE	t	t	f	f	0	0	f	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:21:31.998338+00	2026-07-23 09:21:32.123705+00
\.


--
-- Data for Name: email_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_campaigns (id, tenant_id, name, subject, preview_text, html_body, plain_body, target_segments, target_group_ids, target_all, status, total_recipients, sent_count, delivered_count, opened_count, clicked_count, bounced_count, unsubscribed_count, scheduled_at, sent_at, from_name, from_email, reply_to, created_by, created_at, updated_at) FROM stdin;
ff053d1c-2dc4-466a-8967-6899a3339af5	demo-association	Audit Fixed Campaign	Test	\N	<p>Test</p>	\N	[]	[]	t	SENT	0	0	0	0	0	0	0	\N	2026-07-23 09:21:31.908189+00	AssocHub	noreply@assochub.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:17:12.780722+00	2026-07-23 09:21:31.909624+00
54239d73-8fb0-4d68-9713-ae3b7e864c33	demo-association	Audit Fixed Campaign (Copy)	Test	\N	<p>Test</p>	\N	[]	[]	t	DRAFT	0	0	0	0	0	0	0	\N	\N	AssocHub	noreply@assochub.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:21:31.930003+00	2026-07-23 09:21:31.930008+00
13e1fb2b-69bd-4b68-a3cf-32fee82ce6d1	demo-association	Test	Test	\N	<p>Test</p>	\N	[]	[]	t	SENT	0	0	0	0	0	0	0	\N	2026-07-23 11:06:36.404142+00	AssocHub	noreply@assochub.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:22:25.438597+00	2026-07-23 11:06:36.407003+00
60700672-bfe9-4964-95a2-1852bb78281c	demo-association	SMTP Test - Live	AssocHub Email Test	\N	<h2>Hello!</h2><p>This is a live test email from AssocHub AMS.</p>	\N	[]	[]	f	SENT	0	0	0	0	0	0	0	\N	2026-07-24 06:03:15.792233+00	AssocHub	tara378581@gmail.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 06:03:15.56849+00	2026-07-24 06:03:15.795312+00
db2593dd-7eb7-44c9-9c7c-336121ef4214	demo-association	Live Email Test	AssocHub - Email System Verification	\N	<h2>✅ Email System Working!</h2><p>Hello {{name}},</p><p>This is a live test from AssocHub AMS. If you received this email, the SMTP integration is fully functional.</p><p>— AssocHub Team</p>	\N	[]	[]	f	SENT	0	0	0	0	0	0	0	\N	2026-07-24 06:05:21.408226+00	AssocHub	tara378581@gmail.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 06:05:21.299072+00	2026-07-24 06:05:21.409074+00
8289f5e5-d9a7-4f27-8545-bd3ba854391c	demo-association	Email Test	AssocHub Email Test	\N	<h2>Email Working!</h2><p>Hello {{name}}, this is a test from AssocHub.</p>	\N	[]	[]	f	SENT	0	0	0	0	0	0	0	\N	2026-07-24 06:07:37.863396+00	AssocHub	tara378581@gmail.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 06:07:37.756673+00	2026-07-24 06:07:37.865693+00
6e430039-6f5a-485a-a59b-8018243e96c2	demo-association	Email Test v2	AssocHub Email Test	\N	<h2>Hello {{name}}!</h2><p>Emails are working from AssocHub AMS.</p>	\N	[]	[]	f	SENT	0	0	0	0	0	0	0	\N	2026-07-24 06:11:07.848432+00	AssocHub	tara378581@gmail.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 06:11:07.757489+00	2026-07-24 06:11:07.850496+00
f9c0297b-b20c-4b4f-822c-7b718266c535	demo-association	Email Test v3	AssocHub Email Works!	\N	<h2>Hi {{name}}!</h2><p>Email system verified.</p>	\N	[]	[]	f	SENT	0	0	0	0	0	0	0	\N	2026-07-24 06:13:33.990694+00	AssocHub	tara378581@gmail.com	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 06:13:33.940158+00	2026-07-24 06:13:33.994078+00
\.


--
-- Data for Name: email_sending_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_sending_logs (id, tenant_id, recipient_id, recipient_email, subject, body_preview, status, provider, error_message, template_id, campaign_id, retry_count, max_retries, sent_at, created_at, unsubscribe_token, tracking_id) FROM stdin;
700adf66-c53d-4218-9a05-e638cea417eb	demo-association	\N	tara378581@gmail.com	AssocHub Full Pipeline Test 🔧	<h2>Full pipeline works!</h2><p>Template + provider + DB logging all wired up.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-23 08:32:09.32162+00	2026-07-23 08:32:09.32162+00	\N	\N
1968a3eb-86d3-4f22-b73e-af2791b7f556	demo-association	\N	daniel.harris@example.com	AssocHub Email Works!	<h2>Hi Daniel!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:36.346066+00	2026-07-24 06:13:36.346066+00	\N	\N
7c41e98d-d280-45ee-85f4-7d048ac4616f	demo-association	\N	daniel.taylor@example.com	AssocHub Email Works!	<h2>Hi Daniel!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:36.823635+00	2026-07-24 06:13:36.823635+00	\N	\N
062db220-d2d2-4bb9-b9ac-7eccc98cf256	demo-association	\N	amanda.miller@example.com	AssocHub Email Works!	<h2>Hi Amanda!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:39.104337+00	2026-07-24 06:13:39.104337+00	\N	\N
ee279354-6e6d-4c2e-ab31-7ed7544affb8	demo-association	\N	andrew.king@example.com	AssocHub Email Works!	<h2>Hi Andrew!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:39.723958+00	2026-07-24 06:13:39.723958+00	\N	\N
c3942239-81f4-4d0f-b3fd-8f280db90024	demo-association	\N	nicole.walker@example.com	AssocHub Email Works!	<h2>Hi Nicole!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:41.911257+00	2026-07-24 06:13:41.911257+00	\N	\N
a6a12f55-890c-4bfa-90b7-ce3e56845733	demo-association	\N	rachel.davis@example.com	AssocHub Email Works!	<h2>Hi Rachel!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:42.996409+00	2026-07-24 06:13:42.996409+00	\N	\N
828c453e-c4d2-4bf0-87c0-63d5f74b6643	demo-association	\N	daniel.taylor@example.com	AssocHub Email Works!	<h2>Hi Daniel!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:46.755236+00	2026-07-24 06:13:46.755236+00	\N	\N
789e0d71-c981-4b71-9b4c-566db6f28ee7	demo-association	\N	nicole.nelson@example.com	AssocHub Email Works!	<h2>Hi Nicole!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:47.56878+00	2026-07-24 06:13:47.56878+00	\N	\N
a243c8a5-7715-4c80-a5e1-d01a546cd561	demo-association	\N	heather.davis@example.com	AssocHub Email Works!	<h2>Hi Heather!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:51.160604+00	2026-07-24 06:13:51.160604+00	\N	\N
781d7306-59a5-4841-a127-98bfed9576d3	demo-association	\N	robert.rodriguez@example.com	AssocHub Email Works!	<h2>Hi Robert!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:52.88078+00	2026-07-24 06:13:52.88078+00	\N	\N
69bb3766-7edf-4c1f-b7c0-ddbd492f26c7	demo-association	\N	michael.young@example.com	AssocHub Email Works!	<h2>Hi Michael!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:56.97697+00	2026-07-24 06:13:56.97697+00	\N	\N
57f42452-cb9a-46eb-93ad-513ebea9ebea	demo-association	\N	jennifer.garcia@example.com	AssocHub Email Works!	<h2>Hi Jennifer!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:13:58.387966+00	2026-07-24 06:13:58.387966+00	\N	\N
eae8879e-c55f-48e9-8e17-f77c8ccd65bb	demo-association	\N	william.king@example.com	AssocHub Email Works!	<h2>Hi William!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:00.74611+00	2026-07-24 06:14:00.74611+00	\N	\N
ec779aa4-b461-43cd-85c0-0652ecff3793	demo-association	\N	heather.adams@example.com	AssocHub Email Works!	<h2>Hi Heather!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:01.951316+00	2026-07-24 06:14:01.951316+00	\N	\N
690b3b28-23ac-478c-9381-31b36e4c1b12	demo-association	\N	robert.jones@example.com	AssocHub Email Works!	<h2>Hi Robert!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:03.892595+00	2026-07-24 06:14:03.892595+00	\N	\N
cb81cd31-f178-4ded-9d17-adc8149770a1	demo-association	\N	timothy.robinson@example.com	AssocHub Email Works!	<h2>Hi Timothy!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:04.461642+00	2026-07-24 06:14:04.461642+00	\N	\N
6f030251-ba81-4544-b067-c21290334521	demo-association	\N	laura.lewis@example.com	AssocHub Email Works!	<h2>Hi Laura!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:06.631722+00	2026-07-24 06:14:06.631722+00	\N	\N
d5d21b3e-0213-4160-b6bd-544e162aa323	demo-association	\N	angela.clark@example.com	AssocHub Email Works!	<h2>Hi Angela!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:07.3169+00	2026-07-24 06:14:07.3169+00	\N	\N
d57eee9b-aaf1-42ab-9d9b-81d310905682	demo-association	\N	william.adams@example.com	AssocHub Email Works!	<h2>Hi William!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:09.549091+00	2026-07-24 06:14:09.549091+00	\N	\N
b864d542-43f0-414e-ab27-2d37911d2183	demo-association	\N	maria.scott@example.com	AssocHub Email Works!	<h2>Hi Maria!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:10.515053+00	2026-07-24 06:14:10.515053+00	\N	\N
b6b40411-ef54-4e87-b84d-7f1c89d5b5dc	demo-association	\N	michelle.rodriguez@example.com	AssocHub Email Works!	<h2>Hi Michelle!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:13.112887+00	2026-07-24 06:14:13.112887+00	\N	\N
6b185bf4-d198-4d55-a8e8-7ec42b45c5d9	demo-association	\N	timothy.williams@example.com	AssocHub Email Works!	<h2>Hi Timothy!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:13.659347+00	2026-07-24 06:14:13.659347+00	\N	\N
126702d1-674d-4ee0-88a8-3c1ec0e0f535	demo-association	\N	william.lee@example.com	AssocHub Email Works!	<h2>Hi William!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:16.880777+00	2026-07-24 06:14:16.880777+00	\N	\N
9a767470-1478-4c4d-8401-a12642daa6ad	demo-association	\N	daniel.baker@example.com	AssocHub Email Works!	<h2>Hi Daniel!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:17.386265+00	2026-07-24 06:14:17.386265+00	\N	\N
e4d0cede-9a40-45c7-a85a-1515ad6a4bd9	demo-association	\N	nicole.miller@example.com	AssocHub Email Works!	<h2>Hi Nicole!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:20.698684+00	2026-07-24 06:14:20.698684+00	\N	\N
c11d2425-3bcd-4f75-9c67-ab360472f2d7	demo-association	\N	test_8dd8a5@example.com	AssocHub Email Works!	<h2>Hi Test!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:21.466112+00	2026-07-24 06:14:21.466112+00	\N	\N
c8370e00-b232-485f-a01e-37d974579234	demo-association	\N	qa3@qa.com	AssocHub Email Works!	<h2>Hi QA4!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:25.031412+00	2026-07-24 06:14:25.031412+00	\N	\N
bf19bb9c-3ddc-4eb5-ae35-1d2193aaa62e	demo-association	\N	final_qa@qa.com	AssocHub Email Works!	<h2>Hi FQ2!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:25.769917+00	2026-07-24 06:14:25.769917+00	\N	\N
9a8ec98f-4d60-4089-8b2f-5c1d803d4fb4	demo-association	\N	testcreate@example.com	AssocHub Email Works!	<h2>Hi Test!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:28.498327+00	2026-07-24 06:14:28.498327+00	\N	\N
d31381f7-2258-40ae-bfdc-faea7faf804f	demo-association	\N	test_audit@example.com	AssocHub Email Works!	<h2>Hi Audit!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:29.909318+00	2026-07-24 06:14:29.909318+00	\N	\N
66019909-7fd6-4944-a3c2-3ade6af1ef50	demo-association	\N	testfix2@example.com	AssocHub Email Works!	<h2>Hi Test2!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:33.368872+00	2026-07-24 06:14:33.368872+00	\N	\N
0f5d65cf-be33-4fdf-9f22-e324457c5e0f	demo-association	\N	testfix3@example.com	AssocHub Email Works!	<h2>Hi Test3!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:34.555301+00	2026-07-24 06:14:34.555301+00	\N	\N
078e1142-ca1b-43ab-874e-863497046b10	demo-association	\N	e2e-test-member-v2@example.com	AssocHub Email Works!	<h2>Hi E2E!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:36.632323+00	2026-07-24 06:14:36.632323+00	\N	\N
8dfeb026-613f-409b-85c2-d63e53583308	demo-association	\N	e2e1784829888@test.com	AssocHub Email Works!	<h2>Hi Updated!</h2><p>Email system verified.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:14:37.195923+00	2026-07-24 06:14:37.195923+00	\N	\N
a99d155d-4238-4548-9551-5edfb0e93c89	demo-association	\N	welcome-1784874922@gmail.com	Welcome to AssocHub, Welcome!	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Welcome!</h2>\n                        <p>Your account has been created successfully. Here's what you can do now:</p>\n                        <ul>\n                            <li>Manage your membership profile</li>\n                            <li>Register for events</li>\n                            <li>Track your payments and	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:35:25.075+00	2026-07-24 06:35:25.075+00	\N	\N
d939959d-9f6f-4b28-9aeb-cbf3df8136de	demo-association	\N	welcome-1784874922@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Welcome,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:35 UTC</li>\n                            <li>Ema	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:35:30.077297+00	2026-07-24 06:35:30.077297+00	\N	\N
0e713958-3e41-4936-aca8-5426988bb2e1	demo-association	\N	tara378581@gmail.com	AssocHub Auth Test - Welcome Email	<h2>Welcome!</h2><p>This is a test welcome email from AssocHub.</p>	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:36:29.81425+00	2026-07-24 06:36:29.81425+00	\N	\N
07abb772-422c-40c8-81ea-e5793bae5f2e	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:36 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:36:44.825631+00	2026-07-24 06:36:44.825631+00	\N	\N
bc54ced3-1484-4434-8ecc-9afcba09bf65	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:38 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:38:13.205847+00	2026-07-24 06:38:13.205847+00	\N	\N
ae570906-c50a-4c76-870a-1d9eddd5389b	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:39 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:39:31.642875+00	2026-07-24 06:39:31.642875+00	\N	\N
996ae4cd-f862-45a1-bde5-2164b3765c8a	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:41 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:41:20.629788+00	2026-07-24 06:41:20.629788+00	\N	\N
4adc05e7-c081-4cfa-9272-7f072dc40823	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:37 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:37:59.261696+00	2026-07-24 06:37:59.261696+00	\N	\N
b5403e04-32b9-432d-9db4-2934ade6dec6	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:38 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:38:14.95402+00	2026-07-24 06:38:14.95402+00	\N	\N
6c78eebf-18d6-41bf-ba81-f1530a259db0	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:38 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:38:49.274768+00	2026-07-24 06:38:49.274768+00	\N	\N
b9c19bc8-c1c0-4b19-b8d2-0125b2613513	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:40 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:40:15.372576+00	2026-07-24 06:40:15.372576+00	\N	\N
55079fe5-7024-47b0-bacb-d8592e8b51cd	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:40 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:40:47.970963+00	2026-07-24 06:40:47.970963+00	\N	\N
0c1e4d46-241c-4741-88de-8d61e0e79f32	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:41 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:41:52.556376+00	2026-07-24 06:41:52.556376+00	\N	\N
833441f9-0508-484f-b63f-987691b92bee	user-id	\N	ladlasab061@gmail.com	Welcome to AssocHub, Mohsin!	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Mohsin!</h2>\n                        <p>Your account has been created successfully. Here's what you can do now:</p>\n                        <ul>\n                            <li>Manage your membership profile</li>\n                            <li>Register for events</li>\n                            <li>Track your payments and 	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:41:53.222526+00	2026-07-24 06:41:53.222526+00	\N	\N
78fdb81d-d62c-4f9d-9134-c7904fbf317e	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:42 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:42:36.751519+00	2026-07-24 06:42:36.751519+00	\N	\N
67820441-b01d-4e7b-9e01-b3743278f35c	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:43 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:43:21.866891+00	2026-07-24 06:43:21.866891+00	\N	\N
24f75801-0f6b-45fc-a8f5-466af3c79b45	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:43 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:43:24.16026+00	2026-07-24 06:43:24.16026+00	\N	\N
63f5dbeb-454a-4dff-8703-430a55f8abe0	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:44 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:44:15.856931+00	2026-07-24 06:44:15.856931+00	\N	\N
1bbbe820-93f3-4eb9-bd6b-f5f657ab4109	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:44 UTC</li>\n                            <li>Emai	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:44:17.721994+00	2026-07-24 06:44:17.721994+00	\N	\N
ea984562-dee5-4c84-a4c8-791079f8b949	demo-association	\N	final-test-1784875457@test.com	Welcome to AssocHub, Test!	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Test!</h2>\n                        <p>Your account has been created successfully. Here's what you can do now:</p>\n                        <ul>\n                            <li>Manage your membership profile</li>\n                            <li>Register for events</li>\n                            <li>Track your payments and in	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:44:19.715347+00	2026-07-24 06:44:19.715347+00	\N	\N
b82a1d53-50a7-4a4e-803a-14643dc3ac27	demo-association	\N	testverify-1784876071@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Test!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=luKpnHJOY7jk68F9b9Q6f3PADkiQEg	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:54:35.282352+00	2026-07-24 06:54:35.282352+00	\N	\N
5f3ac9f5-1abc-4204-b499-6735056d3678	demo-association	\N	testverify-1784876071@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Test,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:54 UTC</li>\n                       	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:54:42.239986+00	2026-07-24 06:54:42.239986+00	\N	\N
f1291173-8095-4abb-918a-14f974e45a1f	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:54 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:54:44.164331+00	2026-07-24 06:54:44.164331+00	\N	\N
007a93a9-ec79-4c0f-89f7-18609806f4bf	demo-association	\N	resendtest-1784876100@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Resend!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=kTYu57K8GffZSVeqEHJSet7J_kY5	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:55:02.782694+00	2026-07-24 06:55:02.782694+00	\N	\N
a177b0ea-d26e-4fbb-a4e2-3df352cb535a	demo-association	\N	resendtest-1784876100@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Verify Your Email</h2>\n                        <p>Hi Resend, here's a new verification link for your AssocHub account.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=O2y7lAAAclAnH--XUz-nDTrJBaNQLfFKsfWe7DG1Ror-z9vQpy4vBh	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:55:06.43903+00	2026-07-24 06:55:06.43903+00	\N	\N
c292cf24-6800-4174-94a7-03ac01d95446	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:55 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:55:47.846233+00	2026-07-24 06:55:47.846233+00	\N	\N
f5fa9941-2a4b-4b30-9844-67b57a64071e	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:56 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:56:59.097309+00	2026-07-24 06:56:59.097309+00	\N	\N
b3085f79-2eb0-4850-8ead-9fe10c805d48	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 06:59 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 06:59:59.466077+00	2026-07-24 06:59:59.466077+00	\N	\N
404f563e-eb63-4fe4-a13d-0edf6f9b6698	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:13 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:13:12.699032+00	2026-07-24 07:13:12.699032+00	\N	\N
ebfc1a6c-615e-4099-9020-b0a6688de1e8	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:13 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:13:43.705008+00	2026-07-24 07:13:43.705008+00	\N	\N
a307c0ae-53b8-4616-8599-8c28fd47a15c	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:16 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:16:52.75781+00	2026-07-24 07:16:52.75781+00	\N	\N
30bdb889-579e-4cbd-ada6-b8539c744934	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:17 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:17:43.394511+00	2026-07-24 07:17:43.394511+00	\N	\N
f3292605-5e48-4865-87af-9a32f853c3cf	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:43 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:43:50.554593+00	2026-07-24 07:43:50.554593+00	\N	\N
3a2010cd-95a8-478a-8fb7-86c7aca8941f	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:07 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:07:25.20566+00	2026-07-24 08:07:25.20566+00	\N	\N
b6eaff3f-847d-4761-be72-114e675b98f9	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:07 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:07:34.646986+00	2026-07-24 08:07:34.646986+00	\N	\N
ec03a175-c03b-47c7-82fc-a99196879c34	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:18 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:18:22.452954+00	2026-07-24 07:18:22.452954+00	\N	\N
4ee1d478-b212-4444-96f2-57588ca07722	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:07 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:07:13.533473+00	2026-07-24 08:07:13.533473+00	\N	\N
151164a3-6865-4d70-84f5-a15393c2f3d0	demo-association	\N	test.user@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Test!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=lPfV1E4WmQGLvOq1U1I_KoTE2GDKBh	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:08:37.60879+00	2026-07-24 08:08:37.60879+00	\N	\N
bde65667-5c7e-42fc-a72a-39c850c70213	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:09 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:09:28.524847+00	2026-07-24 08:09:28.524847+00	\N	\N
2cca2a49-0e17-43da-9f75-2ce26ada2203	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:18 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:18:24.417078+00	2026-07-24 07:18:24.417078+00	\N	\N
12ce43c4-6cc0-4f62-8ba7-84ac6ca7ce64	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:18 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:18:52.140953+00	2026-07-24 07:18:52.140953+00	\N	\N
50885e96-1815-45bf-83f7-ca26929a5ee9	ilsasyeda24@gmail.com	\N	ilsasyeda24@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Ilsa!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=F0noV1ZoAZNh3CEEGxfOb5byiHXHBK	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:22:59.864269+00	2026-07-24 07:22:59.864269+00	\N	\N
c1ef489d-6ab3-4c89-a0d5-c13b4026197c	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:25 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:25:42.057602+00	2026-07-24 07:25:42.057602+00	\N	\N
06061e19-e6ca-428f-943f-1079775c1a43	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:42 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:42:38.781048+00	2026-07-24 07:42:38.781048+00	\N	\N
50997000-d112-4034-954e-7925eaf29695	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:42 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:42:47.100417+00	2026-07-24 07:42:47.100417+00	\N	\N
98538c5d-d081-476f-9dcf-a0e067a7ef50	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:42 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:42:59.573613+00	2026-07-24 07:42:59.573613+00	\N	\N
661d0cc0-bbbf-4135-8ad8-2c40e4924992	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:43 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:43:23.8384+00	2026-07-24 07:43:23.8384+00	\N	\N
3794c90d-0e09-4536-bb02-8a670f550d23	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 07:42 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 07:42:25.392645+00	2026-07-24 07:42:25.392645+00	\N	\N
6d7a7967-acb0-40f6-8616-67d5b80918fe	demo-association	\N	ahmed.test@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Ahmed!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=0kMDuTYPRp0lrgP6eweddchqWbygK	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:09:59.353634+00	2026-07-24 08:09:59.353634+00	\N	\N
6fdcd1c2-f7b7-414d-bcaf-c288e8453139	demo-association	\N	ahmed.test@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Ahmed,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:10 UTC</li>\n                      	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:10:44.464105+00	2026-07-24 08:10:44.464105+00	\N	\N
0781dbd9-a1cc-4f3d-9e61-fce033248d33	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:14 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:14:17.320543+00	2026-07-24 08:14:17.320543+00	\N	\N
fae33a21-ca01-4d87-ba32-a64bef045be4	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:15 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:15:35.429014+00	2026-07-24 08:15:35.429014+00	\N	\N
80cc59e7-c067-4596-9941-4c3b896633cc	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:16 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:16:15.621915+00	2026-07-24 08:16:15.621915+00	\N	\N
47f6ea0b-a564-4bce-a55c-073f5ff63af6	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:16 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:16:47.921813+00	2026-07-24 08:16:47.921813+00	\N	\N
df5c2106-7314-49c4-b5ba-eeffd9e581f9	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:17 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:17:19.757512+00	2026-07-24 08:17:19.757512+00	\N	\N
8b44b367-63e0-4270-a8fa-a4cce5724f99	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:43 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:43:53.407643+00	2026-07-24 08:43:53.407643+00	\N	\N
77deac64-5193-412a-ae5a-57e7b11e10eb	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:46 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:46:36.042695+00	2026-07-24 08:46:36.042695+00	\N	\N
c1b9e5df-ca1e-42c4-8bfd-7e2f91e0faec	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:47 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:47:52.542723+00	2026-07-24 08:47:52.542723+00	\N	\N
f61b9f58-897a-4938-8089-bbdfce3d8773	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:48 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:48:36.747374+00	2026-07-24 08:48:36.747374+00	\N	\N
26d445cc-f281-449c-a895-12e805251ca8	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:50 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:50:49.13864+00	2026-07-24 08:50:49.13864+00	\N	\N
61443c3a-ea6f-4655-852a-114e4f0fbfff	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:51 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:51:08.150734+00	2026-07-24 08:51:08.150734+00	\N	\N
ece88cbc-3ae1-4ae3-93b8-db1ac299146a	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:55 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:55:35.470486+00	2026-07-24 08:55:35.470486+00	\N	\N
274b2230-d8a0-44ec-bf79-b25e770c5665	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:58 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:58:53.921571+00	2026-07-24 08:58:53.921571+00	\N	\N
b3e77491-6f5b-418d-894e-fcd859ec40ce	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 08:59 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 08:59:22.850838+00	2026-07-24 08:59:22.850838+00	\N	\N
d182fe3c-56af-43d9-a7d3-efe2187d744a	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 09:14 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 09:14:56.842891+00	2026-07-24 09:14:56.842891+00	\N	\N
47a80ef3-d48c-411a-b034-4f3376b257aa	demo-association	\N	demo@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Demo,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 09:17 UTC</li>\n                       	sent	smtp	\N	\N	\N	0	3	2026-07-24 09:17:38.705415+00	2026-07-24 09:17:38.705415+00	\N	\N
36483b64-5be0-4da7-8e75-3a56a49328d6	demo-association	\N	demo@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Demo,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 09:25 UTC</li>\n                       	sent	smtp	\N	\N	\N	0	3	2026-07-24 09:25:46.730329+00	2026-07-24 09:25:46.730329+00	\N	\N
a2d13467-658f-4f2f-9d8f-7ab44962c9df	mohsin-123	\N	uzairlatif293@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, John!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=Y2fqRYjAJiuDUIuKXz74LxGKS1zgD5	sent	smtp	\N	\N	\N	0	3	2026-07-24 09:27:40.822225+00	2026-07-24 09:27:40.822225+00	\N	\N
75bf0919-1b27-4320-a6ed-69266e390c1b	mohsin-123	\N	uzairlatif293@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello John,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 09:28 UTC</li>\n                       	sent	smtp	\N	\N	\N	0	3	2026-07-24 09:28:03.921892+00	2026-07-24 09:28:03.921892+00	\N	\N
0c67cd9a-e359-4940-bc5a-885193110338	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:13 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:13:58.073018+00	2026-07-24 10:13:58.073018+00	\N	\N
1ae0279c-5ab8-4f4f-b369-3f5830d4ef80	demo-association	\N	demo@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Demo,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:16 UTC</li>\n                       	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:16:47.785609+00	2026-07-24 10:16:47.785609+00	\N	\N
9e18c1f2-a2d2-460f-8a8d-486e00187cdd	demo-association	\N	demo@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Demo,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:16 UTC</li>\n                       	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:16:59.057102+00	2026-07-24 10:16:59.057102+00	\N	\N
df4090e2-a8a9-4acf-902f-7d1ebd42f061	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:17 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:17:13.138829+00	2026-07-24 10:17:13.138829+00	\N	\N
8ac2625c-9414-404f-832e-6cd391b81ae9	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:17 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:17:24.022276+00	2026-07-24 10:17:24.022276+00	\N	\N
3c3fcd18-c092-40da-9604-b8cbddb35666	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:18 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:18:30.413448+00	2026-07-24 10:18:30.413448+00	\N	\N
2c5838bd-72f3-4ca2-9fc6-161dc25dd783	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:19 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:19:50.500844+00	2026-07-24 10:19:50.500844+00	\N	\N
9dfd0f61-0040-4f55-831b-8b3fe99b00c8	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:20 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:20:40.215597+00	2026-07-24 10:20:40.215597+00	\N	\N
4f27892d-3c78-468e-8a5e-f4823f028a37	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:20 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:20:42.261008+00	2026-07-24 10:20:42.261008+00	\N	\N
e692a812-9cae-4e56-8649-193db1fc7a74	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:29 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:29:30.852335+00	2026-07-24 10:29:30.852335+00	\N	\N
da4a13bb-897c-4ec3-88d8-3834a585b98a	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:30 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:30:31.606091+00	2026-07-24 10:30:31.606091+00	\N	\N
b7d1dcce-793d-4771-bd68-7d5255ea4901	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:30 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:30:48.959376+00	2026-07-24 10:30:48.959376+00	\N	\N
ab999e02-1066-4eab-9b35-e5bb56fd2cfe	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:33 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:33:47.928334+00	2026-07-24 10:33:47.928334+00	\N	\N
92fc7367-ef7c-46f0-8727-7bd400a13027	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:35 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:35:37.471758+00	2026-07-24 10:35:37.471758+00	\N	\N
cdf34888-ef26-4062-9e11-297bbecd83fc	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:39 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:39:06.661768+00	2026-07-24 10:39:06.661768+00	\N	\N
77096094-096c-425a-a2e0-990c878d80af	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:40 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:40:29.375151+00	2026-07-24 10:40:29.375151+00	\N	\N
9c8b5247-e002-43e4-ae77-8a11cc64f534	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:41 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:41:10.951693+00	2026-07-24 10:41:10.951693+00	\N	\N
4d22572e-e5a8-4b80-b410-2ee54b5e1f1c	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 10:42 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 10:42:20.726001+00	2026-07-24 10:42:20.726001+00	\N	\N
ac335c98-2297-432c-b2e8-045ac6927137	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 11:04 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 11:04:50.664094+00	2026-07-24 11:04:50.664094+00	\N	\N
a5a19584-85fa-4e34-8998-616fd8561408	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 11:05 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 11:05:27.301784+00	2026-07-24 11:05:27.301784+00	\N	\N
62d740f5-9216-4157-8a98-1c43e460e832	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 24, 2026 at 19:50 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-24 19:50:59.380328+00	2026-07-24 19:50:59.380328+00	\N	\N
6ceb2f20-0737-4a31-91da-1fe48c0e6b89	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 06:20 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 06:20:48.882602+00	2026-07-25 06:20:48.882602+00	\N	\N
d6206ba2-cdf4-4348-b889-9c7304000eed	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 06:21 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 06:21:02.311039+00	2026-07-25 06:21:02.311039+00	\N	\N
52ad06af-c143-42b3-a5b6-63a4763bff6b	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 06:21 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 06:21:31.351971+00	2026-07-25 06:21:31.351971+00	\N	\N
c728de7f-662b-47d5-860e-ad7e14d6794d	demo-association	\N	test-member@example.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Test!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=y6ruSYAktIoT0XXYh2i_OcOsE0EXFz	sent	smtp	\N	\N	\N	0	3	2026-07-25 06:21:46.060081+00	2026-07-25 06:21:46.060081+00	\N	\N
1e2a3b6e-ad72-4a9b-a6ef-89a353dd24bd	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 06:52 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 06:52:09.048715+00	2026-07-25 06:52:09.048715+00	\N	\N
5b7b25d5-f116-4166-b414-b0f127342cc9	demo-association	\N	rbac-test-1784962329@example.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, RBAC!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=FRhongj50xQNfAJVXfArpQOnQkc5xH	sent	smtp	\N	\N	\N	0	3	2026-07-25 06:52:11.201369+00	2026-07-25 06:52:11.201369+00	\N	\N
2fba7e00-5096-4de9-9ee2-e08545a3a9c4	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 07:28 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 07:28:24.036259+00	2026-07-25 07:28:24.036259+00	\N	\N
3a4d0d80-0fae-4be3-8008-8f7856674d46	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 07:32 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 07:32:29.589615+00	2026-07-25 07:32:29.589615+00	\N	\N
1f2939c8-1c26-44b2-8e20-45416dad8e76	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 07:34 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 07:34:38.508776+00	2026-07-25 07:34:38.508776+00	\N	\N
ae8ad50a-50ac-421e-99c7-49033b9ee6cc	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:36 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:36:58.969703+00	2026-07-25 09:36:58.969703+00	\N	\N
5821054c-79bf-4ec0-9579-3456bfc2e608	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:39 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:39:26.308274+00	2026-07-25 09:39:26.308274+00	\N	\N
40b09187-8c12-4a28-a6d1-9b531490fb18	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:39 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:39:28.178919+00	2026-07-25 09:39:28.178919+00	\N	\N
126a7826-4510-4c53-bf42-8240b96bace9	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:36 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:36:31.551866+00	2026-07-25 09:36:31.551866+00	\N	\N
60104597-fe0b-46c6-a377-171c53bd4164	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:39 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:39:29.615756+00	2026-07-25 09:39:29.615756+00	\N	\N
53ad01a7-07ab-4f6e-bf46-9f4d5148ea1b	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:48 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:48:24.41767+00	2026-07-25 09:48:24.41767+00	\N	\N
30ac69a4-4aea-4903-9467-e11b38a8469b	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 09:48 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 09:48:36.51977+00	2026-07-25 09:48:36.51977+00	\N	\N
ca689e37-9e5e-406b-83b7-cc3fb24f17e5	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 10:35 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 10:35:19.471764+00	2026-07-25 10:35:19.471764+00	\N	\N
4c256b1a-5302-4dfa-81be-a51cb1403e0a	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 10:35 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 10:35:28.467255+00	2026-07-25 10:35:28.467255+00	\N	\N
4d4edc78-57e9-480d-8c4f-3550023c69ed	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 10:46 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 10:46:05.48549+00	2026-07-25 10:46:05.48549+00	\N	\N
3e14ad7a-c3c0-4d94-8110-c60284ef72e3	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 10:46 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 10:46:20.937733+00	2026-07-25 10:46:20.937733+00	\N	\N
1f59b586-bcbc-4fc7-bff1-adf020226581	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:16 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:16:21.244099+00	2026-07-25 11:16:21.244099+00	\N	\N
76991fe0-e0bc-48b6-8363-7b6a761fc8f5	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:23 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:23:33.223845+00	2026-07-25 11:23:33.223845+00	\N	\N
39730f4d-a2d4-4f21-9220-4614264e21a0	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:24 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:24:05.741958+00	2026-07-25 11:24:05.741958+00	\N	\N
ec71953e-2998-48b5-a9bd-45f9a9b1ef44	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:24 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:24:23.375626+00	2026-07-25 11:24:23.375626+00	\N	\N
a4939431-92f4-4591-9bde-8ab5d76d7404	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:24 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:24:33.339131+00	2026-07-25 11:24:33.339131+00	\N	\N
f3571b59-bafd-4579-b01c-28a53ef7db03	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:24 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:24:52.916591+00	2026-07-25 11:24:52.916591+00	\N	\N
dbaf8123-cfa1-46a6-b98a-733ee4cbdc3f	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:25 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:25:14.392699+00	2026-07-25 11:25:14.392699+00	\N	\N
d93781dc-721c-45d4-ba92-85d3ddd744a9	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 25, 2026 at 11:26 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-25 11:26:46.994449+00	2026-07-25 11:26:46.994449+00	\N	\N
3b630f5f-c2c5-494b-8ebb-3220b53eaefe	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 06:22 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 06:22:06.599838+00	2026-07-27 06:22:06.599838+00	\N	\N
5566be69-96e0-4cd6-9646-d549113279dc	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 07:54 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 07:54:34.804511+00	2026-07-27 07:54:34.804511+00	\N	\N
fb4e6350-8d26-4847-9b1a-28d78bee6b33	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 07:57 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 07:57:42.492687+00	2026-07-27 07:57:42.492687+00	\N	\N
64431fdf-3835-4eb7-8c01-7f4d1a0fffd5	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 07:58 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 07:58:32.24043+00	2026-07-27 07:58:32.24043+00	\N	\N
64825da0-f9ff-4370-bdc9-8656960b18ec	demo-association	\N	testuser@example.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Test!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=9B_FTwcHYcnS_1TFptf7abTxaabFBd	sent	smtp	\N	\N	\N	0	3	2026-07-27 08:05:32.599014+00	2026-07-27 08:05:32.599014+00	\N	\N
a075cf1f-2e22-4872-aa3a-95da390d480f	demo-association	\N	sarah.rodriguez@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Sarah,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 08:06 UTC</li>\n                      	sent	smtp	\N	\N	\N	0	3	2026-07-27 08:06:31.700021+00	2026-07-27 08:06:31.700021+00	\N	\N
f596365b-c372-44c5-b0f9-d8a245f6ee45	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 08:34 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 08:34:19.330628+00	2026-07-27 08:34:19.330628+00	\N	\N
cdce5c78-4bc5-406c-b043-9382a1f6dc89	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 08:39 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 08:39:29.257048+00	2026-07-27 08:39:29.257048+00	\N	\N
caab004f-e630-4f06-8f1e-ef1a58530504	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 08:51 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 08:51:46.343953+00	2026-07-27 08:51:46.343953+00	\N	\N
76d59aa5-e4aa-4ede-9208-40105dd115d8	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:02 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:02:58.948812+00	2026-07-27 09:02:58.948812+00	\N	\N
19123167-2efc-430b-99d2-5dfae97411b7	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:05 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:05:12.471153+00	2026-07-27 09:05:12.471153+00	\N	\N
6dd12bb2-2712-4672-a51d-9a5236fcf99b	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:05 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:05:20.110317+00	2026-07-27 09:05:20.110317+00	\N	\N
06f4a538-256a-459f-bdfe-4685eb50bb8e	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:05 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:05:31.446077+00	2026-07-27 09:05:31.446077+00	\N	\N
6b6d7516-7204-4d73-86bd-470e7bea338f	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:56 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:57:00.074623+00	2026-07-27 09:57:00.074623+00	\N	\N
8e130b65-c75f-41d5-b4a9-83c88dd02f34	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:57 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:57:13.020578+00	2026-07-27 09:57:13.020578+00	\N	\N
452481db-2a2a-4b18-81ff-bec18b071234	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 09:57 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 09:57:23.904851+00	2026-07-27 09:57:23.904851+00	\N	\N
e69d6a9b-5be8-4a3a-9d4f-66afc28e0c7d	Munazzah-association	\N	munazzah184@gmail.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Munazzah!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=pSg2lc5KkSCdioQ4lUCu3sU91f	sent	smtp	\N	\N	\N	0	3	2026-07-27 11:22:37.02843+00	2026-07-27 11:22:37.02843+00	\N	\N
916ae568-3f62-4624-8586-736a5805aa6f	Munazzah-association	\N	munazzah184@gmail.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Munazzah,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 11:23 UTC</li>\n                   	sent	smtp	\N	\N	\N	0	3	2026-07-27 11:23:37.598617+00	2026-07-27 11:23:37.598617+00	\N	\N
b9f7efd7-3b66-4d28-b28a-ad227d7c2743	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 12:27 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 12:27:56.495413+00	2026-07-27 12:27:56.495413+00	\N	\N
10a9d169-ce4d-4907-85c9-79e0ad17a189	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 13:06 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 13:06:46.897889+00	2026-07-27 13:06:46.897889+00	\N	\N
b50f35c1-cd02-43a3-86d3-00e6c48515f4	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 13:07 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 13:07:15.976352+00	2026-07-27 13:07:15.976352+00	\N	\N
3d0a3871-392a-43b2-a5aa-4cd4cb204f24	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 13:08 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 13:08:16.156032+00	2026-07-27 13:08:16.156032+00	\N	\N
e35c6c41-eda2-4afb-a075-5a5e0b81f329	demo-association	\N	daniel.harris@example.com	New login to your AssocHub account	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">New Login Detected</h2>\n                        <p>Hello Daniel,</p>\n                        <p>We noticed a new login to your AssocHub account.</p>\n                        <p><strong>Login details:</strong></p>\n                        <ul>\n                            <li>Time: July 27, 2026 at 13:11 UTC</li>\n                     	sent	smtp	\N	\N	\N	0	3	2026-07-27 13:11:04.463589+00	2026-07-27 13:11:04.463589+00	\N	\N
154c11cb-27ec-4118-b5c0-be25b69d12fd	test-tenant	\N	duplicate@test.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Dup!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=Ru9fiZuOPLl1cOw0w3VTLvGBjgJM7X5	sent	smtp	\N	\N	\N	0	3	2026-07-28 05:56:32.006134+00	2026-07-28 05:56:32.006134+00	\N	\N
63a21316-67e1-4cc4-9588-4284b41fde98	test-tenant	\N	duplicate@test.com	Verify your AssocHub email address	\n                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">\n                        <h2 style="color: #0891b2;">Welcome to AssocHub, Dup!</h2>\n                        <p>Thank you for creating an account. Please verify your email address to get started.</p>\n                        <div style="text-align: center; margin: 30px 0;">\n                            <a href="https://ams.14.jugaar.ai/verify-email?token=qaYNU_AT0mUfDbpJO48JhGeaFW9fE2d	sent	smtp	\N	\N	\N	0	3	2026-07-28 05:58:31.182686+00	2026-07-28 05:58:31.182686+00	\N	\N
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_templates (id, tenant_id, name, subject, html_body, plain_body, variables, category, is_active, created_at) FROM stdin;
dca3d142-f2b5-440c-9e67-189f7d21f87f	demo-association	Audit Template	Test	<p>Test</p>	\N	[]	general	t	2026-07-23 09:06:01.930797+00
2b7f1771-1040-48fb-a95d-a18d9d6e7c9c	demo-association	Audit Template	Test	<p>Test</p>	\N	[]	general	t	2026-07-23 09:16:05.71268+00
6ea803a0-1c14-442b-a038-420025ab6645	demo-association	Audit Template	Test	<p>Test</p>	\N	[]	general	t	2026-07-23 09:21:31.828613+00
\.


--
-- Data for Name: email_tracking_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_tracking_events (id, tenant_id, email_log_id, event_type, tracking_id, ip_address, user_agent, url, created_at) FROM stdin;
\.


--
-- Data for Name: event_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_feedback (id, event_id, member_id, session_id, tenant_id, rating, review, would_recommend, improvements, is_anonymous, created_at) FROM stdin;
292e55c8-3663-4ece-a93c-b1425d590387	27299e5f-aebf-4ddf-bd8a-32047693c2d8	ef9755e2-de75-4677-b74c-df130ec5d7a0	\N	demo-association	5	\N	\N	\N	f	2026-07-23 07:07:11.373762+00
ba8941ee-bf78-4e0f-a6a1-93ddf3499827	902fbc70-76d4-42c8-8f67-3f9de4a1c344	ef9755e2-de75-4677-b74c-df130ec5d7a0	\N	demo-association	5	\N	\N	\N	f	2026-07-23 07:09:16.286822+00
0e141488-4bce-4a3a-892b-386144bc3b44	7a8d7102-290b-4b00-8204-a94ad92d2329	ef9755e2-de75-4677-b74c-df130ec5d7a0	\N	demo-association	5	\N	\N	\N	f	2026-07-23 07:12:21.999759+00
667076e6-f11b-41f4-b799-4756cc2ee608	351e4363-912f-4ad4-b0bf-a82e7b903525	ef9755e2-de75-4677-b74c-df130ec5d7a0	\N	demo-association	5	\N	\N	\N	f	2026-07-23 07:22:53.469932+00
\.


--
-- Data for Name: event_registrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_registrations (id, event_id, member_id, tenant_id, ticket_id, status, amount_paid, payment_method, stripe_payment_id, checked_in_at, check_in_method, cancelled_at, cancellation_reason, refund_amount, dietary_restrictions, special_requirements, emergency_contact, emergency_phone, custom_fields, registered_at, updated_at) FROM stdin;
a3d745ea-0791-4298-b9a4-6ac30e0ac194	7a8d7102-290b-4b00-8204-a94ad92d2329	ef9755e2-de75-4677-b74c-df130ec5d7a0	demo-association	\N	CONFIRMED	0.00	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	{}	2026-07-23 07:20:29.62565+00	2026-07-23 07:20:29.625657+00
e39a767e-41f0-4931-b592-3dbe31c7f3d8	351e4363-912f-4ad4-b0bf-a82e7b903525	ef9755e2-de75-4677-b74c-df130ec5d7a0	demo-association	\N	CONFIRMED	0.00	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	{}	2026-07-23 07:22:53.413329+00	2026-07-23 07:22:53.413335+00
c662cf10-3aec-4f05-8f7f-504a5045a11f	82ad205f-2431-4963-8ca3-76c700aa5a8e	4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	\N	CONFIRMED	0.00	\N	\N	\N	\N	\N	\N	0.00	\N	\N	\N	\N	{}	2026-07-23 18:02:18.903509+00	2026-07-23 18:02:18.903514+00
\.


--
-- Data for Name: event_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_sessions (id, event_id, tenant_id, title, description, session_type, start_time, end_time, room, track, max_attendees, recording_url, slides_url, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: event_speakers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_speakers (id, event_id, session_id, member_id, tenant_id, name, title, company, bio, avatar_url, email, website, linkedin, twitter, is_keynote, sort_order, created_at) FROM stdin;
40839880-c766-46ed-8562-0316219d196f	351e4363-912f-4ad4-b0bf-a82e7b903525	\N	\N	demo-association	Tahira	AI Engineer	\N	AI Native Developer	\N	\N	\N	\N	\N	f	0	2026-07-23 11:05:35.436221+00
a84f5627-ff50-4b7a-9366-51de7749fe3c	351e4363-912f-4ad4-b0bf-a82e7b903525	\N	\N	demo-association	Tahira	AI Engineer	\N	AI Native Developer	\N	\N	\N	\N	\N	f	0	2026-07-23 11:05:36.423577+00
\.


--
-- Data for Name: event_sponsors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_sponsors (id, event_id, tenant_id, name, logo_url, website, tier, description, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: event_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_tickets (id, event_id, tenant_id, name, ticket_type, description, price, currency, quantity_available, quantity_sold, max_per_order, sale_start, sale_end, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, tenant_id, name, slug, description, short_description, image_url, banner_url, event_type, status, is_virtual, is_hybrid, virtual_link, virtual_platform, start_date, end_date, registration_open, registration_close, venue_name, venue_address, venue_city, venue_country, venue_lat, venue_lng, max_attendees, waitlist_enabled, max_waitlist, is_free, currency, tags, external_url, contact_email, view_count, created_by, created_at, updated_at) FROM stdin;
70a81240-8a3c-492a-a9cc-360010c519b4	demo-association	Annual Conference 2026	annual-conference-2026	Test event	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 09:00:00+00	2026-09-16 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:23:18.918434+00	2026-07-23 02:23:18.918439+00
c18d7960-64ed-4da7-8548-4420e1a45883	demo-association	Annual Conference 2026	annual-conference-2026	Test	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 09:00:00+00	2026-09-16 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:35:23.807597+00	2026-07-23 02:35:23.807601+00
5a6fb010-8aca-41ca-9939-6f02ee787a46	demo-association	Test d81f	test-d81f	Test	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 09:00:00+00	2026-09-15 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:34:31.864745+00	2026-07-23 05:34:31.864749+00
24998e7c-0266-44b9-8bbe-2d1356f6763e	demo-association	Test 248c	test-248c	Test	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 09:00:00+00	2026-09-15 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:36:32.244453+00	2026-07-23 05:36:32.244458+00
eac23187-ab72-4cd9-a07c-9b0a726ee93e	demo-association	QA Test Event	qa-test-event	Test event for QA	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:47:33.442605+00	2026-07-23 06:47:33.442609+00
70ac45da-d7fd-4d44-8ddb-d637d338348e	demo-association	QA Test Event	qa-test-event	Test event for QA	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:48:27.822991+00	2026-07-23 06:48:27.822995+00
b0179b7b-049b-41c9-8043-09b7a6b89c5a	demo-association	QA Event	qa-event	\N	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:50:38.982526+00	2026-07-23 06:50:38.982532+00
a0642f77-2d5c-4ebc-8147-56d0a2f56d53	demo-association	QA Event	qa-event	\N	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:00:28.673735+00	2026-07-23 07:00:28.673741+00
27299e5f-aebf-4ddf-bd8a-32047693c2d8	demo-association	Annual Conference 2026	annual-conference-2026	Test event	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 09:00:00+00	2026-09-16 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	3	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 01:53:06.621343+00	2026-07-23 07:09:16.004882+00
902fbc70-76d4-42c8-8f67-3f9de4a1c344	demo-association	QA Test Event	qa-test-event	Test event for QA	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:09:16.206315+00	2026-07-23 07:09:16.206322+00
34f88daf-6820-4d58-81d7-94fb7b715e92	demo-association	Annual Conference 2026	annual-conference-2026	Test	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 09:00:00+00	2026-09-16 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	3	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:11:02.499211+00	2026-07-23 07:12:21.850727+00
7a8d7102-290b-4b00-8204-a94ad92d2329	demo-association	QA2	qa2	\N	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-15 10:00:00+00	2026-09-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	1	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:12:21.919326+00	2026-07-23 07:22:53.175345+00
9fc48eec-0b06-4665-83c2-24e2ed082b53	demo-association	Audit Fixed Event	audit-fixed-event	\N	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-01 10:00:00+00	2026-09-01 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:17:12.624421+00	2026-07-23 09:17:12.624425+00
bea72030-bdd8-4ade-8d63-4b8e14593bf4	demo-association	Test Event	test-event	\N	\N	\N	\N	conference	DRAFT	f	f	\N	\N	2026-09-01 10:00:00+00	2026-09-01 17:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:22:25.2617+00	2026-07-23 09:22:25.261706+00
351e4363-912f-4ad4-b0bf-a82e7b903525	demo-association	QA	qa	\N	\N	\N	\N	conference	CANCELLED	f	f	\N	\N	2026-10-01 10:00:00+00	2026-10-01 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	5	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:22:53.35953+00	2026-07-23 11:40:48.019749+00
0725196a-6bf6-4c39-a35c-33ba71e77edf	demo-association	E2E Test Event Updated	e2e-test-event	Testing event creation end-to-end	\N	\N	\N	workshop	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 17:55:13.008536+00	2026-07-23 17:55:13.153638+00
82ad205f-2431-4963-8ca3-76c700aa5a8e	demo-association	E2E Updated	e2e-test-event-v2	Test event	\N	\N	\N	workshop	DRAFT	f	f	\N	\N	2026-08-15 10:00:00+00	2026-08-15 16:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	50	t	USD	[]	\N	\N	1	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:02:18.371542+00	2026-07-23 18:02:18.787942+00
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, tenant_id, submitted_by, approved_by, title, description, amount, currency, category, status, expense_date, submitted_at, approved_at, reimbursed_at, receipt_url, receipt_filename, budget_id, cost_center, rejection_reason, created_at, updated_at) FROM stdin;
f786d60a-4272-4cdb-bdb5-9edb77ea527e	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	\N	Test Expense	\N	25.00	USD	OPERATIONS	PENDING_APPROVAL	2026-07-23 00:00:00+00	2026-07-23 09:21:31.005255+00	\N	\N	\N	\N	\N	\N	\N	2026-07-23 09:21:19.110747+00	2026-07-23 09:21:31.006968+00
8d6353c1-6293-42b6-bf1f-fc53e8e72b93	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	\N	Test	\N	25.00	USD	OPERATIONS	PENDING_APPROVAL	2026-07-23 00:00:00+00	2026-07-23 11:03:50.429897+00	\N	\N	\N	\N	\N	\N	\N	2026-07-23 09:22:25.368473+00	2026-07-23 11:03:50.436346+00
8af41c4f-2b02-4b7a-93fd-79dedc26dbf2	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	\N	E2E Test Expense	\N	150.00	USD	OPERATIONS	DRAFT	2026-08-01 00:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-23 18:02:20.460764+00	2026-07-23 18:02:20.460769+00
3d768e41-070f-4df3-b6d8-c18e3b38bef6	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	\N	E2E Test Expense	\N	150.00	USD	OPERATIONS	DRAFT	2026-08-01 00:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-23 18:03:55.466026+00	2026-07-23 18:03:55.466031+00
04225ead-9a07-4cff-8c3a-89125bb20715	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	\N	Expense 1784829888	\N	150.00	USD	OPERATIONS	DRAFT	2026-08-01 00:00:00+00	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-23 18:04:52.795078+00	2026-07-23 18:04:52.795082+00
779a8055-77b4-46a5-adee-d79471d3f252	demo-association	f948d4f9-1d71-471b-b82a-bfed60c3fbf5	\N	Office Supplies	Office Supplies expense	340.00	USD	OPERATIONS	APPROVED	2026-06-15 07:38:00.903573+00	2026-06-15 07:38:00.903573+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.903738+00	2026-07-24 07:38:00.903738+00
98695d28-1148-48aa-bf05-04ef06991054	demo-association	657834d2-176f-45f2-b1e0-1cbc6c21e971	\N	Software Licenses	Software Licenses expense	2400.00	USD	TECHNOLOGY	APPROVED	2026-06-20 07:38:00.908587+00	2026-06-20 07:38:00.908587+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.908871+00	2026-07-24 07:38:00.908871+00
2f7f2972-bca8-4005-b146-a6ebfcafe658	demo-association	f948d4f9-1d71-471b-b82a-bfed60c3fbf5	\N	Catering - Annual Gala	Catering - Annual Gala expense	8500.00	USD	EVENTS	APPROVED	2026-04-30 07:38:00.9116+00	2026-04-30 07:38:00.9116+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.911878+00	2026-07-24 07:38:00.911878+00
09ee44b8-786a-4288-89ae-37b01590d149	demo-association	bb090ff1-bd1e-4092-8940-57fc2f94deab	\N	Venue Deposit - Leadership Summit	Venue Deposit - Leadership Summit expense	5000.00	USD	EVENTS	APPROVED	2026-05-16 07:38:00.914505+00	2026-05-16 07:38:00.914505+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.914769+00	2026-07-24 07:38:00.914769+00
a0c6f404-d610-4ae1-bc59-6b2c86c2b71e	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	\N	Marketing Materials	Marketing Materials expense	1200.00	USD	MARKETING	APPROVED	2026-06-25 07:38:00.917365+00	2026-06-25 07:38:00.917365+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.917678+00	2026-07-24 07:38:00.917678+00
8ed6c584-0f81-474c-8608-9e18693527c9	demo-association	ca7cea75-77d6-4faa-9130-db26a23f5e35	\N	Insurance Premium	Insurance Premium expense	3600.00	USD	INSURANCE	APPROVED	2026-04-18 07:38:00.920084+00	2026-04-18 07:38:00.920084+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.920383+00	2026-07-24 07:38:00.920383+00
eefc9940-d73f-4929-9861-f39de7c5a8eb	demo-association	9e8cc2d7-69ff-4f3b-9382-5b80b6922370	\N	Web Hosting (Annual)	Web Hosting (Annual) expense	800.00	USD	TECHNOLOGY	APPROVED	2026-04-22 07:38:00.922834+00	2026-04-22 07:38:00.922834+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.923073+00	2026-07-24 07:38:00.923073+00
b042e753-d121-4287-bc85-8e841950ec6b	demo-association	6557e96a-2274-4b64-9f89-dccd750107e4	\N	Speaker Fees - Tech Talk	Speaker Fees - Tech Talk expense	1500.00	USD	EVENTS	APPROVED	2026-03-29 07:38:00.925454+00	2026-03-29 07:38:00.925454+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.925736+00	2026-07-24 07:38:00.925736+00
8fdbb65d-9b90-4e1c-9096-8cb995614cfb	demo-association	891637f1-d5f7-4c13-aaae-281c12a8ebb3	\N	Printing - Member Newsletter	Printing - Member Newsletter expense	650.00	USD	OTHER	APPROVED	2026-05-09 07:38:00.928477+00	2026-05-09 07:38:00.928477+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.928785+00	2026-07-24 07:38:00.928785+00
f1ff8cc3-b4b9-4675-89dd-6c59018fb831	demo-association	657834d2-176f-45f2-b1e0-1cbc6c21e971	\N	Travel Reimbursement	Travel Reimbursement expense	1800.00	USD	TRAVEL	APPROVED	2026-07-03 07:38:00.93147+00	2026-07-03 07:38:00.93147+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.931771+00	2026-07-24 07:38:00.931771+00
5e4c9e29-255c-41f8-8a74-66d7a75dc6e2	demo-association	33d09df2-6441-457d-af99-a1bca740d92b	\N	Training Course Fees	Training Course Fees expense	2200.00	USD	PROFESSIONAL_SERVICES	APPROVED	2026-06-13 07:38:00.934221+00	2026-06-13 07:38:00.934221+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.934411+00	2026-07-24 07:38:00.934411+00
9e931a7f-1030-4673-867f-62a1e4737da7	demo-association	fa500bbe-2af8-483b-885a-94ec0de08cff	\N	Holiday Party Decorations	Holiday Party Decorations expense	900.00	USD	EVENTS	APPROVED	2026-06-27 07:38:00.936904+00	2026-06-27 07:38:00.936904+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.937253+00	2026-07-24 07:38:00.937253+00
7bc2420e-2357-41eb-b8f2-b059b6bf2b19	demo-association	baa86bca-8c83-4742-8bb5-d429b22a1577	\N	Conference Badges & Swag	Conference Badges & Swag expense	1800.00	USD	EVENTS	APPROVED	2026-05-17 07:38:00.939851+00	2026-05-17 07:38:00.939851+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.940223+00	2026-07-24 07:38:00.940223+00
edd76160-7e40-40c8-8c43-74c2015715c6	demo-association	6db475ca-90a3-4f7f-9846-5fcc99ea1415	\N	Photography Services	Photography Services expense	750.00	USD	OTHER	APPROVED	2026-07-15 07:38:00.942816+00	2026-07-15 07:38:00.942816+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:38:00.943146+00	2026-07-24 07:38:00.943146+00
290776bf-57c5-4114-b4af-3bf58ec8e004	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	\N	Office Supplies	Office Supplies expense	340.00	USD	OPERATIONS	APPROVED	2026-05-03 07:39:28.31315+00	2026-05-03 07:39:28.31315+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.313429+00	2026-07-24 07:39:28.313429+00
36424093-a0d6-47cd-9481-815f89e3d9f8	demo-association	e0183dea-662d-40e4-882d-b39c325de8b6	\N	Software Licenses	Software Licenses expense	2400.00	USD	TECHNOLOGY	APPROVED	2026-04-07 07:39:28.31975+00	2026-04-07 07:39:28.31975+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.32007+00	2026-07-24 07:39:28.32007+00
e712c724-4191-486d-b3a5-d63da1bcb46b	demo-association	ca7cea75-77d6-4faa-9130-db26a23f5e35	\N	Catering - Annual Gala	Catering - Annual Gala expense	8500.00	USD	EVENTS	APPROVED	2026-06-02 07:39:28.322964+00	2026-06-02 07:39:28.322964+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.323305+00	2026-07-24 07:39:28.323305+00
e2d92671-d0b4-46bb-894e-172d746baeb1	demo-association	baa86bca-8c83-4742-8bb5-d429b22a1577	\N	Venue Deposit	Venue Deposit expense	5000.00	USD	EVENTS	APPROVED	2026-06-10 07:39:28.326296+00	2026-06-10 07:39:28.326296+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.326583+00	2026-07-24 07:39:28.326583+00
382d7ed5-8a44-44e7-8a6e-9fb461361c66	demo-association	a52a155a-5eb0-4954-b25f-e8ea38d4a698	\N	Marketing Materials	Marketing Materials expense	1200.00	USD	MARKETING	APPROVED	2026-07-03 07:39:28.329413+00	2026-07-03 07:39:28.329413+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.329687+00	2026-07-24 07:39:28.329687+00
5b91c42a-d897-48eb-9c23-f38f26f2fe15	demo-association	66d4ca5e-6f2f-4c9a-a53a-dcf03cbaffe8	\N	Insurance Premium	Insurance Premium expense	3600.00	USD	INSURANCE	APPROVED	2026-06-24 07:39:28.332668+00	2026-06-24 07:39:28.332668+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.332931+00	2026-07-24 07:39:28.332931+00
0f6e36ea-5539-4593-a7c5-026e7ae49726	demo-association	6db475ca-90a3-4f7f-9846-5fcc99ea1415	\N	Web Hosting	Web Hosting expense	800.00	USD	TECHNOLOGY	APPROVED	2026-05-24 07:39:28.33576+00	2026-05-24 07:39:28.33576+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.336053+00	2026-07-24 07:39:28.336053+00
6bbc42a9-d2b1-444c-9ad6-4eec73c4d7e9	demo-association	baa86bca-8c83-4742-8bb5-d429b22a1577	\N	Speaker Fees	Speaker Fees expense	1500.00	USD	EVENTS	APPROVED	2026-04-24 07:39:28.338576+00	2026-04-24 07:39:28.338576+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.338854+00	2026-07-24 07:39:28.338854+00
9e972200-cd5e-4862-9597-57a06d40e150	demo-association	e0183dea-662d-40e4-882d-b39c325de8b6	\N	Newsletter Printing	Newsletter Printing expense	650.00	USD	OTHER	APPROVED	2026-04-26 07:39:28.341402+00	2026-04-26 07:39:28.341402+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.341697+00	2026-07-24 07:39:28.341697+00
c44d51be-9a07-4864-8393-8adfbdbec97c	demo-association	bb090ff1-bd1e-4092-8940-57fc2f94deab	\N	Travel Reimbursement	Travel Reimbursement expense	1800.00	USD	TRAVEL	APPROVED	2026-07-14 07:39:28.344226+00	2026-07-14 07:39:28.344226+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.344504+00	2026-07-24 07:39:28.344504+00
d824f0f5-2878-4561-8dfa-3bf5625df52f	demo-association	2722b0b7-cea9-4008-83bd-4b5c357259a4	\N	Training Courses	Training Courses expense	2200.00	USD	PROFESSIONAL_SERVICES	APPROVED	2026-04-15 07:39:28.347065+00	2026-04-15 07:39:28.347065+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.347386+00	2026-07-24 07:39:28.347386+00
7af3c415-a859-4af5-a9a4-a64146cf15eb	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	\N	Holiday Decorations	Holiday Decorations expense	900.00	USD	EVENTS	APPROVED	2026-07-19 07:39:28.349914+00	2026-07-19 07:39:28.349914+00	\N	\N	\N	\N	\N	\N	\N	2026-07-24 07:39:28.350218+00	2026-07-24 07:39:28.350218+00
\.


--
-- Data for Name: integration_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.integration_events (id, tenant_id, event_type, source_module, payload, processed, created_at) FROM stdin;
aa23aa10-457c-4eec-8da2-844a49b3b1ce	demo-association	member.created	api	{"name": "Test Webhook", "email": "test-hook@example.com"}	t	2026-07-24 10:29:31.529203+00
fb43a97b-90b8-47c6-b62e-744c47aa0e06	demo-association	member.created	api	{"name": "Test"}	t	2026-07-24 10:30:49.149218+00
82080bde-80c6-4d70-80d6-8a78799e0ac4	demo-association	member.created	api	{"name": "Test"}	t	2026-07-24 10:33:48.125913+00
0ddb9fe7-8c2a-4938-b321-4e83abab4d1a	demo-association	member.created	api	{"name": "John Doe", "email": "john@test.com"}	f	2026-07-24 10:41:11.537128+00
c4892c6f-5a5c-4207-b7ae-a83815ef25b2	demo-association	member.created	members	{"member_id": "74930db4-eae7-48b8-8ad1-0d26f6292bb8", "email": "webhook-test-1784889740@example.com", "name": "Webhook Test"}	f	2026-07-24 10:42:21.882505+00
631b52f5-1a8a-47eb-812c-fef1c47336b3	demo-association	member.created	members	{"member_id": "5a44618c-af1a-4797-85f9-7e3492418274", "email": "webhook-test-1784891127@example.com", "name": "Test Webhook"}	f	2026-07-24 11:05:27.891731+00
524fdf01-d3ec-43f5-b4ae-e9b5b736bc67	demo-association	member.created	api	{"name": "Manual Emit Test", "email": "manual@test.com"}	f	2026-07-24 11:05:31.24667+00
14a84eca-c4bb-480c-b5c7-9faec7ba3c67	demo-association	invoice.created	finances	{"invoice_id": "2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf", "invoice_number": "INV-2026-00014", "total": 323.67, "member_id": "c8ada24d-1dec-4f9e-b0f7-3be95ebabf14"}	f	2026-07-27 08:00:41.661955+00
b37d2c9d-3c0e-4301-97a2-9fd9b3d22a79	demo-association	invoice.created	finances	{"invoice_id": "e60a7ec2-2b32-47b4-a8ad-427c862a9744", "invoice_number": "INV-2026-00015", "total": 431.92, "member_id": "3f5dc381-5b1d-499f-9a1f-9a4be253fde5"}	f	2026-07-27 08:35:25.026699+00
cca68914-6bcb-495c-b317-82ea843dd6c6	demo-association	invoice.created	finances	{"invoice_id": "8f029a0c-f544-48d6-9775-1b084bd24994", "invoice_number": "INV-2026-00016", "total": 323.67, "member_id": "3f5dc381-5b1d-499f-9a1f-9a4be253fde5"}	f	2026-07-27 08:53:29.585416+00
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.integrations (id, tenant_id, name, integration_type, status, config, webhook_url, last_sync_at, error_message, created_at, updated_at) FROM stdin;
b09728f8-ce8b-4f93-b8b1-2a610d786bf0	demo-association	Stripe	STRIPE	PENDING	{"api_key": "sk_test_demo"}	\N	\N	\N	2026-07-23 01:53:10.087194+00	2026-07-23 01:53:10.087198+00
d82c7bff-f987-46f2-b406-09da0a8b88aa	demo-association	Slack Notifications	SLACK	PENDING	{"bot_token": "xoxb-demo"}	\N	\N	\N	2026-07-23 02:11:06.049839+00	2026-07-23 02:11:06.049842+00
d4166243-8187-4408-9aa2-0956be170ee2	demo-association	Slack Notifications	SLACK	PENDING	{"bot_token": "xoxb-demo"}	\N	\N	\N	2026-07-23 02:23:21.977594+00	2026-07-23 02:23:21.977598+00
2c38e58c-8276-416b-9fad-4554cd4b51f7	demo-association	Slack Notifications 2	SLACK	PENDING	{"bot_token": "xoxb-demo2"}	\N	\N	\N	2026-07-23 02:35:27.586442+00	2026-07-23 02:35:27.586446+00
30b8b2ca-e3bc-47c9-aaee-2b19116529c8	demo-association	QA Test	CUSTOM	PENDING	{"url": "https://example.com"}	\N	\N	\N	2026-07-23 06:59:14.407662+00	2026-07-23 06:59:14.407667+00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, tenant_id, invoice_number, member_id, dues_structure_id, event_id, status, subtotal, tax_rate, tax_amount, discount_amount, total, amount_paid, currency, line_items, issued_at, due_at, paid_at, cancelled_at, notes, internal_notes, stripe_invoice_id, stripe_payment_intent_id, created_at, updated_at, discount_code_id) FROM stdin;
0131c25d-fdc5-48a3-ac8b-f1bdb0d5d70e	demo-association	INV-2026-00001	ff65bee0-ef02-470a-a797-d032057feb7f	\N	\N	PENDING	100.00	0.00	0.00	0.00	100.00	0.00	USD	[{"description": "Test", "quantity": 1, "unit_price": 100.0}]	2026-07-23 05:36:12.907155+00	2026-08-22 05:36:12.904391+00	\N	\N	Updated	\N	\N	\N	2026-07-23 05:36:12.90716+00	2026-07-23 09:16:03.847074+00	\N
c25b36dc-3aa5-463f-955f-39cb0b7d430e	demo-association	INV-2026-00002	cef78bee-8e20-495f-9635-9890c299f0e2	\N	\N	PENDING	50.00	0.00	0.00	0.00	50.00	0.00	USD	[{"description": "Test", "quantity": 1, "unit_price": 50.0}]	2026-07-23 09:17:12.817361+00	2026-08-22 09:17:12.814158+00	\N	\N	Updated	\N	\N	\N	2026-07-23 09:17:12.817365+00	2026-07-23 09:17:14.402139+00	\N
d08d0be9-37e3-4137-a4d8-8b7deb2833e1	demo-association	INV-2026-00003	cef78bee-8e20-495f-9635-9890c299f0e2	\N	\N	PENDING	50.00	0.00	0.00	0.00	50.00	0.00	USD	[{"description": "Test", "quantity": 1, "unit_price": 50.0}]	2026-07-23 09:22:24.348762+00	2026-08-22 09:22:24.345012+00	\N	\N	Updated	\N	\N	\N	2026-07-23 09:22:24.348766+00	2026-07-23 09:22:25.184611+00	\N
c27ba667-e673-448d-a65d-691ca160b981	demo-association	INV-2026-0001	1f3bbb19-e518-4e44-b424-9c83490dcf9c	\N	\N	PAID	250.00	0.08	20.00	0.00	270.00	270.00	USD	\N	2026-06-18 07:40:11.218386+00	2026-07-18 07:40:11.218386+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.262782+00	2026-07-24 07:40:11.262782+00	\N
0e0ad962-8549-4ed8-9211-1a7603505250	demo-association	INV-2026-0002	aba2c4a6-a717-4358-a128-8c3ee346778c	\N	\N	PAID	150.00	0.08	12.00	0.00	162.00	162.00	USD	\N	2026-05-27 07:40:11.268473+00	2026-06-26 07:40:11.268473+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.269099+00	2026-07-24 07:40:11.269099+00	\N
2af2b13f-e9f4-40fa-a05c-157f0f14b52d	demo-association	INV-2026-0003	16b55edd-5043-4c89-8cb9-e0b25a5f4cfe	\N	\N	PAID	399.00	0.00	0.00	0.00	399.00	399.00	USD	\N	2026-05-01 07:40:11.272117+00	2026-05-31 07:40:11.272117+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.27259+00	2026-07-24 07:40:11.27259+00	\N
74e21d90-09df-489a-b551-08f7284e4e2c	demo-association	INV-2026-0004	d5aafbbe-6ee7-4de3-9fe7-6162f5e1ae05	\N	\N	PENDING	500.00	0.08	40.00	0.00	540.00	0.00	USD	\N	2026-07-02 07:40:11.275631+00	2026-08-01 07:40:11.275631+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.276092+00	2026-07-24 07:40:11.276092+00	\N
72608766-f654-422b-97a7-48b1bf7f5670	demo-association	INV-2026-0005	4e9dec12-a0de-4517-87a8-e272539aa6f4	\N	\N	PENDING	75.00	0.08	6.00	0.00	81.00	0.00	USD	\N	2026-06-07 07:40:11.278939+00	2026-07-07 07:40:11.278939+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.279434+00	2026-07-24 07:40:11.279434+00	\N
3b0b986c-bfc7-4032-bbb9-0b48af881276	demo-association	INV-2026-0006	1f3bbb19-e518-4e44-b424-9c83490dcf9c	\N	\N	OVERDUE	1500.00	0.10	150.00	0.00	1650.00	0.00	USD	\N	2026-05-10 07:40:11.282018+00	2026-06-09 07:40:11.282018+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.282521+00	2026-07-24 07:40:11.282521+00	\N
2e66d3da-4466-4e1d-b7fa-45c79376d531	demo-association	INV-2026-0007	a292507b-3092-455c-817e-a5ddfc22c22e	\N	\N	DRAFT	299.00	0.00	0.00	0.00	299.00	0.00	USD	\N	2026-05-25 07:40:11.285561+00	2026-06-24 07:40:11.285561+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.28606+00	2026-07-24 07:40:11.28606+00	\N
58420297-0992-4ee3-aadf-1fca0da8ca44	demo-association	INV-2026-0008	1f3bbb19-e518-4e44-b424-9c83490dcf9c	\N	\N	PAID	100.00	0.08	8.00	0.00	108.00	108.00	USD	\N	2026-07-11 07:40:11.288925+00	2026-08-10 07:40:11.288925+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.289514+00	2026-07-24 07:40:11.289514+00	\N
84bbff9d-c9e0-41ff-984e-c53f7e77a47c	demo-association	INV-2026-0009	44918c2d-9359-48ce-b7fb-3f8e66242525	\N	\N	PAID	2000.00	0.08	160.00	100.00	2060.00	2060.00	USD	\N	2026-06-15 07:40:11.29208+00	2026-07-15 07:40:11.29208+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.292607+00	2026-07-24 07:40:11.292607+00	\N
b64a2e69-041b-4eb9-aa4d-65d9a9a1b9dc	demo-association	INV-2026-0010	69f3398b-6ddd-4b93-8d84-b771773c30b0	\N	\N	PAID	450.00	0.08	36.00	0.00	486.00	486.00	USD	\N	2026-06-29 07:40:11.295224+00	2026-07-29 07:40:11.295224+00	\N	\N	Invoice	\N	\N	\N	2026-07-24 07:40:11.295713+00	2026-07-24 07:40:11.295713+00	\N
2912964c-1f8d-4d0f-9b0f-7eb2f4cb1edf	demo-association	INV-2026-00014	c8ada24d-1dec-4f9e-b0f7-3be95ebabf14	\N	\N	PENDING	299.00	8.25	24.67	0.00	323.67	0.00	USD	[{"description": "Annual Membership Dues 2026", "quantity": 1, "unit_price": 299.0}]	2026-07-27 08:00:40.631824+00	2026-08-26 08:00:40.611338+00	\N	\N	Thank you	\N	\N	\N	2026-07-27 08:00:40.631835+00	2026-07-27 08:00:40.63184+00	\N
e60a7ec2-2b32-47b4-a8ad-427c862a9744	demo-association	INV-2026-00015	3f5dc381-5b1d-499f-9a1f-9a4be253fde5	\N	\N	PAID	399.00	8.25	32.92	0.00	431.92	431.92	USD	[{"description": "Annual Membership Dues 2026", "quantity": 1, "unit_price": 299.0}, {"description": "Event Registration - Annual Gala", "quantity": 2, "unit_price": 50.0}]	2026-07-27 08:35:24.241535+00	2026-08-26 08:35:24.232257+00	2026-07-27 08:40:07.233853+00	\N	Thank you for your continued membership!	\N	\N	\N	2026-07-27 08:35:24.24154+00	2026-07-27 08:40:07.244337+00	\N
8f029a0c-f544-48d6-9775-1b084bd24994	demo-association	INV-2026-00016	3f5dc381-5b1d-499f-9a1f-9a4be253fde5	\N	\N	PENDING	299.00	8.25	24.67	0.00	323.67	0.00	USD	[{"description": "Annual Membership Dues 2026", "quantity": 1, "unit_price": 299.0}]	2026-07-27 08:53:28.770732+00	2026-08-26 08:53:28.763011+00	\N	\N	Thank you	\N	\N	\N	2026-07-27 08:53:28.770738+00	2026-07-27 08:53:28.77074+00	\N
\.


--
-- Data for Name: kpi_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_snapshots (id, tenant_id, metric_name, metric_value, metric_unit, dimensions, snapshot_date, created_at) FROM stdin;
\.


--
-- Data for Name: member_activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_activity_logs (id, tenant_id, user_id, action, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: member_group_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_group_memberships (id, member_id, group_id, role, joined_at, left_at, is_active) FROM stdin;
d7bae8f5-a116-4262-b352-747e7780fbc7	536b9bf9-2955-4007-97d9-70b02de64bf4	adac4ccd-29ee-49bd-8711-5bf126a504b3	CO_CHAIR	2026-07-22 14:12:07.080624+00	\N	t
65bc482e-9a56-426a-847e-d5c8cb1f50e5	7a6bf789-3643-4cae-89ad-89f89c9e85ce	adac4ccd-29ee-49bd-8711-5bf126a504b3	CO_CHAIR	2026-07-22 14:12:07.080674+00	\N	t
d3062a3e-22ba-4506-8033-a2ef8ebf05bf	1f3bbb19-e518-4e44-b424-9c83490dcf9c	adac4ccd-29ee-49bd-8711-5bf126a504b3	CO_CHAIR	2026-07-22 14:12:07.08071+00	\N	t
d0b65908-5a2b-4093-9b6b-a5ed0ab3348f	7f12d7f6-6eee-4de6-a884-9867e0f28a21	adac4ccd-29ee-49bd-8711-5bf126a504b3	CHAIR	2026-07-22 14:12:07.080744+00	\N	t
55abf35b-ee55-4b13-a06f-f3e20977c7a2	422d7eb1-2ff0-4616-85fa-01e9d8f94b6d	adac4ccd-29ee-49bd-8711-5bf126a504b3	CHAIR	2026-07-22 14:12:07.080779+00	\N	t
791c7ed2-9223-4fd1-b0fc-c181096db802	35e9c0db-761d-4520-ac49-c5d7842cf39b	adac4ccd-29ee-49bd-8711-5bf126a504b3	MEMBER	2026-07-22 14:12:07.08083+00	\N	t
d32e8683-8ea8-4c70-ac71-21230d20f186	c6b953a4-74a7-4522-a4f9-50a6f6369a7a	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	MEMBER	2026-07-22 14:12:07.080859+00	\N	t
3628ae71-d901-4c30-950e-4fa3295062a9	a78c08e7-9a44-4a5e-954e-b7cf7374ab90	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	CHAIR	2026-07-22 14:12:07.080887+00	\N	t
bd1d5fdd-3e75-4e4d-8a33-7b0f81b1b9cb	a2a6608d-4782-48ed-a4e9-85b9c5376cf0	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	CO_CHAIR	2026-07-22 14:12:07.080915+00	\N	t
5ca7b190-64c5-41f7-b140-8f18c8bb20b5	e29228a1-843d-46c9-a98f-bb4871906474	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	MEMBER	2026-07-22 14:12:07.080943+00	\N	t
c4ff6aca-aa05-498b-a29f-3039b2e725fd	35e9c0db-761d-4520-ac49-c5d7842cf39b	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	CO_CHAIR	2026-07-22 14:12:07.08097+00	\N	t
c451923b-d98f-4372-b3b2-67754c1de477	96041d0f-9b6b-43cb-b0da-466a380b8a17	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	MEMBER	2026-07-22 14:12:07.080998+00	\N	t
4e965210-3845-4c6e-a3c6-efc9e315a4f6	536b9bf9-2955-4007-97d9-70b02de64bf4	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	MEMBER	2026-07-22 14:12:07.081036+00	\N	t
2e36853e-3530-454c-a5ea-8da71e52a479	98d8e1bf-4488-4919-9276-37a757cac49d	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	CHAIR	2026-07-22 14:12:07.081064+00	\N	t
488a9753-c688-4bd1-a243-1749009b9952	a7050b39-19bc-4b1c-8540-801da2293631	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	MEMBER	2026-07-22 14:12:07.081092+00	\N	t
41d700ff-0b05-4605-8aca-16f9506171c4	c001f1f7-2c35-4292-be02-f6ac238d0b5a	d3ec7f40-72b9-4f52-bd72-1abac8d5919c	CO_CHAIR	2026-07-22 14:12:07.081122+00	\N	t
d796c2cf-c498-4904-b620-6a4db34cf7c7	61f81093-c69d-4fa0-97bc-5a36f539a97a	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	MEMBER	2026-07-22 14:12:07.081155+00	\N	t
51799e2a-73e5-40f0-9342-0d728c114d23	200e6a0c-5764-47be-b4c8-bbcc2478e6ad	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	MEMBER	2026-07-22 14:12:07.081219+00	\N	t
6c30e43f-81d1-4923-ba5c-c51623aed252	a292507b-3092-455c-817e-a5ddfc22c22e	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	CO_CHAIR	2026-07-22 14:12:07.081254+00	\N	t
13f2c6f9-ee23-437a-b79f-21ac5d1c770a	4e9dec12-a0de-4517-87a8-e272539aa6f4	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	MEMBER	2026-07-22 14:12:07.081283+00	\N	t
6ba32332-b16b-4e72-9d28-b4e6f8faa481	16b55edd-5043-4c89-8cb9-e0b25a5f4cfe	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	CO_CHAIR	2026-07-22 14:12:07.08131+00	\N	t
3bb66cc6-d7a7-427a-a1c2-1ded185882f5	fa183c56-a9e2-440e-b188-464f5d841035	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	CO_CHAIR	2026-07-22 14:12:07.081337+00	\N	t
3c1e0a79-63f8-4773-a8c7-f8575c80f10e	ef9755e2-de75-4677-b74c-df130ec5d7a0	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	CHAIR	2026-07-22 14:12:07.081364+00	\N	t
ec016f66-7c8c-4c81-9114-3acfba0b158d	8ce0d21d-1b3b-483c-8f66-eccda38568ee	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	CO_CHAIR	2026-07-22 14:12:07.081392+00	\N	t
fe436a43-7d82-41ed-bb35-eb7599da7ba3	04414b2a-7731-44aa-9346-bebc1cb5bce6	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	MEMBER	2026-07-22 14:12:07.081419+00	\N	t
bcefccf7-6907-4391-93da-9b1274784c1c	4f58899c-591c-43b7-afd6-7cfa419a7be5	dc7e937f-5439-4de4-9ae6-f7891f26fcc5	MEMBER	2026-07-22 14:12:07.081446+00	\N	t
000c1086-9779-40f8-a928-dc356e890133	f98236b9-934b-460a-904e-7664cba49732	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081475+00	\N	t
abe8e9c3-b53f-4b24-b606-ca5412b51ab0	80dd1285-5e60-4737-8ab3-810863bb191e	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081503+00	\N	t
8249d6c6-e60c-4ee6-a078-24113ba026a6	4e9dec12-a0de-4517-87a8-e272539aa6f4	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.08153+00	\N	t
45208fa1-803d-4bb8-bff3-c0127d87d068	0acd0d34-4434-4d97-9167-f2048f2a82bd	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081558+00	\N	t
49d67f73-0743-4261-b9c0-ec6fff4a26fa	3aaf9d8c-3494-48ed-8356-7c5fc3a28d01	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081585+00	\N	t
2307fe89-2ecb-48c1-a7f3-412350692523	b12cfcd9-7591-4933-8158-23a6757fabe9	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081616+00	\N	t
72a625f4-b3f0-40fa-acd0-3637adfb75b2	72e21103-981f-4654-b6c2-35ba50adcde6	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	CO_CHAIR	2026-07-22 14:12:07.081648+00	\N	t
bd5868c9-9a8c-4a67-86d5-f1ec6dea5241	fa183c56-a9e2-440e-b188-464f5d841035	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081682+00	\N	t
0a3b0da9-b22a-4f27-b51b-8cf440e2d377	a2a6608d-4782-48ed-a4e9-85b9c5376cf0	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081729+00	\N	t
341459f7-e690-4763-a83b-51b9c3fdbf16	69f3398b-6ddd-4b93-8d84-b771773c30b0	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	CHAIR	2026-07-22 14:12:07.081758+00	\N	t
70605886-63a0-4b7b-821d-0e3ebcb08cb5	61f81093-c69d-4fa0-97bc-5a36f539a97a	8d55f901-5e9f-45ea-ae9e-cb267ae2d577	MEMBER	2026-07-22 14:12:07.081785+00	\N	t
518a169a-f775-4c57-b37f-4aa8e977fe5e	61f81093-c69d-4fa0-97bc-5a36f539a97a	99513c80-38da-45c6-96fd-bc2c683fbfd8	MEMBER	2026-07-22 14:12:07.08183+00	\N	t
0483dfde-d718-49bb-946b-5c35f8adddff	98d8e1bf-4488-4919-9276-37a757cac49d	99513c80-38da-45c6-96fd-bc2c683fbfd8	MEMBER	2026-07-22 14:12:07.081859+00	\N	t
d735d526-af80-4c42-988f-18a26e27bc61	255e9ff3-c368-455b-aef3-4bbae75b8e62	99513c80-38da-45c6-96fd-bc2c683fbfd8	MEMBER	2026-07-22 14:12:07.081886+00	\N	t
31d395df-6e65-47b9-9bdd-4134f81de47c	aba2c4a6-a717-4358-a128-8c3ee346778c	99513c80-38da-45c6-96fd-bc2c683fbfd8	CO_CHAIR	2026-07-22 14:12:07.081913+00	\N	t
abc9914c-31d7-4b92-bc55-f320f3fc84a6	25cfb547-2fb3-4548-957b-89765d7c30d6	99513c80-38da-45c6-96fd-bc2c683fbfd8	CHAIR	2026-07-22 14:12:07.08194+00	\N	t
de347096-5487-48fc-999a-63782a61d9c2	536b9bf9-2955-4007-97d9-70b02de64bf4	99513c80-38da-45c6-96fd-bc2c683fbfd8	CO_CHAIR	2026-07-22 14:12:07.081967+00	\N	t
bf4b9856-5d26-4cc1-a320-836b4f531d7a	a795ccdb-1455-4d98-a03f-2abd69c23ad7	99513c80-38da-45c6-96fd-bc2c683fbfd8	MEMBER	2026-07-22 14:12:07.081995+00	\N	t
9bc07562-797c-4f83-8411-8acf8da91c88	422d7eb1-2ff0-4616-85fa-01e9d8f94b6d	99513c80-38da-45c6-96fd-bc2c683fbfd8	CO_CHAIR	2026-07-22 14:12:07.082022+00	\N	t
63a4a729-a4e9-4271-8382-bf9baf858d97	d5aafbbe-6ee7-4de3-9fe7-6162f5e1ae05	db7059d6-9890-4f5f-8ed8-894e53282723	MEMBER	2026-07-22 14:12:07.082049+00	\N	t
0d5b794b-bc21-4db2-a696-6fb07a3abc60	77c29388-e3c5-435b-bd22-0b204f7f97a9	db7059d6-9890-4f5f-8ed8-894e53282723	CO_CHAIR	2026-07-22 14:12:07.082076+00	\N	t
4e256e64-dea5-450f-bd43-447a5c184c2a	aba2c4a6-a717-4358-a128-8c3ee346778c	db7059d6-9890-4f5f-8ed8-894e53282723	CHAIR	2026-07-22 14:12:07.082108+00	\N	t
4f5f6dc7-bc58-40b8-a0be-0b27bd5d5337	ef9755e2-de75-4677-b74c-df130ec5d7a0	db7059d6-9890-4f5f-8ed8-894e53282723	MEMBER	2026-07-22 14:12:07.082141+00	\N	t
a137284b-43bb-4299-9d41-7c52482da13b	a78c08e7-9a44-4a5e-954e-b7cf7374ab90	db7059d6-9890-4f5f-8ed8-894e53282723	MEMBER	2026-07-22 14:12:07.082205+00	\N	t
8b50529b-7373-4900-b529-64607c2bcf85	69f3398b-6ddd-4b93-8d84-b771773c30b0	db7059d6-9890-4f5f-8ed8-894e53282723	MEMBER	2026-07-22 14:12:07.082239+00	\N	t
807c7584-d769-4804-8af9-19234595712b	61f81093-c69d-4fa0-97bc-5a36f539a97a	d8884d58-346a-4384-ba6c-5ea7d557fcca	CO_CHAIR	2026-07-22 14:12:07.082266+00	\N	t
dc535ba4-97d3-4da4-917f-4ef710151e4d	fa183c56-a9e2-440e-b188-464f5d841035	d8884d58-346a-4384-ba6c-5ea7d557fcca	MEMBER	2026-07-22 14:12:07.082293+00	\N	t
c3d822a2-b7af-40be-86d5-e05f7478d88b	bc358cc0-31fb-4e3d-86ff-24a8c2075222	d8884d58-346a-4384-ba6c-5ea7d557fcca	MEMBER	2026-07-22 14:12:07.082321+00	\N	t
1fea4bb5-a8e5-4a48-b273-ea6b94e3b376	00612962-5402-4b5a-b3cb-bbded7ebe8fe	d8884d58-346a-4384-ba6c-5ea7d557fcca	CHAIR	2026-07-22 14:12:07.082348+00	\N	t
911f617b-fb3e-43b4-9b71-f828f02685ea	c001f1f7-2c35-4292-be02-f6ac238d0b5a	d8884d58-346a-4384-ba6c-5ea7d557fcca	CHAIR	2026-07-22 14:12:07.082375+00	\N	t
db95507c-9536-4368-85ad-eb1cbc1747f6	44918c2d-9359-48ce-b7fb-3f8e66242525	d8884d58-346a-4384-ba6c-5ea7d557fcca	MEMBER	2026-07-22 14:12:07.082402+00	\N	t
db5fc89d-7daa-419b-8276-214629728ebe	3aaf9d8c-3494-48ed-8356-7c5fc3a28d01	d8884d58-346a-4384-ba6c-5ea7d557fcca	CO_CHAIR	2026-07-22 14:12:07.082429+00	\N	t
eaa68967-9c7f-435a-89d4-3823ad79cdb3	536b9bf9-2955-4007-97d9-70b02de64bf4	d8884d58-346a-4384-ba6c-5ea7d557fcca	MEMBER	2026-07-22 14:12:07.082456+00	\N	t
95c35719-606d-47d4-b253-8ebe836046d3	c6b953a4-74a7-4522-a4f9-50a6f6369a7a	208da7e0-0899-43e2-9a64-83c78ae23925	CO_CHAIR	2026-07-22 14:12:07.082483+00	\N	t
7ae5e1ce-059b-4efe-817e-ad6ef33f50ac	a2633314-0ac1-493a-b2ab-ac464d1e6ff3	208da7e0-0899-43e2-9a64-83c78ae23925	CHAIR	2026-07-22 14:12:07.08251+00	\N	t
9879d627-e43d-4790-a813-205bd1cca5c2	255e9ff3-c368-455b-aef3-4bbae75b8e62	208da7e0-0899-43e2-9a64-83c78ae23925	MEMBER	2026-07-22 14:12:07.082537+00	\N	t
b6983282-6a39-4317-8993-14f3c2021d5a	7a6bf789-3643-4cae-89ad-89f89c9e85ce	208da7e0-0899-43e2-9a64-83c78ae23925	CHAIR	2026-07-22 14:12:07.082564+00	\N	t
b649134b-82b8-489d-99c5-10b94c657756	16b55edd-5043-4c89-8cb9-e0b25a5f4cfe	3623901d-8362-432e-a72f-95e9e8e3e33f	MEMBER	2026-07-22 14:12:07.082596+00	\N	t
edc57d1d-78df-4e8b-ae74-3a591089c4f4	bc358cc0-31fb-4e3d-86ff-24a8c2075222	3623901d-8362-432e-a72f-95e9e8e3e33f	CHAIR	2026-07-22 14:12:07.08263+00	\N	t
18c2f1aa-b8da-46b8-b165-e6df180f73b6	28bdb4cc-21b3-4acd-8bbc-daf71f575861	3623901d-8362-432e-a72f-95e9e8e3e33f	MEMBER	2026-07-22 14:12:07.082663+00	\N	t
cb8efcf9-b2c3-4a0f-b04c-1fa926d7306d	77c29388-e3c5-435b-bd22-0b204f7f97a9	3623901d-8362-432e-a72f-95e9e8e3e33f	CHAIR	2026-07-22 14:12:07.0827+00	\N	t
0a01ffb1-2805-44b6-b516-b31285fef05b	7a6bf789-3643-4cae-89ad-89f89c9e85ce	107ce559-0739-420f-b4af-32f3e19e778e	MEMBER	2026-07-22 14:12:07.082733+00	\N	t
bfd1f86f-4afb-44e0-b7bc-f49e0ffeceb7	25cfb547-2fb3-4548-957b-89765d7c30d6	107ce559-0739-420f-b4af-32f3e19e778e	CO_CHAIR	2026-07-22 14:12:07.08276+00	\N	t
0e8e5937-c19c-4e15-8271-08cf3dd7434b	536b9bf9-2955-4007-97d9-70b02de64bf4	107ce559-0739-420f-b4af-32f3e19e778e	MEMBER	2026-07-22 14:12:07.082788+00	\N	t
dbf457d2-fdf2-4b56-bb0f-55367843089c	aba2c4a6-a717-4358-a128-8c3ee346778c	107ce559-0739-420f-b4af-32f3e19e778e	MEMBER	2026-07-22 14:12:07.082836+00	\N	t
06a48f0f-52c1-4f0a-b3e2-302b4449937a	866a7d12-67ad-4027-ba28-9c56838f720e	107ce559-0739-420f-b4af-32f3e19e778e	CO_CHAIR	2026-07-22 14:12:07.082865+00	\N	t
\.


--
-- Data for Name: member_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_groups (id, tenant_id, name, description, group_type, parent_id, max_members, is_active, meeting_schedule, contact_email, metadata_json, created_at) FROM stdin;
adac4ccd-29ee-49bd-8711-5bf126a504b3	demo-association	Board of Directors	Governing board	BOARD	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410709+00
d3ec7f40-72b9-4f52-bd72-1abac8d5919c	demo-association	Finance Committee	Oversees financial matters	COMMITTEE	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410729+00
dc7e937f-5439-4de4-9ae6-f7891f26fcc5	demo-association	Membership Committee	Recruitment and retention	COMMITTEE	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410744+00
8d55f901-5e9f-45ea-ae9e-cb267ae2d577	demo-association	Events Committee	Plans and executes events	COMMITTEE	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410758+00
99513c80-38da-45c6-96fd-bc2c683fbfd8	demo-association	Communications Committee	Marketing and outreach	COMMITTEE	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410773+00
db7059d6-9890-4f5f-8ed8-894e53282723	demo-association	Policy & Advocacy	Policy positions and advocacy	COMMITTEE	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410786+00
d8884d58-346a-4384-ba6c-5ea7d557fcca	demo-association	Northeast Chapter	Regional chapter	CHAPTER	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410813+00
208da7e0-0899-43e2-9a64-83c78ae23925	demo-association	West Coast Chapter	Regional chapter	CHAPTER	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410827+00
3623901d-8362-432e-a72f-95e9e8e3e33f	demo-association	Technology Interest Group	Tech enthusiasts	INTEREST_GROUP	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410841+00
107ce559-0739-420f-b4af-32f3e19e778e	demo-association	Mentorship Program	Peer mentorship	WORKING_GROUP	\N	\N	t	\N	\N	{}	2026-07-22 14:12:06.410855+00
\.


--
-- Data for Name: member_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_notes (id, tenant_id, member_id, author_id, content, is_pinned, created_at) FROM stdin;
c2c531cf-48ff-4649-bba9-d831bb2e4b30	demo-association	2abf0009-0b79-4866-9e7d-f36cb4451682	ca028c51-23b8-4ae5-b945-2ce378a92ab3	Test note	f	2026-07-23 09:16:02.960456+00
91ef9e5c-30e3-480f-a075-cb23d2ee4fb5	demo-association	ef9755e2-de75-4677-b74c-df130ec5d7a0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	Audit test	f	2026-07-23 09:17:12.602238+00
7d506088-2db5-4314-8cfe-9b6dc5469c25	demo-association	2abf0009-0b79-4866-9e7d-f36cb4451682	ca028c51-23b8-4ae5-b945-2ce378a92ab3	Test note	f	2026-07-23 09:21:30.390761+00
2c2d0a4d-6804-4db7-8ddf-64b1f4dac24b	demo-association	ef9755e2-de75-4677-b74c-df130ec5d7a0	ca028c51-23b8-4ae5-b945-2ce378a92ab3	Test note	f	2026-07-23 09:22:24.31541+00
ac22bd62-be2e-419e-8c88-7d3dcb0213bf	demo-association	27f4b9ed-31a0-44d9-8ecb-ea26c321432d	ca028c51-23b8-4ae5-b945-2ce378a92ab3	test note	f	2026-07-23 11:08:11.132424+00
b84411a2-0e4c-4b5d-85ea-ce23335f555c	demo-association	0acd0d34-4434-4d97-9167-f2048f2a82bd	ca028c51-23b8-4ae5-b945-2ce378a92ab3	test	f	2026-07-23 11:40:47.7768+00
4f91481b-0b94-44a2-a34d-cfb9b77a39cc	demo-association	f62c9f98-76ff-4142-87d7-fd21d0921deb	ca028c51-23b8-4ae5-b945-2ce378a92ab3	E2E test note	f	2026-07-23 11:42:55.127515+00
\.


--
-- Data for Name: member_profile_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_profile_tags (member_id, tag_id) FROM stdin;
4f58899c-591c-43b7-afd6-7cfa419a7be5	83bf89d2-f5b8-4a08-a8a2-6ad6884ef21a
ef9755e2-de75-4677-b74c-df130ec5d7a0	a05d9421-847b-48c9-8162-4f55d8dda124
ef9755e2-de75-4677-b74c-df130ec5d7a0	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
ef9755e2-de75-4677-b74c-df130ec5d7a0	45d0a46e-fff7-4f58-8a71-894efab3fe9f
16b55edd-5043-4c89-8cb9-e0b25a5f4cfe	5fa71c92-40be-43bb-85f0-ccad3c205c69
16b55edd-5043-4c89-8cb9-e0b25a5f4cfe	45d0a46e-fff7-4f58-8a71-894efab3fe9f
8ce0d21d-1b3b-483c-8f66-eccda38568ee	ea407112-bcd4-4a48-be29-c46df2f90562
8ce0d21d-1b3b-483c-8f66-eccda38568ee	74ffab39-fb92-415f-a2d7-2d6820f58f96
96041d0f-9b6b-43cb-b0da-466a380b8a17	ea407112-bcd4-4a48-be29-c46df2f90562
04414b2a-7731-44aa-9346-bebc1cb5bce6	74ffab39-fb92-415f-a2d7-2d6820f58f96
04414b2a-7731-44aa-9346-bebc1cb5bce6	95f08bfc-d702-400e-bce0-e74ca8adb497
04414b2a-7731-44aa-9346-bebc1cb5bce6	ea407112-bcd4-4a48-be29-c46df2f90562
a2a6608d-4782-48ed-a4e9-85b9c5376cf0	3d5ef800-fe2e-4a67-835b-7f454dbb8c5b
84b4a18c-7d13-4c74-9d7d-5033401e971a	ea407112-bcd4-4a48-be29-c46df2f90562
84b4a18c-7d13-4c74-9d7d-5033401e971a	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
84b4a18c-7d13-4c74-9d7d-5033401e971a	74ffab39-fb92-415f-a2d7-2d6820f58f96
1f3bbb19-e518-4e44-b424-9c83490dcf9c	45d0a46e-fff7-4f58-8a71-894efab3fe9f
1f3bbb19-e518-4e44-b424-9c83490dcf9c	ea407112-bcd4-4a48-be29-c46df2f90562
28bdb4cc-21b3-4acd-8bbc-daf71f575861	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
25cfb547-2fb3-4548-957b-89765d7c30d6	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
32f2ecf3-bf79-463c-b4d2-587c1d6abb38	a14d3085-8a5c-48ee-92e8-cd580420cbdd
32f2ecf3-bf79-463c-b4d2-587c1d6abb38	a05d9421-847b-48c9-8162-4f55d8dda124
a292507b-3092-455c-817e-a5ddfc22c22e	95f08bfc-d702-400e-bce0-e74ca8adb497
a292507b-3092-455c-817e-a5ddfc22c22e	a05d9421-847b-48c9-8162-4f55d8dda124
b12cfcd9-7591-4933-8158-23a6757fabe9	5fa71c92-40be-43bb-85f0-ccad3c205c69
69f3398b-6ddd-4b93-8d84-b771773c30b0	a05d9421-847b-48c9-8162-4f55d8dda124
69f3398b-6ddd-4b93-8d84-b771773c30b0	74ffab39-fb92-415f-a2d7-2d6820f58f96
0acd0d34-4434-4d97-9167-f2048f2a82bd	5fa71c92-40be-43bb-85f0-ccad3c205c69
35e9c0db-761d-4520-ac49-c5d7842cf39b	83bf89d2-f5b8-4a08-a8a2-6ad6884ef21a
35e9c0db-761d-4520-ac49-c5d7842cf39b	5fa71c92-40be-43bb-85f0-ccad3c205c69
35e9c0db-761d-4520-ac49-c5d7842cf39b	95f08bfc-d702-400e-bce0-e74ca8adb497
e29228a1-843d-46c9-a98f-bb4871906474	a14d3085-8a5c-48ee-92e8-cd580420cbdd
e29228a1-843d-46c9-a98f-bb4871906474	ea407112-bcd4-4a48-be29-c46df2f90562
e29228a1-843d-46c9-a98f-bb4871906474	5fa71c92-40be-43bb-85f0-ccad3c205c69
c001f1f7-2c35-4292-be02-f6ac238d0b5a	3d5ef800-fe2e-4a67-835b-7f454dbb8c5b
43fe70dd-856a-4ee8-a1da-83950adbfed1	5fa71c92-40be-43bb-85f0-ccad3c205c69
43fe70dd-856a-4ee8-a1da-83950adbfed1	a05d9421-847b-48c9-8162-4f55d8dda124
4e9dec12-a0de-4517-87a8-e272539aa6f4	a14d3085-8a5c-48ee-92e8-cd580420cbdd
4e9dec12-a0de-4517-87a8-e272539aa6f4	a05d9421-847b-48c9-8162-4f55d8dda124
00612962-5402-4b5a-b3cb-bbded7ebe8fe	74ffab39-fb92-415f-a2d7-2d6820f58f96
5cc59ebd-063c-478c-8f25-b0368b1f52d1	a14d3085-8a5c-48ee-92e8-cd580420cbdd
5cc59ebd-063c-478c-8f25-b0368b1f52d1	a05d9421-847b-48c9-8162-4f55d8dda124
255e9ff3-c368-455b-aef3-4bbae75b8e62	45d0a46e-fff7-4f58-8a71-894efab3fe9f
255e9ff3-c368-455b-aef3-4bbae75b8e62	a14d3085-8a5c-48ee-92e8-cd580420cbdd
3aaf9d8c-3494-48ed-8356-7c5fc3a28d01	45d0a46e-fff7-4f58-8a71-894efab3fe9f
3aaf9d8c-3494-48ed-8356-7c5fc3a28d01	95f08bfc-d702-400e-bce0-e74ca8adb497
77c29388-e3c5-435b-bd22-0b204f7f97a9	45d0a46e-fff7-4f58-8a71-894efab3fe9f
77c29388-e3c5-435b-bd22-0b204f7f97a9	74ffab39-fb92-415f-a2d7-2d6820f58f96
a7050b39-19bc-4b1c-8540-801da2293631	a05d9421-847b-48c9-8162-4f55d8dda124
a7050b39-19bc-4b1c-8540-801da2293631	ea407112-bcd4-4a48-be29-c46df2f90562
a2633314-0ac1-493a-b2ab-ac464d1e6ff3	3d5ef800-fe2e-4a67-835b-7f454dbb8c5b
fa183c56-a9e2-440e-b188-464f5d841035	45d0a46e-fff7-4f58-8a71-894efab3fe9f
4249e6cd-b1ff-4830-9226-0fb73486c3af	95f08bfc-d702-400e-bce0-e74ca8adb497
4249e6cd-b1ff-4830-9226-0fb73486c3af	a14d3085-8a5c-48ee-92e8-cd580420cbdd
a795ccdb-1455-4d98-a03f-2abd69c23ad7	74ffab39-fb92-415f-a2d7-2d6820f58f96
72e21103-981f-4654-b6c2-35ba50adcde6	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
72e21103-981f-4654-b6c2-35ba50adcde6	ea407112-bcd4-4a48-be29-c46df2f90562
c6b953a4-74a7-4522-a4f9-50a6f6369a7a	3d5ef800-fe2e-4a67-835b-7f454dbb8c5b
c6b953a4-74a7-4522-a4f9-50a6f6369a7a	5fa71c92-40be-43bb-85f0-ccad3c205c69
bc358cc0-31fb-4e3d-86ff-24a8c2075222	95f08bfc-d702-400e-bce0-e74ca8adb497
bc358cc0-31fb-4e3d-86ff-24a8c2075222	5fa71c92-40be-43bb-85f0-ccad3c205c69
8a3ea2db-b4a9-4ce7-93e5-3052b50258d9	74ffab39-fb92-415f-a2d7-2d6820f58f96
8a3ea2db-b4a9-4ce7-93e5-3052b50258d9	ea407112-bcd4-4a48-be29-c46df2f90562
8a3ea2db-b4a9-4ce7-93e5-3052b50258d9	5fa71c92-40be-43bb-85f0-ccad3c205c69
7a6bf789-3643-4cae-89ad-89f89c9e85ce	45d0a46e-fff7-4f58-8a71-894efab3fe9f
7a6bf789-3643-4cae-89ad-89f89c9e85ce	a14d3085-8a5c-48ee-92e8-cd580420cbdd
7a6bf789-3643-4cae-89ad-89f89c9e85ce	83bf89d2-f5b8-4a08-a8a2-6ad6884ef21a
866a7d12-67ad-4027-ba28-9c56838f720e	a14d3085-8a5c-48ee-92e8-cd580420cbdd
866a7d12-67ad-4027-ba28-9c56838f720e	45d0a46e-fff7-4f58-8a71-894efab3fe9f
866a7d12-67ad-4027-ba28-9c56838f720e	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
7f12d7f6-6eee-4de6-a884-9867e0f28a21	5acea570-1c20-4d7a-84ad-c46cb02f1a2a
7f12d7f6-6eee-4de6-a884-9867e0f28a21	95f08bfc-d702-400e-bce0-e74ca8adb497
422d7eb1-2ff0-4616-85fa-01e9d8f94b6d	95f08bfc-d702-400e-bce0-e74ca8adb497
422d7eb1-2ff0-4616-85fa-01e9d8f94b6d	a14d3085-8a5c-48ee-92e8-cd580420cbdd
422d7eb1-2ff0-4616-85fa-01e9d8f94b6d	3d5ef800-fe2e-4a67-835b-7f454dbb8c5b
\.


--
-- Data for Name: member_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_profiles (id, tenant_id, user_id, member_number, tier, status, joined_at, expires_at, renewal_date, auto_renew, phone, organization, job_title, bio, avatar_url, address, social_links, tags, interests, email_opt_in, sms_opt_in, engagement_score, churn_risk, lifetime_value, custom_fields, created_at, updated_at) FROM stdin;
00612962-5402-4b5a-b3cb-bbded7ebe8fe	demo-association	04d3cb9b-c2e7-4e0b-80d3-06f1b0d88c34	MEM-A5D80450	PREMIUM	LAPSED	2024-10-26 14:12:06.978355+00	\N	\N	f	+15558309555	Global Industries	\N	Passionate about technology	\N	\N	\N	[]	["policy", "mentorship"]	t	f	0.3475	1	4134.89	{}	2026-07-22 14:12:06.98083+00	2026-07-28 07:19:00.215313+00
43fe70dd-856a-4ee8-a1da-83950adbfed1	demo-association	36dcfd7d-3d69-41a9-adb9-1f58dbe4bab6	MEM-B1ED063E	BASIC	LAPSED	2022-12-27 14:12:06.97097+00	\N	\N	f	+15552208607	Nexus Group	Marketing Director	Passionate about leadership	\N	\N	\N	[]	["policy", "events"]	f	f	0.1525	1	4891.1	{}	2026-07-22 14:12:06.973403+00	2026-07-28 07:19:00.28602+00
a292507b-3092-455c-817e-a5ddfc22c22e	demo-association	657834d2-176f-45f2-b1e0-1cbc6c21e971	MEM-8A51700E	FREE	LAPSED	2022-01-12 14:12:06.925542+00	\N	\N	t	+15556422041	\N	Program Manager	Passionate about innovation	\N	\N	\N	[]	["technology", "mentorship", "fundraising"]	f	f	0.2275	0.9999	1023.56	{}	2026-07-22 14:12:06.928482+00	2026-07-28 07:19:00.361982+00
866a7d12-67ad-4027-ba28-9c56838f720e	demo-association	b26e414a-7059-456a-8a8c-dc96aa4031f7	MEM-D1AD1C63	FREE	LAPSED	2023-07-05 14:12:07.040689+00	\N	\N	f	+15551728709	\N	Communications Manager	Passionate about advocacy	\N	\N	\N	[]	["policy", "governance"]	t	f	0.3475	1	299.99	{}	2026-07-22 14:12:07.042711+00	2026-07-28 07:19:00.433572+00
bfcaed2e-42f8-4a20-956d-f0478b39658e	demo-association	f10fbaf3-ed93-4a57-87d9-3c6fe977b1c3	MEM-C7DD80A3	BASIC	LAPSED	2026-07-23 07:00:27.807304+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-23 07:00:27.807312+00	2026-07-28 07:19:00.549129+00
c6b953a4-74a7-4522-a4f9-50a6f6369a7a	demo-association	f4e540fd-2ff1-4f73-98f7-3d6ffcdf3a49	MEM-B2DE2606	FREE	LAPSED	2023-02-08 14:12:07.028424+00	\N	\N	t	+15551201070	Global Industries	\N	Passionate about advocacy	\N	\N	\N	[]	["fundraising", "technology"]	t	f	0.3775	0.9999	2922.12	{}	2026-07-22 14:12:07.030511+00	2026-07-28 07:19:00.559276+00
22b8898e-c89c-45eb-8345-9c490e4d45ea	demo-association	0a69f6b1-de49-43ba-b82c-c8d04c544a36	MEM-426AC48F	BASIC	LAPSED	2026-07-23 07:22:52.115691+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-23 07:22:52.115698+00	2026-07-28 07:19:00.57092+00
835344b0-18f3-4167-a49c-3a5f0e5d9981	demo-association	49cad601-b361-4965-99e3-a53156ccc6a0	MEM-5E77DCD6	BASIC	LAPSED	2026-07-23 07:12:21.079805+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-23 07:12:21.079813+00	2026-07-28 07:19:00.583001+00
86fdde45-ce9d-4f4a-95b0-f3c3c6bfb001	demo-association	2daa1c96-6133-4516-9c87-2d0c1f8fe2ee	\N	BASIC	LAPSED	2026-07-24 06:55:01.393577+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 06:55:01.398217+00	2026-07-28 07:19:00.595117+00
e25f037a-3872-4516-b672-b0471c4580e4	demo-association	3dc8afe4-cc58-4bc4-8694-b6cae6fe4349	MEM-343EEA56	BASIC	LAPSED	2026-07-23 18:04:50.40271+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-23 18:04:50.402717+00	2026-07-28 07:19:00.606936+00
d2422914-ff0a-4d86-8183-4a14263c824d	demo-association	72c4932a-4187-4f1e-8d45-d813af6e0837	\N	BASIC	LAPSED	2026-07-24 06:20:06.229396+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 06:20:06.235418+00	2026-07-28 07:19:00.621151+00
f123b1d7-220b-44fb-a8de-9932e33fa47d	demo-association	8ead9684-d170-469a-85b6-edd147c4a686	\N	BASIC	LAPSED	2026-07-24 06:22:31.914462+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 06:22:31.915906+00	2026-07-28 07:19:00.635068+00
d25c9bc8-5cb8-47f9-91ae-55d6dd9c7c1b	demo-association	a86b4b08-b23c-4d3d-b4ce-f5041e651c58	\N	BASIC	LAPSED	2026-07-24 08:09:57.888032+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 08:09:57.891529+00	2026-07-28 07:19:00.645962+00
69f3398b-6ddd-4b93-8d84-b771773c30b0	demo-association	f948d4f9-1d71-471b-b82a-bfed60c3fbf5	MEM-28ECDB6C	LIFETIME	LAPSED	2022-02-20 14:12:06.942781+00	\N	\N	t	+15553292394	Innovate Labs	Policy Analyst	Passionate about technology	\N	\N	\N	[]	["technology", "mentorship", "events"]	f	f	0.2575	1	3383.55	{}	2026-07-22 14:12:06.945555+00	2026-07-28 07:19:00.656846+00
8ce0d21d-1b3b-483c-8f66-eccda38568ee	demo-association	79befe4c-d588-4c8c-a572-3e11ad023df9	MEM-CDBC5F0E	PREMIUM	LAPSED	2022-10-13 14:12:06.858722+00	\N	\N	f	+15552748033	Vanguard Partners	Membership Coordinator	Passionate about advocacy	\N	\N	\N	[]	["mentorship", "policy"]	t	f	0.34	1	4838.11	{}	2026-07-22 14:12:06.862683+00	2026-07-28 07:13:22.484688+00
8a3ea2db-b4a9-4ce7-93e5-3052b50258d9	demo-association	f45fe9ba-7126-4763-a703-257d3631e785	MEM-34E8D9AB	CORPORATE	ACTIVE	2023-02-21 14:12:07.03476+00	\N	\N	f	+15556686741	\N	Program Manager	Passionate about innovation	\N	\N	\N	[]	["governance", "policy", "technology"]	t	f	0.265	0	3022.26	{}	2026-07-22 14:12:07.036694+00	2026-07-28 07:13:22.60865+00
35e9c0db-761d-4520-ac49-c5d7842cf39b	demo-association	04a1c0c6-5d11-4b1a-b490-76bef72b590d	MEM-2EE6B2BB	BASIC	LAPSED	2024-10-30 14:12:06.951038+00	\N	\N	f	+15556046428	\N	VP of Operations	Passionate about innovation	\N	\N	\N	[]	["mentorship", "fundraising", "policy"]	t	f	0.3775	1	3773.39	{}	2026-07-22 14:12:06.953631+00	2026-07-28 07:19:00.918405+00
bc358cc0-31fb-4e3d-86ff-24a8c2075222	demo-association	eba75e9d-261f-450c-bc6a-aa90faef7e79	MEM-8E393EB2	PREMIUM	LAPSED	2022-04-11 14:12:07.031629+00	\N	\N	t	+15553128265	Pinnacle Systems	Volunteer Coordinator	Passionate about community	\N	\N	\N	[]	["policy", "fundraising", "technology"]	t	f	0.37	1	2030.4	{}	2026-07-22 14:12:07.033647+00	2026-07-28 07:13:22.612292+00
a78c08e7-9a44-4a5e-954e-b7cf7374ab90	demo-association	a52a155a-5eb0-4954-b25f-e8ea38d4a698	MEM-7C1FAB66	PREMIUM	ACTIVE	2025-12-24 14:12:06.907464+00	\N	\N	t	+15557175297	Summit Associates	Program Manager	Passionate about technology	\N	\N	\N	[]	["mentorship", "governance", "policy"]	t	f	0.37	0	1014.28	{}	2026-07-22 14:12:06.910624+00	2026-07-28 07:13:22.502082+00
25cfb547-2fb3-4548-957b-89765d7c30d6	demo-association	33d09df2-6441-457d-af99-a1bca740d92b	MEM-3EBC45FB	CORPORATE	LAPSED	2025-06-23 14:12:06.912016+00	\N	\N	f	+15555900384	Nexus Group	Membership Coordinator	Passionate about leadership	\N	\N	\N	[]	["governance", "policy", "fundraising"]	t	f	0.37	1	2850.06	{}	2026-07-22 14:12:06.915612+00	2026-07-28 07:13:22.504919+00
32f2ecf3-bf79-463c-b4d2-587c1d6abb38	demo-association	66d4ca5e-6f2f-4c9a-a53a-dcf03cbaffe8	MEM-27EC8818	LIFETIME	LAPSED	2022-04-16 14:12:06.917016+00	\N	\N	t	+15551743844	Tech Solutions Inc	VP of Operations	Passionate about innovation	\N	\N	\N	[]	["events", "policy"]	t	f	0.265	1	1267.25	{}	2026-07-22 14:12:06.919943+00	2026-07-28 07:13:22.507288+00
98d8e1bf-4488-4919-9276-37a757cac49d	demo-association	81ab7a4d-0a0c-4804-84c4-a746fc332378	MEM-A58246F1	FREE	ACTIVE	2023-07-03 14:12:06.921305+00	\N	\N	f	+15558003384	Tech Solutions Inc	Volunteer Coordinator	Passionate about community	\N	\N	\N	[]	["policy", "technology"]	f	f	0.25	0	1151.96	{}	2026-07-22 14:12:06.924024+00	2026-07-28 07:13:22.509917+00
aba2c4a6-a717-4358-a128-8c3ee346778c	demo-association	baa86bca-8c83-4742-8bb5-d429b22a1577	MEM-0C41B433	CORPORATE	SUSPENDED	2024-08-17 14:12:06.929915+00	\N	\N	f	+15559741297	Global Industries	Policy Analyst	Passionate about leadership	\N	\N	\N	[]	["events", "governance", "policy"]	t	f	0.415	1	2731.02	{}	2026-07-22 14:12:06.932689+00	2026-07-28 07:13:22.512606+00
536b9bf9-2955-4007-97d9-70b02de64bf4	demo-association	fa500bbe-2af8-483b-885a-94ec0de08cff	MEM-9386D1EA	LIFETIME	CANCELLED	2022-08-29 14:12:06.934312+00	\N	\N	t	+15556986486	Innovate Labs	Finance Director	Passionate about leadership	\N	\N	\N	[]	["mentorship", "fundraising", "governance"]	t	f	0.415	1	734.84	{}	2026-07-22 14:12:06.937103+00	2026-07-28 07:13:22.515195+00
b12cfcd9-7591-4933-8158-23a6757fabe9	demo-association	4cc69459-a224-4a8c-8aba-4fdc5f03fdac	MEM-F479D0A5	LIFETIME	LAPSED	2021-09-10 14:12:06.938625+00	\N	\N	f	+15559171596	\N	Policy Analyst	Passionate about community	\N	\N	\N	[]	["governance"]	t	f	0.34	1	549.73	{}	2026-07-22 14:12:06.94139+00	2026-07-28 07:13:22.517745+00
0acd0d34-4434-4d97-9167-f2048f2a82bd	demo-association	891637f1-d5f7-4c13-aaae-281c12a8ebb3	MEM-BAEA9A6A	FREE	ACTIVE	2022-05-18 14:12:06.947027+00	\N	\N	f	+15551053752	Vanguard Partners	Research Associate	Passionate about advocacy	\N	\N	\N	[]	["mentorship", "fundraising"]	t	f	0.34	0	2300.29	{}	2026-07-22 14:12:06.949661+00	2026-07-28 07:13:22.52043+00
200e6a0c-5764-47be-b4c8-bbcc2478e6ad	demo-association	980d6569-31e9-47e4-831b-af4a78786f20	MEM-91361E4D	FREE	ACTIVE	2026-05-15 14:12:07.014591+00	\N	\N	t	+15556673898	Acme Corp	Executive Director	Passionate about advocacy	\N	\N	\N	[]	["policy", "technology"]	t	f	0.34	0	1582.42	{}	2026-07-22 14:12:07.017273+00	2026-07-28 07:13:22.522937+00
3aaf9d8c-3494-48ed-8356-7c5fc3a28d01	demo-association	2722b0b7-cea9-4008-83bd-4b5c357259a4	MEM-B66A681F	CORPORATE	LAPSED	2023-01-20 14:12:06.989724+00	\N	\N	t	+15551425923	Tech Solutions Inc	Marketing Director	Passionate about community	\N	\N	\N	[]	["technology"]	f	f	0.25	1	4533.71	{}	2026-07-22 14:12:06.992049+00	2026-07-28 07:13:22.525527+00
f98236b9-934b-460a-904e-7664cba49732	demo-association	bb090ff1-bd1e-4092-8940-57fc2f94deab	MEM-A5379540	LIFETIME	LAPSED	2025-02-22 14:12:06.9933+00	\N	\N	f	+15556607033	Atlas Consulting	VP of Operations	Passionate about community	\N	\N	\N	[]	["technology", "governance"]	t	f	0.34	1	725.85	{}	2026-07-22 14:12:06.995636+00	2026-07-28 07:13:22.528141+00
5cc59ebd-063c-478c-8f25-b0368b1f52d1	demo-association	5d913cce-c5cb-4393-b45a-de110506d811	MEM-0B60D737	LIFETIME	ACTIVE	2025-12-25 14:12:06.982127+00	\N	\N	t	+15555066073	\N	Event Planner	Passionate about innovation	\N	\N	\N	[]	["policy", "mentorship"]	t	f	0.265	0	2153.77	{}	2026-07-22 14:12:06.98445+00	2026-07-28 07:13:22.530735+00
4e9dec12-a0de-4517-87a8-e272539aa6f4	demo-association	e1de858a-5ead-4819-9afa-15f13c9b4cae	MEM-E672FE00	PREMIUM	ACTIVE	2023-04-25 14:12:06.974703+00	\N	\N	f	+15559589312	Innovate Labs	Program Manager	Passionate about technology	\N	\N	\N	[]	["policy", "mentorship"]	t	f	0.37	0	4211.88	{}	2026-07-22 14:12:06.977067+00	2026-07-28 07:13:22.533319+00
61f81093-c69d-4fa0-97bc-5a36f539a97a	demo-association	9a402f41-9334-45eb-b110-1f0ddc2e462b	MEM-E42C9520	PREMIUM	LAPSED	2022-09-30 14:12:06.966979+00	\N	\N	f	+15552348026	Atlas Consulting	Board President	Passionate about community	\N	\N	\N	[]	["policy", "fundraising", "mentorship"]	f	f	0.295	1	4384.64	{}	2026-07-22 14:12:06.96959+00	2026-07-28 07:13:22.53559+00
c001f1f7-2c35-4292-be02-f6ac238d0b5a	demo-association	6cf15109-5ecd-4b1f-aa9a-12adf3adcc36	MEM-B8C89F40	CORPORATE	ACTIVE	2022-09-23 14:12:06.962954+00	\N	\N	t	+15553786251	Nexus Group	Finance Director	Passionate about technology	\N	\N	\N	[]	["policy"]	t	f	0.37	0	2746.32	{}	2026-07-22 14:12:06.965509+00	2026-07-28 07:13:22.537923+00
80dd1285-5e60-4737-8ab3-810863bb191e	demo-association	e70e3cf9-b819-480f-952b-5113a3821e48	MEM-3C524EE8	CORPORATE	SUSPENDED	2025-06-18 14:12:06.959072+00	\N	\N	f	+15551857436	Atlas Consulting	Membership Coordinator	Passionate about leadership	\N	\N	\N	[]	["governance", "mentorship"]	f	f	0.22	0.9998	4689.02	{}	2026-07-22 14:12:06.961604+00	2026-07-28 07:13:22.540271+00
e29228a1-843d-46c9-a98f-bb4871906474	demo-association	581c9554-8d8b-4d90-ac3b-74bbf7ed052b	MEM-1E61B6CD	FREE	LAPSED	2023-04-28 14:12:06.955113+00	\N	\N	t	+15555867911	Horizon Technologies	Executive Director	Passionate about advocacy	\N	\N	\N	[]	["events", "fundraising"]	t	f	0.34	1	175.96	{}	2026-07-22 14:12:06.957714+00	2026-07-28 07:13:22.542551+00
ef9755e2-de75-4677-b74c-df130ec5d7a0	demo-association	6557e96a-2274-4b64-9f89-dccd750107e4	MEM-3374B1A4	CORPORATE	ACTIVE	2024-07-16 14:12:06.847107+00	\N	\N	f	+15554952556	Summit Associates	\N	Passionate about leadership	\N	\N	\N	[]	["technology", "events", "governance"]	t	f	0.37	0	3841.63	{}	2026-07-22 14:12:06.85123+00	2026-07-28 07:13:22.547154+00
e2a49808-a2bc-43cb-a0ba-535c90b244e2	demo-association	036bbde1-e694-45aa-8d32-89a5afdd553a	MEM-5B0B8883	BASIC	ACTIVE	2026-07-23 10:54:06.806878+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 10:54:06.8069+00	2026-07-28 07:13:22.561067+00
422d7eb1-2ff0-4616-85fa-01e9d8f94b6d	demo-association	2f7aafb5-9299-4367-96b7-daabfa4f742e	MEM-7DE35941	LIFETIME	ACTIVE	2024-07-17 14:12:07.047912+00	\N	\N	t	+15556794788	\N	Finance Director	Passionate about advocacy	\N	\N	\N	[]	["events", "technology", "fundraising"]	t	f	0.37	0	3459.98	{}	2026-07-22 14:12:07.049538+00	2026-07-28 07:13:22.56549+00
7a6bf789-3643-4cae-89ad-89f89c9e85ce	demo-association	aee4f441-03a3-44b1-b6d1-f7c74ff3e304	MEM-CF3DE11B	BASIC	ACTIVE	2026-06-02 14:12:07.037724+00	\N	\N	f	+15553043918	Atlas Consulting	Policy Analyst	Passionate about community	\N	\N	\N	[]	["governance", "fundraising", "events"]	t	f	0.415	0	741.47	{}	2026-07-22 14:12:07.039659+00	2026-07-28 07:13:22.604722+00
72e21103-981f-4654-b6c2-35ba50adcde6	demo-association	6fa37fd2-ad11-4d2a-ab31-a3728bf82d8d	MEM-83B89A1D	PREMIUM	LAPSED	2022-12-19 14:12:07.02511+00	\N	\N	t	+15555629222	\N	Research Associate	Passionate about advocacy	\N	\N	\N	[]	["policy", "fundraising", "technology"]	f	f	0.22	1	4874.28	{}	2026-07-22 14:12:07.027268+00	2026-07-28 07:13:22.615772+00
a795ccdb-1455-4d98-a03f-2abd69c23ad7	demo-association	cc5c9bbf-47e5-4454-9994-66b51de4b5b0	MEM-A094E4BC	BASIC	ACTIVE	2022-10-21 14:12:07.021884+00	\N	\N	f	+15555605420	Pinnacle Systems	Volunteer Coordinator	Passionate about community	\N	\N	\N	[]	["mentorship", "fundraising"]	t	f	0.34	0	4323.86	{}	2026-07-22 14:12:07.023975+00	2026-07-28 07:13:22.619443+00
4249e6cd-b1ff-4830-9226-0fb73486c3af	demo-association	8bfa4087-cc9b-4554-9b77-872015142851	MEM-4D53D1F5	PREMIUM	ACTIVE	2023-09-26 14:12:07.018476+00	\N	\N	t	+15555812015	Summit Associates	Volunteer Coordinator	Passionate about innovation	\N	\N	\N	[]	["mentorship"]	t	f	0.265	0	1660.55	{}	2026-07-22 14:12:07.020614+00	2026-07-28 07:13:22.623007+00
fa183c56-a9e2-440e-b188-464f5d841035	demo-association	887cd793-b112-4dd2-a767-0b484c944568	MEM-550F61BB	LIFETIME	ACTIVE	2023-07-19 14:12:07.011137+00	\N	\N	t	+15557464508	Acme Corp	Volunteer Coordinator	Passionate about technology	\N	\N	\N	[]	["fundraising"]	t	f	0.415	0	1564.89	{}	2026-07-22 14:12:07.013368+00	2026-07-28 07:13:22.626615+00
d64a876e-bc3e-43fd-ad30-d67eba63810b	demo-association	96313534-5f27-4dd8-8652-c719b7d7ac57	MEM-EA3C96E6	BASIC	ACTIVE	2026-07-23 18:02:17.682289+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 18:02:17.682298+00	2026-07-28 07:13:22.673487+00
ac3f9cef-9072-49db-bac7-26b10375780a	demo-association	8255181c-f093-4941-accb-0acf353069f5	\N	BASIC	ACTIVE	2026-07-24 06:21:13.189008+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:21:13.1906+00	2026-07-28 07:13:22.677352+00
04414b2a-7731-44aa-9346-bebc1cb5bce6	demo-association	596c32fe-36f0-4371-97a2-d22d5f7d83ec	MEM-F34EB5D1	PREMIUM	LAPSED	2022-02-08 14:12:06.870016+00	\N	\N	f	+15554599540	Vanguard Partners	Volunteer Coordinator	Passionate about technology	\N	\N	\N	[]	["policy"]	t	f	0.3475	1	2989.66	{}	2026-07-22 14:12:06.873646+00	2026-07-28 07:19:01.110026+00
20104e30-4bff-4291-9bc2-a49026323b5d	demo-association	2a4c6c00-9dd3-48b6-a7fe-a68f2b1c08e7	MEM-ADD19D85	BASIC	LAPSED	2026-07-23 10:55:45.490555+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-23 10:55:45.490565+00	2026-07-28 07:19:01.168069+00
f9edb753-e116-4115-a2ef-786753b967ec	default	55510ed3-93bd-4bd2-9237-bd7232331da7	\N	BASIC	ACTIVE	2026-07-24 04:24:28.095376+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:24:28.099643+00	2026-07-24 04:24:28.099648+00
d3424d04-6ecb-4848-a48b-b14d0b9f4287	default	beceb1e6-8637-408b-9dc7-902a2c0a92c0	\N	BASIC	ACTIVE	2026-07-24 04:24:43.495472+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:24:43.496074+00	2026-07-24 04:24:43.496077+00
3707761d-3c79-4637-91e2-23b252adaadf	default	1780a786-78be-4fdc-8fc6-2ee3b7255e92	\N	BASIC	ACTIVE	2026-07-24 04:29:44.728454+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:29:44.730183+00	2026-07-24 04:29:44.730187+00
44c77159-b6ff-4b70-9e11-8ffa1f4780d5	default	b95d329c-651e-4497-8960-0d87f97c1206	\N	BASIC	ACTIVE	2026-07-24 04:34:27.505221+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:34:27.508544+00	2026-07-24 04:34:27.508547+00
23339169-17fd-47b4-b480-b8e1f9d8b44f	default	7954a04f-edd6-480b-9033-ffc2b9c0b905	\N	BASIC	ACTIVE	2026-07-24 04:35:16.743989+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:35:16.745566+00	2026-07-24 04:35:16.74557+00
1475caf9-9fc2-452b-9e9e-2a08be604288	default	27f03b8f-3bc9-4d5f-a447-2e90f6089f95	\N	BASIC	ACTIVE	2026-07-24 04:36:20.722754+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:36:20.723949+00	2026-07-24 04:36:20.723953+00
b025b76b-b051-4067-a6d0-294d859febd9	default	3a32a809-200a-4859-9a42-ed8c46d34f47	\N	BASIC	ACTIVE	2026-07-24 04:40:07.042056+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:40:07.043495+00	2026-07-24 04:40:07.043499+00
1d6e5cf7-e431-4509-922e-c953c9db02e1	default	b3f4a36f-f121-42aa-90c8-760cd29d6a56	\N	BASIC	ACTIVE	2026-07-24 04:41:24.198283+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:41:24.20024+00	2026-07-24 04:41:24.200244+00
7356ea7c-b852-4f43-bd14-7ccadbc328b7	default	a7a61fcc-77e7-4592-a426-2376edb9b4f3	\N	BASIC	ACTIVE	2026-07-24 04:49:19.445932+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:49:19.447085+00	2026-07-24 04:49:19.447088+00
239214f5-07f7-43ce-a6b2-b8ae1c79f1da	default	d98bf893-3b0c-4dd7-87b9-d4cfef5b39be	\N	BASIC	ACTIVE	2026-07-24 04:57:22.701237+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 04:57:22.703293+00	2026-07-24 04:57:22.703296+00
f208231e-4d52-4fc3-bd50-373884ae7968	default	cacf3dc7-07ab-48d5-b29c-aeb7424fb85c	\N	BASIC	ACTIVE	2026-07-24 05:01:00.936272+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 05:01:00.937856+00	2026-07-24 05:01:00.93786+00
16b55edd-5043-4c89-8cb9-e0b25a5f4cfe	demo-association	a86ab5f1-93ae-4d51-b99d-f16fa0513039	MEM-E5FD0001	LIFETIME	CANCELLED	2022-02-19 14:12:06.853214+00	\N	\N	f	+15558909077	Vanguard Partners	Program Manager	Passionate about innovation	\N	\N	\N	[]	["technology", "governance", "mentorship"]	t	f	0.37	1	1685.43	{}	2026-07-22 14:12:06.856906+00	2026-07-28 07:13:22.478736+00
a2a6608d-4782-48ed-a4e9-85b9c5376cf0	demo-association	91edd7a9-bbf0-429d-8107-3b16f01e9f45	MEM-BB69EA59	FREE	PENDING	2025-12-17 14:12:06.875516+00	\N	\N	f	+15552310284	\N	\N	Passionate about community	\N	\N	\N	[]	["mentorship"]	f	f	0.25	0.0019	2596.64	{}	2026-07-22 14:12:06.879075+00	2026-07-28 07:13:22.487449+00
84b4a18c-7d13-4c74-9d7d-5033401e971a	demo-association	9e8cc2d7-69ff-4f3b-9382-5b80b6922370	MEM-63AE4289	CORPORATE	LAPSED	2023-02-01 14:12:06.880754+00	\N	\N	f	+15556498800	\N	Research Associate	Passionate about advocacy	\N	\N	\N	[]	["fundraising", "policy"]	t	f	0.265	1	3976.71	{}	2026-07-22 14:12:06.884364+00	2026-07-28 07:13:22.490052+00
a2633314-0ac1-493a-b2ab-ac464d1e6ff3	demo-association	004f3304-d128-4e4f-9142-517a767a6e64	MEM-0ECC4842	BASIC	ACTIVE	2025-01-11 14:12:07.007634+00	\N	\N	t	+15554737033	Acme Corp	Communications Manager	Passionate about community	\N	\N	\N	[]	["mentorship", "technology"]	t	f	0.34	0	4264.42	{}	2026-07-22 14:12:07.009911+00	2026-07-28 07:13:22.630422+00
470b65f5-e218-4f63-8bba-6d29f0cb41d2	demo-association	2f9bf1f7-1263-49ff-a53d-b000e84adab6	MEM-4FC647C7	CORPORATE	ACTIVE	2023-01-16 14:12:07.004071+00	\N	\N	f	+15559656302	Pinnacle Systems	Policy Analyst	Passionate about technology	\N	\N	\N	[]	["events", "fundraising"]	f	f	0.145	0	542.14	{}	2026-07-22 14:12:07.006349+00	2026-07-28 07:13:22.634221+00
4f58899c-591c-43b7-afd6-7cfa419a7be5	demo-association	ca028c51-23b8-4ae5-b945-2ce378a92ab3	MEM-A1BF95DA	FREE	ACTIVE	2026-01-31 14:12:06.815112+00	\N	\N	t	+15555740474	\N	Volunteer Coordinator	Passionate about community	\N	\N	\N	[]	["governance", "technology", "fundraising"]	t	f	0.34	0	1043.07	{}	2026-07-22 14:12:06.820062+00	2026-07-28 07:13:22.650149+00
a2aa4253-ca0f-4d17-a739-f7f88a416971	user-id	dece0280-8349-4967-8580-7e6e5e162fd1	\N	BASIC	ACTIVE	2026-07-24 06:41:52.186625+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 06:41:52.199604+00	2026-07-24 06:41:52.199609+00
a7050b39-19bc-4b1c-8540-801da2293631	demo-association	959199ef-2edd-4aea-8110-2ce993b327b4	MEM-5C15FF23	PREMIUM	ACTIVE	2022-07-11 14:12:07.000541+00	\N	\N	t	+15551677111	\N	Executive Director	Passionate about community	\N	\N	\N	[]	["policy", "technology", "fundraising"]	f	f	0.22	0	4222.18	{}	2026-07-22 14:12:07.002767+00	2026-07-28 07:13:22.665857+00
f62c9f98-76ff-4142-87d7-fd21d0921deb	demo-association	a31875df-6ff5-4dc3-bdc4-a8f938a4e4a9	MEM-0D5349BF	BASIC	CANCELLED	2026-07-23 11:42:54.919903+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0.9999	0	{}	2026-07-23 11:42:54.919914+00	2026-07-28 07:13:22.669591+00
bb4565bc-6136-4643-a640-d07fdaaf4506	ilsasyeda24@gmail.com	38220819-c3de-43df-bcb2-84e9a092b824	\N	BASIC	ACTIVE	2026-07-24 07:22:59.010655+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 07:22:59.012345+00	2026-07-24 07:22:59.01235+00
7d80b0ab-a5a2-44ea-85ff-578829dd0806	demo-association	4e4fe691-3858-4a74-9624-a75e3fa5cc54	\N	BASIC	ACTIVE	2026-07-24 06:26:57.156778+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:26:57.162049+00	2026-07-28 07:13:22.681009+00
025c8717-0d2c-4a32-9e91-e1eebd0efeb2	demo-association	85f559c0-49f6-47eb-bc7c-b36fb7601276	\N	BASIC	ACTIVE	2026-07-24 06:28:35.217401+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:28:35.222121+00	2026-07-28 07:13:22.68496+00
a601aaa4-779e-493a-b82f-041dd593653d	mohsin-123	ff3b36d5-d2fc-4c6f-a73d-469291d7211f	\N	BASIC	ACTIVE	2026-07-24 09:27:39.692109+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-24 09:27:39.696658+00	2026-07-24 09:27:39.696662+00
69527738-c85c-4969-b863-32fe155fb88f	demo-association	564eac99-bc46-4d10-9e24-13792140a541	\N	BASIC	ACTIVE	2026-07-24 06:30:08.016099+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:30:08.01819+00	2026-07-28 07:13:22.68836+00
426e77cd-d6b3-432b-ba3a-5d1a7052b708	demo-association	06ef2e59-5818-49a5-87c6-fdfdc5747162	\N	BASIC	ACTIVE	2026-07-24 06:35:23.123955+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:35:23.128851+00	2026-07-28 07:13:22.691829+00
75f2d4b7-9a17-47b7-a1a6-39ffdbba9ace	demo-association	36de8826-d6c5-4f70-8c6f-a58fbc08db44	\N	BASIC	ACTIVE	2026-07-24 06:44:18.460959+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:44:18.463224+00	2026-07-28 07:13:22.695319+00
c06c77a6-5ee7-422a-aad8-7fd2fefe8751	demo-association	61a95f6a-d7e9-4ca4-a8aa-ae3da5e24604	\N	BASIC	ACTIVE	2026-07-24 06:54:31.981473+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-24 06:54:31.989276+00	2026-07-28 07:13:22.698825+00
eb78cee2-0b3a-496e-9e35-61b59e69f48d	Munazzah-association	ad3e0ece-dd9d-401a-91d4-44b920337714	\N	BASIC	ACTIVE	2026-07-27 11:22:35.812301+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0	0	0	{}	2026-07-27 11:22:35.823494+00	2026-07-27 11:22:35.823506+00
96041d0f-9b6b-43cb-b0da-466a380b8a17	demo-association	6db475ca-90a3-4f7f-9846-5fcc99ea1415	MEM-BEFDA0E2	PREMIUM	SUSPENDED	2022-09-20 14:12:06.864493+00	\N	\N	f	+15551837708	Pinnacle Systems	Program Manager	Passionate about advocacy	\N	\N	\N	[]	["policy", "governance", "events"]	t	f	0.3475	1	4787.35	{}	2026-07-22 14:12:06.868241+00	2026-07-28 07:19:01.286248+00
1f3bbb19-e518-4e44-b424-9c83490dcf9c	demo-association	4c730d4a-b7b6-4b7d-8c3a-ba2943d4ad4e	MEM-7AE92585	FREE	ACTIVE	2026-05-22 14:12:06.886103+00	\N	\N	f	+15557757166	Pinnacle Systems	Finance Director	Passionate about advocacy	\N	\N	\N	[]	["events"]	t	f	0.34	0	1729.11	{}	2026-07-22 14:12:06.889878+00	2026-07-28 07:13:22.492598+00
d5aafbbe-6ee7-4de3-9fe7-6162f5e1ae05	demo-association	78f737e7-bbc4-495a-9b7a-b636452622cb	MEM-78696234	PREMIUM	ACTIVE	2022-08-19 14:12:06.891761+00	\N	\N	f	+15556294437	\N	Research Associate	Passionate about innovation	\N	\N	\N	[]	["technology", "policy"]	t	f	0.34	0	1788.9	{}	2026-07-22 14:12:06.895416+00	2026-07-28 07:13:22.495385+00
44918c2d-9359-48ce-b7fb-3f8e66242525	demo-association	4e83d2ac-6e7a-44f8-a795-f94da6150631	MEM-4066EC50	CORPORATE	ACTIVE	2024-08-23 14:12:06.897007+00	\N	\N	t	+15556001382	Atlas Consulting	Research Associate	Passionate about technology	\N	\N	\N	[]	["technology"]	f	f	0.22	0	4951.21	{}	2026-07-22 14:12:06.900487+00	2026-07-28 07:13:22.497725+00
28bdb4cc-21b3-4acd-8bbc-daf71f575861	demo-association	e0183dea-662d-40e4-882d-b39c325de8b6	MEM-165F4339	FREE	ACTIVE	2023-11-28 14:12:06.902239+00	\N	\N	f	+15555974796	Horizon Technologies	Finance Director	Passionate about technology	\N	\N	\N	[]	["events", "policy"]	t	f	0.34	0	1555.52	{}	2026-07-22 14:12:06.90566+00	2026-07-28 07:13:22.499925+00
2d99c9a8-acbf-4035-a488-ed460f351034	demo-association	f43fcf05-6051-4f16-bf18-444b068f3dac	MEM-6E79FD0A	BASIC	ACTIVE	2026-07-23 06:50:38.312538+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 06:50:38.31255+00	2026-07-28 07:13:22.558858+00
7f12d7f6-6eee-4de6-a884-9867e0f28a21	demo-association	f7e548ad-b447-415b-9492-57ff56f8776d	MEM-EBAD4242	BASIC	ACTIVE	2022-09-04 14:12:07.043913+00	\N	\N	t	+15555617089	Horizon Technologies	\N	Passionate about innovation	\N	\N	\N	[]	["mentorship", "governance", "fundraising"]	t	f	0.34	0	2761.93	{}	2026-07-22 14:12:07.046036+00	2026-07-28 07:13:22.569949+00
2abf0009-0b79-4866-9e7d-f36cb4451682	demo-association	c2a5381c-ca9c-4764-8865-2801950e2a63	MEM-2212DB31	BASIC	ACTIVE	2026-07-23 09:05:49.308303+00	\N	\N	f	\N	Test Org	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 09:05:49.308312+00	2026-07-28 07:13:22.574348+00
c9ad3209-ed22-4026-8972-cd0a1f2e5a0e	demo-association	3e18e45a-568f-46c7-8222-ad8cd6aa443f	MEM-9E02B8B4	BASIC	ACTIVE	2026-07-23 09:40:42.747621+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 09:40:42.747628+00	2026-07-28 07:13:22.578643+00
29ad00a7-dd6b-4115-8dd1-b7e9af20631c	demo-association	e43ff69b-9d1d-4f8f-a88f-24a909f6ca95	MEM-FB9DF5D4	BASIC	ACTIVE	2026-07-23 09:40:43.696101+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 09:40:43.696109+00	2026-07-28 07:13:22.583662+00
cef78bee-8e20-495f-9635-9890c299f0e2	demo-association	fb754c51-171b-45cc-8347-3fb74f61f868	\N	BASIC	ACTIVE	2026-07-23 08:52:19.741396+00	\N	\N	f	555-0123	Test Org	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 08:52:19.746451+00	2026-07-28 07:13:22.587947+00
ff65bee0-ef02-470a-a797-d032057feb7f	demo-association	080e1383-4385-494b-9b57-89fe55a2692f	MEM-6BFBF5BF	BASIC	ACTIVE	2026-07-23 05:32:12.635086+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 05:32:12.635094+00	2026-07-28 07:13:22.592665+00
27f4b9ed-31a0-44d9-8ecb-ea26c321432d	demo-association	a68455f6-dd62-4074-a41a-8bcaa3618345	MEM-C04F89A6	BASIC	ACTIVE	2026-07-23 10:56:41.186038+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 10:56:41.186049+00	2026-07-28 07:13:22.596626+00
150e0de9-2e0c-4858-8e01-324e666bd4fe	demo-association	b6056439-ea0c-4e6c-9b28-a87d23741f7d	MEM-26491DBC	BASIC	ACTIVE	2026-07-23 10:55:46.043125+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-23 10:55:46.043135+00	2026-07-28 07:13:22.60057+00
4e83ddf0-34ea-4d8f-8f1d-24def7e9e87c	demo-association	5a44618c-af1a-4797-85f9-7e3492418274	MEM-C12D0ACB	BASIC	LAPSED	2026-07-24 11:05:27.832963+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 11:05:27.832971+00	2026-07-28 07:19:01.506109+00
c8ada24d-1dec-4f9e-b0f7-3be95ebabf14	demo-association	74930db4-eae7-48b8-8ad1-0d26f6292bb8	MEM-EB2903AB	BASIC	LAPSED	2026-07-24 10:42:21.830582+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 10:42:21.83059+00	2026-07-28 07:19:01.52048+00
49a38903-3a10-4886-9823-bb69f43bbc88	demo-association	ae49210a-8807-4060-94c6-fb4685ffccb0	\N	BASIC	LAPSED	2026-07-24 08:08:36.441654+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-24 08:08:36.442951+00	2026-07-28 07:19:01.536043+00
77c29388-e3c5-435b-bd22-0b204f7f97a9	demo-association	ba5bba70-0b16-41a3-88ef-6ad1dbb5efb1	MEM-3FACEB20	LIFETIME	LAPSED	2023-08-01 14:12:06.996965+00	\N	\N	f	+15558682673	Acme Corp	Volunteer Coordinator	Passionate about technology	\N	\N	\N	[]	["events", "mentorship"]	t	f	0.3775	1	3626.23	{}	2026-07-22 14:12:06.999258+00	2026-07-28 07:19:01.552224+00
255e9ff3-c368-455b-aef3-4bbae75b8e62	demo-association	ca7cea75-77d6-4faa-9130-db26a23f5e35	MEM-B1101456	BASIC	LAPSED	2023-07-22 14:12:06.986197+00	\N	\N	t	+15551339429	Horizon Technologies	Finance Director	Passionate about advocacy	\N	\N	\N	[]	["policy"]	t	f	0.3775	1	3034.82	{}	2026-07-22 14:12:06.988441+00	2026-07-28 07:19:01.572096+00
ff4d3f05-1253-4284-a43f-9b50d1e760f8	demo-association	f6c175dc-b28e-477b-b686-3c4f0514029f	\N	BASIC	LAPSED	2026-07-25 06:52:10.1324+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.2725	1	0	{}	2026-07-25 06:52:10.133628+00	2026-07-28 07:19:01.593253+00
960d70a1-e732-4157-9c0d-18f248f55414	demo-association	eed8e96f-ff7b-4fc5-b6ad-e9744ed43feb	\N	BASIC	ACTIVE	2026-07-25 06:21:45.096582+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-25 06:21:45.101326+00	2026-07-28 07:13:22.702503+00
3f5dc381-5b1d-499f-9a1f-9a4be253fde5	demo-association	578d9f44-a84d-4f27-9753-28ccc685287b	\N	BASIC	ACTIVE	2026-07-27 08:05:31.544743+00	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	[]	[]	t	f	0.265	0	0	{}	2026-07-27 08:05:31.551693+00	2026-07-28 07:13:22.706069+00
\.


--
-- Data for Name: member_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_tags (id, tenant_id, name, color, created_at) FROM stdin;
5fa71c92-40be-43bb-85f0-ccad3c205c69	demo-association	Board Member	#EF4444	2026-07-22 14:12:06.40173+00
74ffab39-fb92-415f-a2d7-2d6820f58f96	demo-association	Volunteer	#22C55E	2026-07-22 14:12:06.401754+00
83bf89d2-f5b8-4a08-a8a2-6ad6884ef21a	demo-association	Donor	#3B82F6	2026-07-22 14:12:06.401768+00
95f08bfc-d702-400e-bce0-e74ca8adb497	demo-association	Event Speaker	#A855F7	2026-07-22 14:12:06.401782+00
a14d3085-8a5c-48ee-92e8-cd580420cbdd	demo-association	New Member	#F59E0B	2026-07-22 14:12:06.401795+00
45d0a46e-fff7-4f58-8a71-894efab3fe9f	demo-association	At Risk	#EF4444	2026-07-22 14:12:06.40182+00
5acea570-1c20-4d7a-84ad-c46cb02f1a2a	demo-association	VIP	#F59E0B	2026-07-22 14:12:06.401833+00
ea407112-bcd4-4a48-be29-c46df2f90562	demo-association	Committee Chair	#6366F1	2026-07-22 14:12:06.401846+00
3d5ef800-fe2e-4a67-835b-7f454dbb8c5b	demo-association	Lifetime Member	#10B981	2026-07-22 14:12:06.401859+00
a05d9421-847b-48c9-8162-4f55d8dda124	demo-association	Corporate Rep	#8B5CF6	2026-07-22 14:12:06.401872+00
\.


--
-- Data for Name: message_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_logs (id, tenant_id, channel, recipient_id, recipient_email, recipient_phone, subject, body_preview, status, campaign_id, opened_at, clicked_at, clicked_link, sent_at) FROM stdin;
\.


--
-- Data for Name: nominations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nominations (id, election_id, position_id, member_id, tenant_id, status, statement, qualifications, endorsed_by, nominated_at, responded_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, tenant_id, user_id, title, message, link, notification_type, is_read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, tenant_id, invoice_id, member_id, amount, currency, payment_method, status, stripe_charge_id, stripe_receipt_url, reference_number, notes, metadata_json, paid_at, created_at) FROM stdin;
fe5d874e-030f-4e9d-9e40-4e8126f5b3ce	demo-association	e60a7ec2-2b32-47b4-a8ad-427c862a9744	3f5dc381-5b1d-499f-9a1f-9a4be253fde5	431.92	USD	CASH	completed	\N	\N	\N	\N	{}	2026-07-27 08:40:07.253393+00	2026-07-27 08:40:07.253403+00
\.


--
-- Data for Name: recurring_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recurring_transactions (id, tenant_id, member_id, dues_structure_id, frequency, next_invoice_date, last_invoice_date, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: saved_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_reports (id, tenant_id, name, description, report_type, query_config, is_scheduled, schedule_cron, last_run_at, last_result, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: survey_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.survey_responses (id, survey_id, respondent_id, answers, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.surveys (id, tenant_id, title, description, questions, target_segments, target_all, status, is_anonymous, opens_at, closes_at, total_invited, response_count, created_by, created_at) FROM stdin;
e0fa8dad-4e0e-486c-80bf-41156c3411d5	demo-association	Member Satisfaction Survey 2025	Survey: Member Satisfaction Survey 2025	[{"q": "How satisfied?", "type": "rating"}]	\N	t	CLOSED	t	\N	\N	89	58	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.382876+00
a035522d-4fbc-4915-b07a-51ab9abaa6c6	demo-association	Event Feedback - Annual Gala	Survey: Event Feedback - Annual Gala	[{"q": "How satisfied?", "type": "rating"}]	\N	t	CLOSED	t	\N	\N	120	40	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.389388+00
58bfb5a8-003b-493e-a9dd-dbcefb8561be	demo-association	Website Usability Survey	Survey: Website Usability Survey	[{"q": "How satisfied?", "type": "rating"}]	\N	t	ACTIVE	t	\N	\N	89	37	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.392613+00
f8fdbb63-8660-40e8-be97-de52681fc516	demo-association	Strategic Plan Input Survey	Survey: Strategic Plan Input Survey	[{"q": "How satisfied?", "type": "rating"}]	\N	t	ACTIVE	t	\N	\N	89	38	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-24 07:40:11.395681+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, email, hashed_password, first_name, last_name, roles, is_active, last_login_at, created_at, updated_at, email_verified, verification_token, verification_sent_at, custom_permissions) FROM stdin;
a86ab5f1-93ae-4d51-b99d-f16fa0513039	demo-association	daniel.taylor@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Daniel	Taylor	["member"]	t	\N	2026-07-22 14:12:06.849497+00	2026-07-22 14:12:06.849504+00	t	\N	\N	\N
79befe4c-d588-4c8c-a572-3e11ad023df9	demo-association	maria.wright@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Maria	Wright	["member"]	t	\N	2026-07-22 14:12:06.855371+00	2026-07-22 14:12:06.855378+00	t	\N	\N	\N
91edd7a9-bbf0-429d-8107-3b16f01e9f45	demo-association	andrew.king@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Andrew	King	["member"]	t	\N	2026-07-22 14:12:06.872097+00	2026-07-22 14:12:06.872104+00	t	\N	\N	\N
9e8cc2d7-69ff-4f3b-9382-5b80b6922370	demo-association	heather.miller@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Heather	Miller	["member"]	t	\N	2026-07-22 14:12:06.877597+00	2026-07-22 14:12:06.877604+00	t	\N	\N	\N
4c730d4a-b7b6-4b7d-8c3a-ba2943d4ad4e	demo-association	joshua.lewis@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Joshua	Lewis	["member"]	t	\N	2026-07-22 14:12:06.882858+00	2026-07-22 14:12:06.882865+00	t	\N	\N	\N
78f737e7-bbc4-495a-9b7a-b636452622cb	demo-association	nicole.walker@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Nicole	Walker	["member"]	t	\N	2026-07-22 14:12:06.888226+00	2026-07-22 14:12:06.888233+00	t	\N	\N	\N
4e83d2ac-6e7a-44f8-a795-f94da6150631	demo-association	rachel.davis@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Rachel	Davis	["member"]	t	\N	2026-07-22 14:12:06.893915+00	2026-07-22 14:12:06.893922+00	t	\N	\N	\N
e0183dea-662d-40e4-882d-b39c325de8b6	demo-association	stephanie.harris@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Stephanie	Harris	["member"]	t	\N	2026-07-22 14:12:06.89889+00	2026-07-22 14:12:06.898896+00	t	\N	\N	\N
a52a155a-5eb0-4954-b25f-e8ea38d4a698	demo-association	timothy.taylor@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Timothy	Taylor	["member"]	t	\N	2026-07-22 14:12:06.904128+00	2026-07-22 14:12:06.904134+00	t	\N	\N	\N
33d09df2-6441-457d-af99-a1bca740d92b	demo-association	daniel.taylor@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Daniel	Taylor	["member"]	t	\N	2026-07-22 14:12:06.909358+00	2026-07-22 14:12:06.909363+00	t	\N	\N	\N
66d4ca5e-6f2f-4c9a-a53a-dcf03cbaffe8	demo-association	nicole.nelson@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Nicole	Nelson	["member"]	t	\N	2026-07-22 14:12:06.913722+00	2026-07-22 14:12:06.913728+00	t	\N	\N	\N
81ab7a4d-0a0c-4804-84c4-a746fc332378	demo-association	robert.jones@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Robert	Jones	["member"]	t	\N	2026-07-22 14:12:06.918725+00	2026-07-22 14:12:06.91873+00	t	\N	\N	\N
baa86bca-8c83-4742-8bb5-d429b22a1577	demo-association	heather.davis@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Heather	Davis	["member"]	t	\N	2026-07-22 14:12:06.927114+00	2026-07-22 14:12:06.92712+00	t	\N	\N	\N
fa500bbe-2af8-483b-885a-94ec0de08cff	demo-association	robert.rodriguez@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Robert	Rodriguez	["member"]	t	\N	2026-07-22 14:12:06.931397+00	2026-07-22 14:12:06.931402+00	t	\N	\N	\N
4cc69459-a224-4a8c-8aba-4fdc5f03fdac	demo-association	laura.walker@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Laura	Walker	["member"]	t	\N	2026-07-22 14:12:06.935795+00	2026-07-22 14:12:06.935819+00	t	\N	\N	\N
891637f1-d5f7-4c13-aaae-281c12a8ebb3	demo-association	robert.jones@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Robert	Jones	["member"]	t	\N	2026-07-22 14:12:06.9443+00	2026-07-22 14:12:06.944305+00	t	\N	\N	\N
980d6569-31e9-47e4-831b-af4a78786f20	demo-association	megan.davis@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Megan	Davis	["member"]	f	\N	2026-07-22 14:12:07.012306+00	2026-07-23 11:14:00.948829+00	t	\N	\N	\N
2722b0b7-cea9-4008-83bd-4b5c357259a4	demo-association	brian.hill@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Brian	Hill	["member"]	f	\N	2026-07-22 14:12:06.987385+00	2026-07-23 11:14:38.27796+00	t	\N	\N	\N
bb090ff1-bd1e-4092-8940-57fc2f94deab	demo-association	laura.lewis@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Laura	Lewis	["member"]	f	\N	2026-07-22 14:12:06.990961+00	2026-07-23 11:14:38.290663+00	t	\N	\N	\N
5d913cce-c5cb-4393-b45a-de110506d811	demo-association	timothy.robinson@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Timothy	Robinson	["member"]	f	\N	2026-07-22 14:12:06.979658+00	2026-07-23 11:14:38.300479+00	t	\N	\N	\N
e1de858a-5ead-4819-9afa-15f13c9b4cae	demo-association	michelle.king@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Michelle	King	["member"]	f	\N	2026-07-22 14:12:06.972305+00	2026-07-23 11:14:38.318018+00	t	\N	\N	\N
9a402f41-9334-45eb-b110-1f0ddc2e462b	demo-association	william.king@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	William	King	["member"]	f	\N	2026-07-22 14:12:06.964379+00	2026-07-23 11:14:55.888767+00	t	\N	\N	\N
6cf15109-5ecd-4b1f-aa9a-12adf3adcc36	demo-association	emily.rodriguez@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Emily	Rodriguez	["member"]	f	\N	2026-07-22 14:12:06.960473+00	2026-07-23 11:14:55.897619+00	t	\N	\N	\N
e70e3cf9-b819-480f-952b-5113a3821e48	demo-association	maria.jones@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Maria	Jones	["member"]	f	\N	2026-07-22 14:12:06.956524+00	2026-07-23 11:15:20.975212+00	t	\N	\N	\N
581c9554-8d8b-4d90-ac3b-74bbf7ed052b	demo-association	jennifer.garcia@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Jennifer	Garcia	["member"]	f	\N	2026-07-22 14:12:06.952476+00	2026-07-23 11:15:20.986932+00	t	\N	\N	\N
04d3cb9b-c2e7-4e0b-80d3-06f1b0d88c34	demo-association	robert.miller@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Robert	Miller	["member"]	f	2026-03-29 07:11:04.827068+00	2026-07-22 14:12:06.97599+00	2026-07-28 07:11:04.834976+00	t	\N	\N	\N
6557e96a-2274-4b64-9f89-dccd750107e4	demo-association	sarah.rodriguez@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Sarah	Rodriguez	["member"]	t	\N	2026-07-22 14:12:06.816273+00	2026-07-22 14:12:06.816277+00	t	\N	\N	\N
04a1c0c6-5d11-4b1a-b490-76bef72b590d	demo-association	michael.young@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Michael	Young	["member"]	f	2026-01-10 07:11:04.827117+00	2026-07-22 14:12:06.948523+00	2026-07-28 07:11:04.834968+00	t	\N	\N	\N
36dcfd7d-3d69-41a9-adb9-1f58dbe4bab6	demo-association	heather.adams@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Heather	Adams	["member"]	f	2026-03-02 07:11:04.82709+00	2026-07-22 14:12:06.968314+00	2026-07-28 07:11:04.834986+00	t	\N	\N	\N
596c32fe-36f0-4371-97a2-d22d5f7d83ec	demo-association	amanda.miller@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Amanda	Miller	["member"]	t	2026-01-02 07:11:04.826929+00	2026-07-22 14:12:06.866595+00	2026-07-28 07:11:04.834993+00	t	\N	\N	\N
657834d2-176f-45f2-b1e0-1cbc6c21e971	demo-association	angela.clark@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Angela	Clark	["member"]	t	2025-09-10 07:11:04.826997+00	2026-07-22 14:12:06.922893+00	2026-07-28 07:11:04.834998+00	t	\N	\N	\N
f43fcf05-6051-4f16-bf18-444b068f3dac	demo-association	qa@qa.com	$2b$12$2wVAdSi/E.Xxil7ibotnH.DqCAq/.wfK4QPD7dWe.NSriXkpW7bI2	QA2	QA	["member"]	f	\N	2026-07-23 06:50:38.298921+00	2026-07-23 06:50:38.431955+00	t	\N	\N	\N
036bbde1-e694-45aa-8d32-89a5afdd553a	demo-association	testcreate@example.com	$2b$12$/JtfEV5dUUmJLCXLClHoC.RP.n9RC1x26lqEUWna1uOJVNMpJoWlW	Test	Member	["member"]	f	\N	2026-07-23 10:54:06.785766+00	2026-07-23 11:14:00.868925+00	t	\N	\N	\N
2f7aafb5-9299-4367-96b7-daabfa4f742e	demo-association	nicole.miller@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Nicole	Miller	["member"]	f	\N	2026-07-22 14:12:07.044967+00	2026-07-23 11:14:00.877987+00	t	\N	\N	\N
f7e548ad-b447-415b-9492-57ff56f8776d	demo-association	amanda.baker@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Amanda	Baker	["member"]	f	\N	2026-07-22 14:12:07.041737+00	2026-07-23 11:14:00.887101+00	t	\N	\N	\N
c2a5381c-ca9c-4764-8865-2801950e2a63	demo-association	test_audit@example.com	$2b$12$uXJly3zsw8TarYl61DesdOr8/KUwO7MTf7tnI.KN20xMNiCP21XeC	Audit	Test	["member"]	f	\N	2026-07-23 09:05:49.304257+00	2026-07-23 09:37:01.259013+00	t	\N	\N	\N
3e18e45a-568f-46c7-8222-ad8cd6aa443f	demo-association	delete-test@example.com	$2b$12$4vGSN0qGGkUUXr/AHI6hU.v8PcZBsOCcTiLIiV6ecUuoPWI.XiPii	Delete	Me	["member"]	f	\N	2026-07-23 09:40:42.743063+00	2026-07-23 09:40:43.317895+00	t	\N	\N	\N
e43ff69b-9d1d-4f8f-a88f-24a909f6ca95	demo-association	create-test@example.com	$2b$12$rK5E7P/68nRkZQ/IH4yfiOFzfMxEivnhx7co8AATdi6jri3CYBDO6	Create	Test	["member"]	f	\N	2026-07-23 09:40:43.693926+00	2026-07-23 09:40:43.715033+00	t	\N	\N	\N
fb754c51-171b-45cc-8347-3fb74f61f868	demo-association	test@example.com	$2b$12$x0fuiyXRE2tupdPON5aPK.LkXwNI0hLU6Y6itWgPGiyjCC8S.I1A2	Test	User	["member"]	f	\N	2026-07-23 08:52:19.7355+00	2026-07-23 09:42:21.344082+00	t	\N	\N	\N
080e1383-4385-494b-9b57-89fe55a2692f	demo-association	test_8dd8a5@example.com	$2b$12$6gx5Z6w2ZCQDWts1z3G/Eeb/s5K0vZj38x/0P1ouQQnC.Z/BIps4.	Test	User	["member"]	f	\N	2026-07-23 05:32:12.628741+00	2026-07-23 10:43:51.557597+00	t	\N	\N	\N
a68455f6-dd62-4074-a41a-8bcaa3618345	demo-association	testfix@example.com	$2b$12$JqmMV6pbSKT3tCo7Ln1YBewedjUIEJpY3ua2I3dfvT8klyFLcR0Rq	Test		["member"]	f	\N	2026-07-23 10:56:41.177735+00	2026-07-23 11:14:00.835575+00	t	\N	\N	\N
b6056439-ea0c-4e6c-9b28-a87d23741f7d	demo-association	testfix3@example.com	$2b$12$qfSuQjjRuh9qqg7aejaRRegjPa5XoOQH0PDKV/yxukRmj0fYC.o4i	Test3	Fixer	["member"]	f	\N	2026-07-23 10:55:46.040314+00	2026-07-23 11:14:00.849911+00	t	\N	\N	\N
aee4f441-03a3-44b1-b6d1-f7c74ff3e304	demo-association	daniel.baker@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Daniel	Baker	["member"]	f	\N	2026-07-22 14:12:07.035822+00	2026-07-23 11:14:00.902954+00	t	\N	\N	\N
f45fe9ba-7126-4763-a703-257d3631e785	demo-association	william.lee@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	William	Lee	["member"]	f	\N	2026-07-22 14:12:07.032718+00	2026-07-23 11:14:00.910448+00	t	\N	\N	\N
eba75e9d-261f-450c-bc6a-aa90faef7e79	demo-association	jason.green@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Jason	Green	["member"]	f	\N	2026-07-22 14:12:07.029517+00	2026-07-23 11:14:00.917471+00	t	\N	\N	\N
6fa37fd2-ad11-4d2a-ab31-a3728bf82d8d	demo-association	timothy.williams@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Timothy	Williams	["member"]	f	\N	2026-07-22 14:12:07.022993+00	2026-07-23 11:14:00.930513+00	t	\N	\N	\N
cc5c9bbf-47e5-4454-9994-66b51de4b5b0	demo-association	michelle.rodriguez@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Michelle	Rodriguez	["member"]	f	\N	2026-07-22 14:12:07.019616+00	2026-07-23 11:14:00.936723+00	t	\N	\N	\N
8bfa4087-cc9b-4554-9b77-872015142851	demo-association	ashley.wilson@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Ashley	Wilson	["member"]	f	\N	2026-07-22 14:12:07.015724+00	2026-07-23 11:14:00.942831+00	t	\N	\N	\N
887cd793-b112-4dd2-a767-0b484c944568	demo-association	maria.scott@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Maria	Scott	["member"]	f	\N	2026-07-22 14:12:07.008781+00	2026-07-23 11:14:00.95679+00	t	\N	\N	\N
004f3304-d128-4e4f-9142-517a767a6e64	demo-association	william.adams@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	William	Adams	["member"]	f	\N	2026-07-22 14:12:07.005239+00	2026-07-23 11:14:00.965427+00	t	\N	\N	\N
2f9bf1f7-1263-49ff-a53d-b000e84adab6	demo-association	timothy.jones@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Timothy	Jones	["member"]	f	\N	2026-07-22 14:12:07.001717+00	2026-07-23 11:14:00.973633+00	t	\N	\N	\N
b26e414a-7059-456a-8a8c-dc96aa4031f7	demo-association	emily.garcia@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Emily	Garcia	["member"]	f	2026-04-21 07:11:04.827279+00	2026-07-22 14:12:07.038776+00	2026-07-28 07:11:04.835014+00	t	\N	\N	\N
f10fbaf3-ed93-4a57-87d9-3c6fe977b1c3	demo-association	qa2@qa.com	$2b$12$wiycfoNZNvmlTPGOOba58OYlmcONefVjQA7C66yBwGrtOoanzlxLS	QA3	QA2	["member"]	f	2025-08-28 07:11:04.827157+00	2026-07-23 07:00:27.802117+00	2026-07-28 07:11:04.835021+00	t	\N	\N	\N
f4e540fd-2ff1-4f73-98f7-3d6ffcdf3a49	demo-association	brian.scott@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Brian	Scott	["member"]	f	2025-09-16 07:11:04.827301+00	2026-07-22 14:12:07.026232+00	2026-07-28 07:11:04.835023+00	t	\N	\N	\N
ca028c51-23b8-4ae5-b945-2ce378a92ab3	demo-association	daniel.harris@example.com	$2b$12$8sDJ/.OVA79GB4LjITKQRudalxPBIZIecfr7PXdlKVSjfJWpNMa7C	Daniel	Harris	["super_admin"]	t	\N	2026-07-22 14:12:06.81113+00	2026-07-22 14:12:06.811137+00	t	\N	\N	\N
0a69f6b1-de49-43ba-b82c-c8d04c544a36	demo-association	final_qa@qa.com	$2b$12$kgcOsDx4zVFxsgb90gzi/up6pqF0FEvL/480ZwJnlnLOWWi9DuaeW	FQ2	FQ	["member"]	f	2025-11-30 07:11:04.827245+00	2026-07-23 07:22:52.110298+00	2026-07-28 07:11:04.834979+00	t	\N	\N	\N
2a4c6c00-9dd3-48b6-a7fe-a68f2b1c08e7	demo-association	testfix2@example.com	$2b$12$LEJOgIduxxE3RWwbqLEcX.NeexFgB9Rx..UM2P0Zp/PS5G5DsoMo2	Test2		["member"]	f	2025-10-28 07:11:04.827137+00	2026-07-23 10:55:45.482714+00	2026-07-28 07:11:04.834981+00	t	\N	\N	\N
49cad601-b361-4965-99e3-a53156ccc6a0	demo-association	qa3@qa.com	$2b$12$JAzVVwfwFtZbx.7YblGR.ORGtREbtujY5akoDe11lZNyKfYBWHmLq	QA4	QA3	["member"]	f	2025-09-04 07:11:04.827225+00	2026-07-23 07:12:21.074893+00	2026-07-28 07:11:04.834991+00	t	\N	\N	\N
959199ef-2edd-4aea-8110-2ce993b327b4	demo-association	maria.davis@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Maria	Davis	["member"]	f	\N	2026-07-22 14:12:06.998202+00	2026-07-23 11:14:00.982722+00	t	\N	\N	\N
a31875df-6ff5-4dc3-bdc4-a8f938a4e4a9	demo-association	e2e-test@example.com	$2b$12$dol221fotKbD6Rg6Uo6Av.WWSralVd7KR6P6sav7VbsiPdt7vn7LW	E2E	Test	["member"]	t	\N	2026-07-23 11:42:54.913566+00	2026-07-23 11:42:54.913573+00	t	\N	\N	\N
96313534-5f27-4dd8-8652-c719b7d7ac57	demo-association	e2e-test-member-v2@example.com	$2b$12$.1HAWPk/Y8o8EOLH1br.8uC9CHVZlPJVQIQ8eQmQWfgpdD55xESu6	E2E	Tester	["member"]	f	\N	2026-07-23 18:02:17.676553+00	2026-07-23 18:02:17.917767+00	t	\N	\N	\N
55510ed3-93bd-4bd2-9237-bd7232331da7	default	test-routefix@example.com	$2b$12$8Cvn.7tHjGbseC9Y2PE.Ne12znb9.tgWC3cgHoI2zRDzkA.YfGhDu	Test	User	["member"]	t	\N	2026-07-24 04:24:28.091865+00	2026-07-24 04:24:28.091873+00	t	\N	\N	\N
beceb1e6-8637-408b-9dc7-902a2c0a92c0	default	test-routefix2@example.com	$2b$12$cMUGm8pdW0nui.MHZhmKCeGJ3HKB9o/1iSvcWfNvseKE5HBcrhg9K	Test2	User2	["member"]	t	\N	2026-07-24 04:24:43.493398+00	2026-07-24 04:24:43.493403+00	t	\N	\N	\N
1780a786-78be-4fdc-8fc6-2ee3b7255e92	default	test-flow-42836@example.com	$2b$12$UedxTBuV6Xut8czuJntGjeENXSDOaeFV3hDs51ZN0hG5i.T0Lu1XK	Test	Flow	["member"]	t	\N	2026-07-24 04:29:44.722597+00	2026-07-24 04:29:44.722602+00	t	\N	\N	\N
b95d329c-651e-4497-8960-0d87f97c1206	default	browser-test-final@example.com	$2b$12$Kd60ujXBLAnGN4bakj10sO7ZMdLgXEu32QwAL2u5GSD5l6KcqhV0u	Browser	Test	["member"]	t	\N	2026-07-24 04:34:27.501782+00	2026-07-24 04:34:27.501789+00	t	\N	\N	\N
7954a04f-edd6-480b-9033-ffc2b9c0b905	default	debug-test@example.com	$2b$12$GyizDLtG.A8zIk47ZBUcF.6g7ZEB6wcW7gefKHswRz4bz4UlgEEs.	Debug	User	["member"]	t	\N	2026-07-24 04:35:16.741056+00	2026-07-24 04:35:16.741063+00	t	\N	\N	\N
27f03b8f-3bc9-4d5f-a447-2e90f6089f95	default	debug3-test@example.com	$2b$12$gop/T7dDcD4TY.DlQsQZS.v2mgDPxH7ydD3LpU74Bj9QbheB3kW1i	Debug3	User	["member"]	t	\N	2026-07-24 04:36:20.720179+00	2026-07-24 04:36:20.720186+00	t	\N	\N	\N
3a32a809-200a-4859-9a42-ed8c46d34f47	default	final-test-1784868006@example.com	$2b$12$m3SRf/.ubuiC0.Jk8Ho0OenNd9i9g3gGIF0EhATs2UddaN2QOsNie	Final	Test	["member"]	t	\N	2026-07-24 04:40:07.039716+00	2026-07-24 04:40:07.039723+00	t	\N	\N	\N
b3f4a36f-f121-42aa-90c8-760cd29d6a56	default	verify-1784868083@example.com	$2b$12$fqKg1s6dMkz6//9KxYOw5eRs38KSL/lu5NnsQKjJdDZE3VLeKYFEC	Verify	Test	["member"]	t	\N	2026-07-24 04:41:24.195672+00	2026-07-24 04:41:24.195679+00	t	\N	\N	\N
a7a61fcc-77e7-4592-a426-2376edb9b4f3	default	demo@assochub.com	$2b$12$582aqUWqHbylVX99qKr.huaB.wVprqOq5.elrgC7RS/VJhdbrU8Um	Demo	Admin	["member"]	t	\N	2026-07-24 04:49:19.443157+00	2026-07-24 04:49:19.443175+00	t	\N	\N	\N
d98bf893-3b0c-4dd7-87b9-d4cfef5b39be	default	final-1784869041@example.com	$2b$12$Av/FE0ISqGILXTdcHSLi9.eluLTSeujcDwu35s/pZfW7MROJo5jfC	Final	Test	["member"]	t	\N	2026-07-24 04:57:22.698193+00	2026-07-24 04:57:22.6982+00	t	\N	\N	\N
cacf3dc7-07ab-48d5-b29c-aeb7424fb85c	default	qa-1784869260@example.com	$2b$12$GpIokL4421HmuMBu8KjbAe3Og.Vn4WBia9.qJYXXS/SlF5Z08JOUq	QA	Tester	["member"]	t	\N	2026-07-24 05:01:00.931817+00	2026-07-24 05:01:00.931822+00	t	\N	\N	\N
8255181c-f093-4941-accb-0acf353069f5	demo-association	nginx-test@example.com	$2b$12$cazhJz/jDx7WGFS7h0HpJumX2kfS6gxc/HebqZnYiLIz3oZTs6msa	Nginx	Test	["member"]	t	\N	2026-07-24 06:21:13.183954+00	2026-07-24 06:21:13.183962+00	t	\N	\N	\N
4e4fe691-3858-4a74-9624-a75e3fa5cc54	demo-association	valid@test.com	$2b$12$s79iUa6GMTQ4MxY8wJNhnei6iKNeNYH9WPBiP16jsH5aihaHkpMHS	Valid	Test	["member"]	t	\N	2026-07-24 06:26:57.151232+00	2026-07-24 06:26:57.151239+00	t	\N	\N	\N
85f559c0-49f6-47eb-bc7c-b36fb7601276	demo-association	email-test@example.com	$2b$12$XUqGB9mfjsNXfHpzwuYsreAv7Z5ZFE7RGr7Qnzs9ya0uYszr6Fshq	Email	Test	["member"]	t	\N	2026-07-24 06:28:35.212837+00	2026-07-24 06:28:35.212844+00	t	\N	\N	\N
564eac99-bc46-4d10-9e24-13792140a541	demo-association	newuser-1784874607@example.com	$2b$12$ufpjVuFsXkz8OYm9qcG01OByCPwQ.oFCSN.sPuSm.EvMhXPhQ0cI.	New	User	["member"]	t	\N	2026-07-24 06:30:08.013868+00	2026-07-24 06:30:08.013876+00	t	\N	\N	\N
06ef2e59-5818-49a5-87c6-fdfdc5747162	demo-association	welcome-1784874922@gmail.com	$2b$12$N/yh1TaOAVafXN1pB0YHTO63ZofABg1bv92iW3qSWbP7io0zifHe.	Welcome	Tester	["member"]	t	\N	2026-07-24 06:35:23.120458+00	2026-07-24 06:35:23.120465+00	t	\N	\N	\N
dece0280-8349-4967-8580-7e6e5e162fd1	user-id	ladlasab061@gmail.com	$2b$12$Cnb8LUOQ/5O99oZ.ej291.bCTwqRMxEJN4GQTe63NXfa36sHgBsIK	Mohsin	Khan	["member"]	t	\N	2026-07-24 06:41:52.178955+00	2026-07-24 06:41:52.178961+00	t	\N	\N	\N
36de8826-d6c5-4f70-8c6f-a58fbc08db44	demo-association	final-test-1784875457@test.com	$2b$12$pHXA/VRxOj3riD8T07bCt.36O9sK9LMAb2aRpeNv90MBaU8UiKadm	Test	User	["member"]	t	\N	2026-07-24 06:44:18.454943+00	2026-07-24 06:44:18.454951+00	t	\N	\N	\N
61a95f6a-d7e9-4ca4-a8aa-ae3da5e24604	demo-association	testverify-1784876071@gmail.com	$2b$12$zPhySgAMYeA3ud1Q.Ynab.xPMJGBHY9ehMDjh966bxtIM09ce3H56	Test	Verifier	["member"]	t	\N	2026-07-24 06:54:31.975286+00	2026-07-24 06:54:39.916256+00	t	\N	\N	\N
38220819-c3de-43df-bcb2-84e9a092b824	ilsasyeda24@gmail.com	ilsasyeda24@gmail.com	$2b$12$hAn9Qn1VYWcj2JtFWFRJsO.Y4IWSl8oyAwZcyKfKEBX/Qpig8glvG	Ilsa	Ubiad	["member"]	t	\N	2026-07-24 07:22:59.006822+00	2026-07-24 07:23:36.748873+00	t	\N	\N	\N
a56bf1d7-a918-4796-846a-4754c30a690a	demo-association	demo@gmail.com	$2b$12$DNTLx05qGv6ubArNqwnnXegZA0TykxIClpF1Ol4/OGY/OsSwhY/We	Demo	User	["member"]	t	\N	2026-07-24 09:17:30.958859+00	2026-07-24 09:17:30.958859+00	t	\N	\N	\N
ff3b36d5-d2fc-4c6f-a73d-469291d7211f	mohsin-123	uzairlatif293@gmail.com	$2b$12$Mq8jbdeJE2agGo6sd1viI.ZApMJwgdsMEn.wyyTabFbMGwdoyP4s2	John	smith	["member"]	t	\N	2026-07-24 09:27:39.685666+00	2026-07-24 09:27:52.153447+00	t	\N	\N	\N
eed8e96f-ff7b-4fc5-b6ad-e9744ed43feb	demo-association	test-member@example.com	$2b$12$PCTDECS8hoUKw9H2naL/8eU..A4qCREqgq/lQvMGop/k2FIKZncRy	Test	Member	["member"]	f	\N	2026-07-25 06:21:45.047622+00	2026-07-25 11:16:47.779883+00	f	y6ruSYAktIoT0XXYh2i_OcOsE0EXFzyrOGSpoMM6vCRpFOKY_97maQ5mqWPixg46	2026-07-25 06:21:45.042755+00	\N
578d9f44-a84d-4f27-9753-28ccc685287b	demo-association	testuser@example.com	$2b$12$Ltoi5lismZ1CBQenA6acdu5RK6NR7kFwUu2MApzQO8ZH9Cg7lZKwy	Test	User	["member"]	t	\N	2026-07-27 08:05:31.494662+00	2026-07-27 08:05:31.494667+00	f	9B_FTwcHYcnS_1TFptf7abTxaabFBdDJqR9JC8bQ7HH0ZiWQKElxNJcbiynVUyHC	2026-07-27 08:05:31.486683+00	\N
2daa1c96-6133-4516-9c87-2d0c1f8fe2ee	demo-association	resendtest-1784876100@gmail.com	$2b$12$B.CMyFurW0l92FOGvKWJYurFabqyk0VddIx1w7wmiS.KQFPwkuaXS	Resend	Test	["member"]	t	2026-01-25 07:11:04.827441+00	2026-07-24 06:55:01.38946+00	2026-07-28 07:11:04.834984+00	f	O2y7lAAAclAnH--XUz-nDTrJBaNQLfFKsfWe7DG1Ror-z9vQpy4vBhja8g4yKBvg	2026-07-24 06:55:04.903096+00	\N
ad3e0ece-dd9d-401a-91d4-44b920337714	Munazzah-association	munazzah184@gmail.com	$2b$12$h9CpYDmQJ.uPzC/k7b4SvejjldODkRS771PFJiy2LD0ArnjhaUGRy	Munazzah	Khan	["member"]	t	\N	2026-07-27 11:22:35.767042+00	2026-07-27 11:23:19.429342+00	t	\N	\N	\N
3dc8afe4-cc58-4bc4-8694-b6cae6fe4349	demo-association	e2e1784829888@test.com	$2b$12$/ClJ0AI.StwALnJChYgmUOqXyTpMCzH4pxNckiNOD4unH2hT1msQS	Updated		["member"]	f	2025-10-10 07:11:04.827377+00	2026-07-23 18:04:50.397933+00	2026-07-28 07:11:04.834988+00	t	\N	\N	\N
5a44618c-af1a-4797-85f9-7e3492418274	demo-association	webhook-test-1784891127@example.com	$2b$12$SGWPB4qEP5LyucW2Tqe7/umUleJxiDKBg.Y2BM8aPw1OwRBB2ZGqO	Test	Webhook	["member"]	f	2026-04-02 07:11:04.827498+00	2026-07-24 11:05:27.824273+00	2026-07-28 07:11:04.834995+00	t	\N	\N	\N
6db475ca-90a3-4f7f-9846-5fcc99ea1415	demo-association	william.jones@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	William	Jones	["member"]	t	2025-09-10 07:11:04.827549+00	2026-07-22 14:12:06.861066+00	2026-07-28 07:11:04.835+00	t	\N	\N	\N
72c4932a-4187-4f1e-8d45-d813af6e0837	demo-association	test-new-user@example.com	$2b$12$9Jg2vjmVwbdTe8dA8XUz7efYnGXb1is/i.lHGCS9mGgCLFofj9xNm	Test	User	["member"]	t	2026-01-30 07:11:04.8274+00	2026-07-24 06:20:06.225222+00	2026-07-28 07:11:04.835002+00	t	\N	\N	\N
74930db4-eae7-48b8-8ad1-0d26f6292bb8	demo-association	webhook-test-1784889740@example.com	$2b$12$.ikfSweTn87UgS8Dx3DHM.ZqSccOfmhSj6B2Ose33t4686Dd0wpE2	Webhook	Test	["member"]	t	2025-10-17 07:11:04.827479+00	2026-07-24 10:42:21.82286+00	2026-07-28 07:11:04.835005+00	t	\N	\N	\N
8ead9684-d170-469a-85b6-edd147c4a686	demo-association	welcome-test@example.com	$2b$12$5.G2DmQiyp8FIj7qBMNnKe/rvKHFXn6eUCU1bWWGBv5bm1qW9FPja	Welcome	Test	["member"]	t	2025-09-26 07:11:04.82742+00	2026-07-24 06:22:31.911538+00	2026-07-28 07:11:04.835007+00	t	\N	\N	\N
a86b4b08-b23c-4d3d-b4ce-f5041e651c58	demo-association	ahmed.test@gmail.com	$2b$12$sTpexqh0Umn.UAOFMDTBDuCIK53bShLi6MzVzfkxYW0W5a9k6D8vq	Ahmed	Test	["member"]	t	2025-10-28 07:11:04.827353+00	2026-07-24 08:09:57.884341+00	2026-07-28 07:11:04.835009+00	t	\N	\N	\N
ae49210a-8807-4060-94c6-fb4685ffccb0	demo-association	test.user@gmail.com	$2b$12$6bs4X00OTqDyZIqcg33Py.jAq0Mbftb83i0JoVS7w/rHFPClR.lxa	Test	User	["member"]	t	2025-08-31 07:11:04.82746+00	2026-07-24 08:08:36.439214+00	2026-07-28 07:11:04.835011+00	f	lPfV1E4WmQGLvOq1U1I_KoTE2GDKBhuwMuCDVRSoltzYgdie6dkQXjNc-nLIcAy_	2026-07-24 08:08:36.435713+00	\N
ba5bba70-0b16-41a3-88ef-6ad1dbb5efb1	demo-association	angela.clark@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Angela	Clark	["member"]	f	2026-03-25 07:11:04.827331+00	2026-07-22 14:12:06.99455+00	2026-07-28 07:11:04.835016+00	t	\N	\N	\N
ca7cea75-77d6-4faa-9130-db26a23f5e35	demo-association	sarah.lee@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Sarah	Lee	["member"]	f	2026-04-02 07:11:04.827046+00	2026-07-22 14:12:06.98337+00	2026-07-28 07:11:04.835018+00	t	\N	\N	\N
f6c175dc-b28e-477b-b686-3c4f0514029f	demo-association	rbac-test-1784962329@example.com	$2b$12$62Ojo.P.WA5aqlHnvcvZFOX/.jfOZdCpr3/GEivplR0mRK2VzuACu	RBAC	Tester	["member"]	f	2025-09-28 07:11:04.827516+00	2026-07-25 06:52:10.1106+00	2026-07-28 07:11:04.835025+00	f	FRhongj50xQNfAJVXfArpQOnQkc5xHSPR9TdfwOMFeQ0jNmTzxGeOBE-r-6iX87T	2026-07-25 06:52:10.106582+00	\N
f948d4f9-1d71-471b-b82a-bfed60c3fbf5	demo-association	ashley.green@example.com	$2b$12$O8vK03BFVzWSLYRAhCzcI.AaJEyDf.n7pcPsi.zuAlzgaEJiHw7Sa	Ashley	Green	["member"]	t	2026-03-01 07:11:04.827026+00	2026-07-22 14:12:06.94011+00	2026-07-28 07:11:04.835027+00	t	\N	\N	\N
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_logs (id, webhook_id, tenant_id, event_type, payload, response_status, response_body, success, attempts, created_at) FROM stdin;
86484761-ba01-42df-8f00-ef461143f8d9	c317e421-a077-46eb-9a94-6605078d5cb8	demo-association	member.created	{"name": "Manual Emit Test", "email": "manual@test.com"}	200	{"ok":true}	t	1	2026-07-24 11:05:31.427812+00
0e445d31-bc89-4710-a6c5-ec8c25fa988b	c317e421-a077-46eb-9a94-6605078d5cb8	demo-association	member.created	{"name": "John Doe", "email": "john@test.com"}	200	{"ok": true}	t	1	2026-07-24 10:41:11.924842+00
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, tenant_id, name, url, events, secret, is_active, retry_count, created_at, updated_at) FROM stdin;
c317e421-a077-46eb-9a94-6605078d5cb8	demo-association	Test Receiver	http://localhost:9998/hook	["member.created"]	test-secret-123	t	3	2026-07-24 10:41:11.153485+00	2026-07-24 10:41:11.153489+00
\.


--
-- Data for Name: workflow_action_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_action_templates (id, tenant_id, name, action_type, config, description, created_at) FROM stdin;
\.


--
-- Data for Name: workflow_delays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_delays (id, workflow_id, run_id, tenant_id, step_index, resume_at, is_resumed, created_at) FROM stdin;
\.


--
-- Data for Name: workflow_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_runs (id, workflow_id, tenant_id, status, current_step, total_steps, trigger_data, context, step_results, error_message, error_step, started_at, completed_at, created_at) FROM stdin;
974e5eea-220a-4d28-ad64-7389c5b77e2e	eb7c3637-25db-47b3-8787-ebbaac25a2ac	demo-association	SUCCESS	0	0	{}	{}	[]	\N	\N	\N	2026-07-23 09:22:25.576275+00	2026-07-23 09:22:25.536535+00
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflows (id, tenant_id, name, description, status, trigger_type, trigger_config, steps, total_runs, successful_runs, failed_runs, last_run_at, created_by, created_at, updated_at) FROM stdin;
7a128ad3-b82d-44f1-a307-bbb5fc6f7b74	demo-association	Test WF	Test	DRAFT	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:11:25.696231+00	2026-07-23 02:11:25.696234+00
a9a3a707-1e10-4f82-af24-101c62f7a559	demo-association	Welcome New Members 2	Test WF	DRAFT	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:23:20.764956+00	2026-07-23 02:23:20.764959+00
bf928b4b-9f67-40b6-8313-83980f90038b	demo-association	Welcome New Members 3	Test	DRAFT	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 02:35:25.733252+00	2026-07-23 02:35:25.733256+00
601a9fb1-50ed-4333-98b0-ec2efcec41da	demo-association	Test 9d2b	Test	DRAFT	MANUAL	{}	[{"type": "send_email", "subject": "Test", "body": "Test", "to": "{{email}}"}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:34:31.782654+00	2026-07-23 05:34:31.782664+00
979c2918-7f1c-4fbe-b027-efed41702c1a	demo-association	QA Test Workflow	Test	ARCHIVED	MANUAL	{}	[{"type": "send_notification", "config": {"template": "welcome"}}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:48:28.851299+00	2026-07-23 06:48:28.914413+00
f9f6d103-f8a7-4ef1-87bd-f91d13b3fcf8	demo-association	QA WF	\N	ARCHIVED	MANUAL	{}	[{"type": "send_notification", "config": {"template": "welcome"}}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 06:50:40.781365+00	2026-07-23 06:50:40.990146+00
2f16f472-464f-4a34-8650-9a98a211ed18	demo-association	QA WF	\N	ARCHIVED	MANUAL	{}	[{"type": "send_notification", "config": {"template": "welcome"}}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:00:29.764836+00	2026-07-23 07:00:29.835465+00
16701cb1-9cf0-4c4a-8729-8e3036b69dc6	demo-association	QA Test Workflow	Test	ARCHIVED	MANUAL	{}	[{"type": "send_notification", "config": {"template": "welcome"}}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:09:18.019931+00	2026-07-23 07:09:18.137434+00
59f1badf-a827-4daa-846f-0395c7441811	demo-association	QA2	\N	ARCHIVED	MANUAL	{}	[{"type": "send_notification", "config": {"template": "welcome"}}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:12:23.03459+00	2026-07-23 07:12:23.086914+00
597d9459-5e22-4f51-814d-ab228783d6e4	demo-association	QA	\N	ARCHIVED	MANUAL	{}	[{"type": "send_notification", "config": {"template": "welcome"}}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 07:22:54.454132+00	2026-07-23 07:22:54.505658+00
c4aa73fe-2bbc-48ec-86f6-2427d84ef845	demo-association	Audit Workflow	Test	ACTIVE	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:06:02.989449+00	2026-07-23 09:06:03.167103+00
57426b67-8608-433b-a8d5-9c3ef84633e9	demo-association	Audit Workflow	Test	ACTIVE	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:16:06.121636+00	2026-07-23 09:16:06.256774+00
eb7c3637-25db-47b3-8787-ebbaac25a2ac	demo-association	Audit Workflow	Test	ACTIVE	MANUAL	{}	[]	1	1	0	2026-07-23 09:22:25.529283+00	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 09:21:32.182598+00	2026-07-23 09:22:25.577742+00
7d8d55d0-1dfd-4497-a0bb-4348457ad5ce	demo-association	Test c5e2	Test	ARCHIVED	MANUAL	{}	[{"type": "send_email", "subject": "Test", "body": "Test", "to": "{{email}}"}]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 05:36:32.140598+00	2026-07-23 11:08:36.466675+00
1cbdc055-23be-4bf4-9485-ef4b7b6afef6	demo-association	E2E Test Workflow	Test	ARCHIVED	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:02:22.907707+00	2026-07-23 18:02:23.175962+00
738fedf3-adcc-46b8-97f5-66b05c40aba0	demo-association	E2E Test Workflow	Test	ARCHIVED	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:03:57.923816+00	2026-07-23 18:03:58.345083+00
6633bcdc-e85e-4070-a987-8f497cb068f3	demo-association	WF 1784829888	\N	ARCHIVED	MANUAL	{}	[]	0	0	0	\N	ca028c51-23b8-4ae5-b945-2ce378a92ab3	2026-07-23 18:04:54.785513+00	2026-07-23 18:04:55.019531+00
\.


--
-- Name: ai_conversations ai_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_pkey PRIMARY KEY (id);


--
-- Name: ai_embeddings ai_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_embeddings
    ADD CONSTRAINT ai_embeddings_pkey PRIMARY KEY (id);


--
-- Name: ai_insights ai_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_insights
    ADD CONSTRAINT ai_insights_pkey PRIMARY KEY (id);


--
-- Name: ai_models ai_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_models
    ADD CONSTRAINT ai_models_pkey PRIMARY KEY (id);


--
-- Name: ai_predictions ai_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_predictions
    ADD CONSTRAINT ai_predictions_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: ballots ballots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ballots
    ADD CONSTRAINT ballots_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: dashboard_widgets dashboard_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_pkey PRIMARY KEY (id);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: data_exports data_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_pkey PRIMARY KEY (id);


--
-- Name: discount_codes discount_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_pkey PRIMARY KEY (id);


--
-- Name: document_activities document_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_activities
    ADD CONSTRAINT document_activities_pkey PRIMARY KEY (id);


--
-- Name: document_categories document_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_pkey PRIMARY KEY (id);


--
-- Name: document_comments document_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_comments
    ADD CONSTRAINT document_comments_pkey PRIMARY KEY (id);


--
-- Name: document_shares document_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_pkey PRIMARY KEY (id);


--
-- Name: document_versions document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: drip_campaigns drip_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_campaigns
    ADD CONSTRAINT drip_campaigns_pkey PRIMARY KEY (id);


--
-- Name: drip_enrollments drip_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_enrollments
    ADD CONSTRAINT drip_enrollments_pkey PRIMARY KEY (id);


--
-- Name: drip_logs drip_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_logs
    ADD CONSTRAINT drip_logs_pkey PRIMARY KEY (id);


--
-- Name: drip_steps drip_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_steps
    ADD CONSTRAINT drip_steps_pkey PRIMARY KEY (id);


--
-- Name: dues_structures dues_structures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dues_structures
    ADD CONSTRAINT dues_structures_pkey PRIMARY KEY (id);


--
-- Name: election_positions election_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.election_positions
    ADD CONSTRAINT election_positions_pkey PRIMARY KEY (id);


--
-- Name: election_results election_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.election_results
    ADD CONSTRAINT election_results_pkey PRIMARY KEY (id);


--
-- Name: elections elections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elections
    ADD CONSTRAINT elections_pkey PRIMARY KEY (id);


--
-- Name: email_campaigns email_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_pkey PRIMARY KEY (id);


--
-- Name: email_sending_logs email_sending_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sending_logs
    ADD CONSTRAINT email_sending_logs_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: email_tracking_events email_tracking_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_tracking_events
    ADD CONSTRAINT email_tracking_events_pkey PRIMARY KEY (id);


--
-- Name: event_feedback event_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_feedback
    ADD CONSTRAINT event_feedback_pkey PRIMARY KEY (id);


--
-- Name: event_registrations event_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_pkey PRIMARY KEY (id);


--
-- Name: event_sessions event_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_sessions
    ADD CONSTRAINT event_sessions_pkey PRIMARY KEY (id);


--
-- Name: event_speakers event_speakers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_speakers
    ADD CONSTRAINT event_speakers_pkey PRIMARY KEY (id);


--
-- Name: event_sponsors event_sponsors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_sponsors
    ADD CONSTRAINT event_sponsors_pkey PRIMARY KEY (id);


--
-- Name: event_tickets event_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_tickets
    ADD CONSTRAINT event_tickets_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: integration_events integration_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integration_events
    ADD CONSTRAINT integration_events_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: kpi_snapshots kpi_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_snapshots
    ADD CONSTRAINT kpi_snapshots_pkey PRIMARY KEY (id);


--
-- Name: member_activity_logs member_activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_activity_logs
    ADD CONSTRAINT member_activity_logs_pkey PRIMARY KEY (id);


--
-- Name: member_group_memberships member_group_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_group_memberships
    ADD CONSTRAINT member_group_memberships_pkey PRIMARY KEY (id);


--
-- Name: member_groups member_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups
    ADD CONSTRAINT member_groups_pkey PRIMARY KEY (id);


--
-- Name: member_notes member_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notes
    ADD CONSTRAINT member_notes_pkey PRIMARY KEY (id);


--
-- Name: member_profile_tags member_profile_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profile_tags
    ADD CONSTRAINT member_profile_tags_pkey PRIMARY KEY (member_id, tag_id);


--
-- Name: member_profiles member_profiles_member_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profiles
    ADD CONSTRAINT member_profiles_member_number_key UNIQUE (member_number);


--
-- Name: member_profiles member_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profiles
    ADD CONSTRAINT member_profiles_pkey PRIMARY KEY (id);


--
-- Name: member_profiles member_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profiles
    ADD CONSTRAINT member_profiles_user_id_key UNIQUE (user_id);


--
-- Name: member_tags member_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_tags
    ADD CONSTRAINT member_tags_pkey PRIMARY KEY (id);


--
-- Name: message_logs message_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_pkey PRIMARY KEY (id);


--
-- Name: nominations nominations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nominations
    ADD CONSTRAINT nominations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: recurring_transactions recurring_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_transactions
    ADD CONSTRAINT recurring_transactions_pkey PRIMARY KEY (id);


--
-- Name: saved_reports saved_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT saved_reports_pkey PRIMARY KEY (id);


--
-- Name: survey_responses survey_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.survey_responses
    ADD CONSTRAINT survey_responses_pkey PRIMARY KEY (id);


--
-- Name: surveys surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: workflow_action_templates workflow_action_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_action_templates
    ADD CONSTRAINT workflow_action_templates_pkey PRIMARY KEY (id);


--
-- Name: workflow_delays workflow_delays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_delays
    ADD CONSTRAINT workflow_delays_pkey PRIMARY KEY (id);


--
-- Name: workflow_runs workflow_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant ON public.audit_logs USING btree (tenant_id);


--
-- Name: idx_audit_logs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user ON public.audit_logs USING btree (user_id);


--
-- Name: idx_email_tracking_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_tracking_tenant ON public.email_tracking_events USING btree (tenant_id);


--
-- Name: idx_esl_tracking; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_esl_tracking ON public.email_sending_logs USING btree (tracking_id);


--
-- Name: idx_esl_unsubscribe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_esl_unsubscribe ON public.email_sending_logs USING btree (unsubscribe_token);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id, tenant_id, is_read);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, tenant_id);


--
-- Name: ix_ai_conversations_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_conversations_session_id ON public.ai_conversations USING btree (session_id);


--
-- Name: ix_ai_conversations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_conversations_tenant_id ON public.ai_conversations USING btree (tenant_id);


--
-- Name: ix_ai_embeddings_content_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_embeddings_content_id ON public.ai_embeddings USING btree (content_id);


--
-- Name: ix_ai_embeddings_content_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_embeddings_content_type ON public.ai_embeddings USING btree (content_type);


--
-- Name: ix_ai_embeddings_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_embeddings_tenant_id ON public.ai_embeddings USING btree (tenant_id);


--
-- Name: ix_ai_insights_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_insights_tenant_id ON public.ai_insights USING btree (tenant_id);


--
-- Name: ix_ai_models_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_models_tenant_id ON public.ai_models USING btree (tenant_id);


--
-- Name: ix_ai_predictions_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_predictions_entity_id ON public.ai_predictions USING btree (entity_id);


--
-- Name: ix_ai_predictions_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_predictions_entity_type ON public.ai_predictions USING btree (entity_type);


--
-- Name: ix_ai_predictions_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_predictions_model_id ON public.ai_predictions USING btree (model_id);


--
-- Name: ix_ai_predictions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ai_predictions_tenant_id ON public.ai_predictions USING btree (tenant_id);


--
-- Name: ix_announcements_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_tenant_id ON public.announcements USING btree (tenant_id);


--
-- Name: ix_ballots_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ballots_election_id ON public.ballots USING btree (election_id);


--
-- Name: ix_ballots_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ballots_tenant_id ON public.ballots USING btree (tenant_id);


--
-- Name: ix_ballots_voter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ballots_voter_id ON public.ballots USING btree (voter_id);


--
-- Name: ix_budgets_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_budgets_tenant_id ON public.budgets USING btree (tenant_id);


--
-- Name: ix_dashboard_widgets_dashboard_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dashboard_widgets_dashboard_id ON public.dashboard_widgets USING btree (dashboard_id);


--
-- Name: ix_dashboard_widgets_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dashboard_widgets_tenant_id ON public.dashboard_widgets USING btree (tenant_id);


--
-- Name: ix_dashboards_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dashboards_tenant_id ON public.dashboards USING btree (tenant_id);


--
-- Name: ix_data_exports_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_data_exports_tenant_id ON public.data_exports USING btree (tenant_id);


--
-- Name: ix_discount_codes_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discount_codes_tenant_id ON public.discount_codes USING btree (tenant_id);


--
-- Name: ix_document_activities_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_activities_document_id ON public.document_activities USING btree (document_id);


--
-- Name: ix_document_activities_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_activities_tenant_id ON public.document_activities USING btree (tenant_id);


--
-- Name: ix_document_categories_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_categories_tenant_id ON public.document_categories USING btree (tenant_id);


--
-- Name: ix_document_comments_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_comments_document_id ON public.document_comments USING btree (document_id);


--
-- Name: ix_document_comments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_comments_tenant_id ON public.document_comments USING btree (tenant_id);


--
-- Name: ix_document_shares_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shares_document_id ON public.document_shares USING btree (document_id);


--
-- Name: ix_document_shares_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_shares_tenant_id ON public.document_shares USING btree (tenant_id);


--
-- Name: ix_document_versions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_versions_document_id ON public.document_versions USING btree (document_id);


--
-- Name: ix_document_versions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_versions_tenant_id ON public.document_versions USING btree (tenant_id);


--
-- Name: ix_documents_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_category_id ON public.documents USING btree (category_id);


--
-- Name: ix_documents_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_tenant_id ON public.documents USING btree (tenant_id);


--
-- Name: ix_drip_campaigns_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_campaigns_tenant_id ON public.drip_campaigns USING btree (tenant_id);


--
-- Name: ix_drip_enrollments_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_enrollments_campaign_id ON public.drip_enrollments USING btree (campaign_id);


--
-- Name: ix_drip_enrollments_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_enrollments_member_id ON public.drip_enrollments USING btree (member_id);


--
-- Name: ix_drip_enrollments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_enrollments_tenant_id ON public.drip_enrollments USING btree (tenant_id);


--
-- Name: ix_drip_logs_enrollment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_logs_enrollment_id ON public.drip_logs USING btree (enrollment_id);


--
-- Name: ix_drip_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_logs_tenant_id ON public.drip_logs USING btree (tenant_id);


--
-- Name: ix_drip_steps_campaign_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_steps_campaign_id ON public.drip_steps USING btree (campaign_id);


--
-- Name: ix_drip_steps_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drip_steps_tenant_id ON public.drip_steps USING btree (tenant_id);


--
-- Name: ix_dues_structures_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_dues_structures_tenant_id ON public.dues_structures USING btree (tenant_id);


--
-- Name: ix_election_positions_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_positions_election_id ON public.election_positions USING btree (election_id);


--
-- Name: ix_election_positions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_positions_tenant_id ON public.election_positions USING btree (tenant_id);


--
-- Name: ix_election_results_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_results_election_id ON public.election_results USING btree (election_id);


--
-- Name: ix_election_results_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_results_tenant_id ON public.election_results USING btree (tenant_id);


--
-- Name: ix_elections_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_elections_tenant_id ON public.elections USING btree (tenant_id);


--
-- Name: ix_email_campaigns_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_campaigns_tenant_id ON public.email_campaigns USING btree (tenant_id);


--
-- Name: ix_email_sending_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_sending_logs_created_at ON public.email_sending_logs USING btree (created_at);


--
-- Name: ix_email_sending_logs_recipient_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_sending_logs_recipient_email ON public.email_sending_logs USING btree (recipient_email);


--
-- Name: ix_email_sending_logs_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_sending_logs_recipient_id ON public.email_sending_logs USING btree (recipient_id);


--
-- Name: ix_email_sending_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_sending_logs_status ON public.email_sending_logs USING btree (status);


--
-- Name: ix_email_sending_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_sending_logs_tenant_id ON public.email_sending_logs USING btree (tenant_id);


--
-- Name: ix_email_sending_logs_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_sending_logs_tenant_status ON public.email_sending_logs USING btree (tenant_id, status);


--
-- Name: ix_email_templates_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_templates_tenant_id ON public.email_templates USING btree (tenant_id);


--
-- Name: ix_event_feedback_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_feedback_event_id ON public.event_feedback USING btree (event_id);


--
-- Name: ix_event_feedback_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_feedback_tenant_id ON public.event_feedback USING btree (tenant_id);


--
-- Name: ix_event_registrations_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_registrations_event_id ON public.event_registrations USING btree (event_id);


--
-- Name: ix_event_registrations_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_registrations_member_id ON public.event_registrations USING btree (member_id);


--
-- Name: ix_event_registrations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_registrations_tenant_id ON public.event_registrations USING btree (tenant_id);


--
-- Name: ix_event_sessions_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_sessions_event_id ON public.event_sessions USING btree (event_id);


--
-- Name: ix_event_sessions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_sessions_tenant_id ON public.event_sessions USING btree (tenant_id);


--
-- Name: ix_event_speakers_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_speakers_event_id ON public.event_speakers USING btree (event_id);


--
-- Name: ix_event_speakers_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_speakers_tenant_id ON public.event_speakers USING btree (tenant_id);


--
-- Name: ix_event_sponsors_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_sponsors_event_id ON public.event_sponsors USING btree (event_id);


--
-- Name: ix_event_sponsors_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_sponsors_tenant_id ON public.event_sponsors USING btree (tenant_id);


--
-- Name: ix_event_tickets_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_tickets_event_id ON public.event_tickets USING btree (event_id);


--
-- Name: ix_event_tickets_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_event_tickets_tenant_id ON public.event_tickets USING btree (tenant_id);


--
-- Name: ix_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_events_tenant_id ON public.events USING btree (tenant_id);


--
-- Name: ix_expenses_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_expenses_tenant_id ON public.expenses USING btree (tenant_id);


--
-- Name: ix_integration_events_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_integration_events_tenant_id ON public.integration_events USING btree (tenant_id);


--
-- Name: ix_integrations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_integrations_tenant_id ON public.integrations USING btree (tenant_id);


--
-- Name: ix_invoices_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoices_member_id ON public.invoices USING btree (member_id);


--
-- Name: ix_invoices_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoices_tenant_id ON public.invoices USING btree (tenant_id);


--
-- Name: ix_kpi_snapshots_metric_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kpi_snapshots_metric_name ON public.kpi_snapshots USING btree (metric_name);


--
-- Name: ix_kpi_snapshots_snapshot_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kpi_snapshots_snapshot_date ON public.kpi_snapshots USING btree (snapshot_date);


--
-- Name: ix_kpi_snapshots_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_kpi_snapshots_tenant_id ON public.kpi_snapshots USING btree (tenant_id);


--
-- Name: ix_member_activity_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_member_activity_logs_tenant_id ON public.member_activity_logs USING btree (tenant_id);


--
-- Name: ix_member_groups_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_member_groups_tenant_id ON public.member_groups USING btree (tenant_id);


--
-- Name: ix_member_notes_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_member_notes_tenant_id ON public.member_notes USING btree (tenant_id);


--
-- Name: ix_member_profiles_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_member_profiles_tenant_id ON public.member_profiles USING btree (tenant_id);


--
-- Name: ix_member_tags_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_member_tags_tenant_id ON public.member_tags USING btree (tenant_id);


--
-- Name: ix_message_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_logs_tenant_id ON public.message_logs USING btree (tenant_id);


--
-- Name: ix_nominations_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nominations_election_id ON public.nominations USING btree (election_id);


--
-- Name: ix_nominations_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nominations_member_id ON public.nominations USING btree (member_id);


--
-- Name: ix_nominations_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_nominations_tenant_id ON public.nominations USING btree (tenant_id);


--
-- Name: ix_notifications_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_tenant_id ON public.notifications USING btree (tenant_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_payments_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payments_invoice_id ON public.payments USING btree (invoice_id);


--
-- Name: ix_payments_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_payments_tenant_id ON public.payments USING btree (tenant_id);


--
-- Name: ix_recurring_transactions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recurring_transactions_tenant_id ON public.recurring_transactions USING btree (tenant_id);


--
-- Name: ix_saved_reports_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_saved_reports_tenant_id ON public.saved_reports USING btree (tenant_id);


--
-- Name: ix_survey_responses_survey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_responses_survey_id ON public.survey_responses USING btree (survey_id);


--
-- Name: ix_surveys_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_tenant_id ON public.surveys USING btree (tenant_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: ix_webhook_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_logs_tenant_id ON public.webhook_logs USING btree (tenant_id);


--
-- Name: ix_webhook_logs_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_logs_webhook_id ON public.webhook_logs USING btree (webhook_id);


--
-- Name: ix_webhooks_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhooks_tenant_id ON public.webhooks USING btree (tenant_id);


--
-- Name: ix_workflow_action_templates_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_action_templates_tenant_id ON public.workflow_action_templates USING btree (tenant_id);


--
-- Name: ix_workflow_delays_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_delays_run_id ON public.workflow_delays USING btree (run_id);


--
-- Name: ix_workflow_delays_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_delays_tenant_id ON public.workflow_delays USING btree (tenant_id);


--
-- Name: ix_workflow_delays_workflow_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_delays_workflow_id ON public.workflow_delays USING btree (workflow_id);


--
-- Name: ix_workflow_runs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_runs_tenant_id ON public.workflow_runs USING btree (tenant_id);


--
-- Name: ix_workflow_runs_workflow_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_runs_workflow_id ON public.workflow_runs USING btree (workflow_id);


--
-- Name: ix_workflows_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflows_tenant_id ON public.workflows USING btree (tenant_id);


--
-- Name: ballots ballots_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ballots
    ADD CONSTRAINT ballots_election_id_fkey FOREIGN KEY (election_id) REFERENCES public.elections(id);


--
-- Name: ballots ballots_voter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ballots
    ADD CONSTRAINT ballots_voter_id_fkey FOREIGN KEY (voter_id) REFERENCES public.member_profiles(id);


--
-- Name: dashboard_widgets dashboard_widgets_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id);


--
-- Name: discount_codes discount_codes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: document_activities document_activities_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_activities
    ADD CONSTRAINT document_activities_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: document_activities document_activities_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_activities
    ADD CONSTRAINT document_activities_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: document_categories document_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.document_categories(id);


--
-- Name: document_comments document_comments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_comments
    ADD CONSTRAINT document_comments_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: document_comments document_comments_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_comments
    ADD CONSTRAINT document_comments_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: document_comments document_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_comments
    ADD CONSTRAINT document_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.document_comments(id);


--
-- Name: document_shares document_shares_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: document_shares document_shares_shared_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_shared_by_fkey FOREIGN KEY (shared_by) REFERENCES public.member_profiles(id);


--
-- Name: document_shares document_shares_shared_with_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_shared_with_fkey FOREIGN KEY (shared_with) REFERENCES public.member_profiles(id);


--
-- Name: document_versions document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: documents documents_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.document_categories(id);


--
-- Name: documents documents_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.documents(id);


--
-- Name: drip_enrollments drip_enrollments_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_enrollments
    ADD CONSTRAINT drip_enrollments_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.drip_campaigns(id);


--
-- Name: drip_logs drip_logs_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_logs
    ADD CONSTRAINT drip_logs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.drip_campaigns(id);


--
-- Name: drip_logs drip_logs_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_logs
    ADD CONSTRAINT drip_logs_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.drip_enrollments(id);


--
-- Name: drip_logs drip_logs_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_logs
    ADD CONSTRAINT drip_logs_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.drip_steps(id);


--
-- Name: drip_steps drip_steps_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drip_steps
    ADD CONSTRAINT drip_steps_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.drip_campaigns(id);


--
-- Name: election_positions election_positions_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.election_positions
    ADD CONSTRAINT election_positions_election_id_fkey FOREIGN KEY (election_id) REFERENCES public.elections(id);


--
-- Name: election_results election_results_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.election_results
    ADD CONSTRAINT election_results_election_id_fkey FOREIGN KEY (election_id) REFERENCES public.elections(id);


--
-- Name: election_results election_results_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.election_results
    ADD CONSTRAINT election_results_position_id_fkey FOREIGN KEY (position_id) REFERENCES public.election_positions(id);


--
-- Name: email_sending_logs email_sending_logs_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sending_logs
    ADD CONSTRAINT email_sending_logs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.email_campaigns(id);


--
-- Name: email_sending_logs email_sending_logs_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sending_logs
    ADD CONSTRAINT email_sending_logs_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: email_sending_logs email_sending_logs_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sending_logs
    ADD CONSTRAINT email_sending_logs_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.email_templates(id);


--
-- Name: event_feedback event_feedback_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_feedback
    ADD CONSTRAINT event_feedback_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_feedback event_feedback_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_feedback
    ADD CONSTRAINT event_feedback_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: event_feedback event_feedback_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_feedback
    ADD CONSTRAINT event_feedback_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.event_sessions(id);


--
-- Name: event_registrations event_registrations_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_registrations event_registrations_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: event_registrations event_registrations_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_registrations
    ADD CONSTRAINT event_registrations_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.event_tickets(id);


--
-- Name: event_sessions event_sessions_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_sessions
    ADD CONSTRAINT event_sessions_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_speakers event_speakers_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_speakers
    ADD CONSTRAINT event_speakers_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_speakers event_speakers_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_speakers
    ADD CONSTRAINT event_speakers_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: event_speakers event_speakers_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_speakers
    ADD CONSTRAINT event_speakers_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.event_sessions(id);


--
-- Name: event_sponsors event_sponsors_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_sponsors
    ADD CONSTRAINT event_sponsors_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: event_tickets event_tickets_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_tickets
    ADD CONSTRAINT event_tickets_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- Name: expenses expenses_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: expenses expenses_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budgets(id);


--
-- Name: expenses expenses_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: invoices invoices_dues_structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_dues_structure_id_fkey FOREIGN KEY (dues_structure_id) REFERENCES public.dues_structures(id);


--
-- Name: invoices invoices_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: member_activity_logs member_activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_activity_logs
    ADD CONSTRAINT member_activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: member_group_memberships member_group_memberships_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_group_memberships
    ADD CONSTRAINT member_group_memberships_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.member_groups(id);


--
-- Name: member_group_memberships member_group_memberships_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_group_memberships
    ADD CONSTRAINT member_group_memberships_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: member_groups member_groups_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups
    ADD CONSTRAINT member_groups_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.member_groups(id);


--
-- Name: member_notes member_notes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notes
    ADD CONSTRAINT member_notes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: member_notes member_notes_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notes
    ADD CONSTRAINT member_notes_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: member_profile_tags member_profile_tags_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profile_tags
    ADD CONSTRAINT member_profile_tags_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: member_profile_tags member_profile_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profile_tags
    ADD CONSTRAINT member_profile_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.member_tags(id);


--
-- Name: member_profiles member_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_profiles
    ADD CONSTRAINT member_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: message_logs message_logs_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES public.email_campaigns(id);


--
-- Name: message_logs message_logs_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: nominations nominations_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nominations
    ADD CONSTRAINT nominations_election_id_fkey FOREIGN KEY (election_id) REFERENCES public.elections(id);


--
-- Name: nominations nominations_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nominations
    ADD CONSTRAINT nominations_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: nominations nominations_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nominations
    ADD CONSTRAINT nominations_position_id_fkey FOREIGN KEY (position_id) REFERENCES public.election_positions(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: payments payments_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: recurring_transactions recurring_transactions_dues_structure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_transactions
    ADD CONSTRAINT recurring_transactions_dues_structure_id_fkey FOREIGN KEY (dues_structure_id) REFERENCES public.dues_structures(id);


--
-- Name: recurring_transactions recurring_transactions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_transactions
    ADD CONSTRAINT recurring_transactions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member_profiles(id);


--
-- Name: survey_responses survey_responses_respondent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.survey_responses
    ADD CONSTRAINT survey_responses_respondent_id_fkey FOREIGN KEY (respondent_id) REFERENCES public.users(id);


--
-- Name: survey_responses survey_responses_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.survey_responses
    ADD CONSTRAINT survey_responses_survey_id_fkey FOREIGN KEY (survey_id) REFERENCES public.surveys(id);


--
-- Name: webhook_logs webhook_logs_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id);


--
-- Name: workflow_delays workflow_delays_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_delays
    ADD CONSTRAINT workflow_delays_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.workflow_runs(id);


--
-- Name: workflow_delays workflow_delays_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_delays
    ADD CONSTRAINT workflow_delays_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: workflow_runs workflow_runs_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_runs
    ADD CONSTRAINT workflow_runs_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- PostgreSQL database dump complete
--

\unrestrict xmdXl7eYJDNRdd08hIVVRw9QFbr6OnYXaFsldhx4S6HalZDoF43Lo2L6oDci89D

